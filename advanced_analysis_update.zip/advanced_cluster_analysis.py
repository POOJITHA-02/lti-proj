"""
Advanced cluster analysis — goes beyond "run 4 algorithms, pick the best" to answer
three questions a reviewer will actually ask:

1. How many clusters should there really be? (rigorous k sweep, not a fixed heuristic)
2. Are the clusters real, or a fluke of one random run? (bootstrap stability check)
3. What actually distinguishes each cluster? (feature importance via surrogate model)

Run this AFTER pattern_discovery.py has populated shopper_signatures.
"""

from datetime import datetime

import mlflow
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.tree import DecisionTreeClassifier

from db import get_connection, init_db
from pattern_discovery import (
    MLFLOW_EXPERIMENT,
    build_feature_table,
    encode_features,
    get_feature_names,
    reduce_dimensions,
)

N_BOOTSTRAP = 10           # how many subsamples to test stability across
SUBSAMPLE_FRACTION = 0.8   # fraction of users kept in each bootstrap subsample
K_RANGE = range(2, 9)      # cluster counts to sweep when picking k


def optimal_k_sweep(X: np.ndarray) -> dict[int, float]:
    """Silhouette score for K-Means across a range of k — a data-driven justification
    for cluster count instead of a fixed heuristic like min(5, n//3)."""
    scores = {}
    for k in K_RANGE:
        if k >= len(X):
            break
        labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(X)
        scores[k] = silhouette_score(X, labels)
    return scores


def stability_check(X: np.ndarray, full_labels: np.ndarray, k: int) -> float:
    """Repeatedly clusters random subsamples and measures agreement (Adjusted Rand
    Index) against the full-data clustering restricted to the same rows. ARI close
    to 1 = clusters are stable and not an artifact of one particular run; ARI near 0
    = clusters would look substantially different on a different sample of shoppers."""
    n = len(X)
    ari_scores = []
    rng = np.random.default_rng(42)

    for _ in range(N_BOOTSTRAP):
        idx = rng.choice(n, size=int(n * SUBSAMPLE_FRACTION), replace=False)
        sub_labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(X[idx])
        ari_scores.append(adjusted_rand_score(full_labels[idx], sub_labels))

    return float(np.mean(ari_scores))


def feature_importance(X_encoded: np.ndarray, feature_names: list[str], cluster_labels: np.ndarray):
    """Trains a shallow decision tree to predict cluster assignment from the ORIGINAL
    (pre-UMAP) features. High accuracy means the clusters are genuinely explainable
    by these interpretable shopper dimensions — not just an artifact of the UMAP
    embedding. feature_importances_ tells you which dimensions actually drive the
    split between clusters, which is the concrete answer to 'what defines cluster X'."""
    tree = DecisionTreeClassifier(max_depth=5, random_state=42)
    tree.fit(X_encoded, cluster_labels)
    accuracy = tree.score(X_encoded, cluster_labels)

    importance_df = pd.DataFrame(
        {"feature": feature_names, "importance": tree.feature_importances_}
    ).sort_values("importance", ascending=False)

    return importance_df, accuracy


def run() -> None:
    init_db()
    conn = get_connection()
    mlflow.set_experiment(MLFLOW_EXPERIMENT)

    print("Building feature table...")
    df = build_feature_table(conn)
    if len(df) < 10:
        print(f"Only {len(df)} users — need more tagged/live data before deeper analysis is meaningful.")
        conn.close()
        return

    X_encoded = encode_features(df)
    feature_names = get_feature_names(df)
    X_reduced = reduce_dimensions(X_encoded)

    print("\n=== 1. Optimal k sweep (silhouette score by cluster count) ===")
    k_scores = optimal_k_sweep(X_reduced)
    for k, score in k_scores.items():
        print(f"  k={k}: silhouette={score:.3f}")
    best_k = max(k_scores, key=k_scores.get)
    print(f"  -> best k by silhouette: {best_k}")

    print(f"\n=== 2. Cluster stability check (k={best_k}, {N_BOOTSTRAP} subsamples of {SUBSAMPLE_FRACTION:.0%}) ===")
    full_labels = KMeans(n_clusters=best_k, random_state=42, n_init=10).fit_predict(X_reduced)
    stability = stability_check(X_reduced, full_labels, best_k)
    verdict = "stable" if stability > 0.7 else "moderately stable" if stability > 0.4 else "unstable"
    print(f"  Average Adjusted Rand Index across {N_BOOTSTRAP} subsamples: {stability:.3f} ({verdict})")

    print("\n=== 3. Feature importance (surrogate decision tree on original features) ===")
    importance_df, accuracy = feature_importance(X_encoded, feature_names, full_labels)
    print(f"  Decision tree accuracy reconstructing clusters from raw features: {accuracy:.1%}")
    print(importance_df.head(10).to_string(index=False))

    with mlflow.start_run(run_name="advanced_cluster_analysis"):
        mlflow.log_param("best_k_by_silhouette", best_k)
        mlflow.log_metric("cluster_stability_ari", stability)
        mlflow.log_metric("surrogate_tree_accuracy", accuracy)
        for k, score in k_scores.items():
            mlflow.log_metric(f"silhouette_k{k}", score)

    importance_df.to_csv("feature_importance.csv", index=False)
    print("\nSaved feature_importance.csv")

    conn.close()


if __name__ == "__main__":
    run()
