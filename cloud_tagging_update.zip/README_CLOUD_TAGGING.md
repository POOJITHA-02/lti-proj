# Cloud Tagging Setup (Groq + SambaNova, free tier)

This replaces local Ollama tagging for the ambiguous product set — both providers'
free tiers run **concurrently**, roughly doubling effective throughput at $0 cost.

## 1. Get free API keys (no credit card needed for free tier)

**Groq**
1. Go to https://console.groq.com/keys
2. Sign up / log in, click "Create API Key"
3. Copy the key (starts with `gsk_...`)

**SambaNova**
1. Go to https://cloud.sambanova.ai/apis
2. Sign up / log in, create an API key
3. Copy the key

## 2. Set them as environment variables

**Windows (cmd):**
```
set GROQ_API_KEY=gsk_your_key_here
set SAMBANOVA_API_KEY=your_key_here
```
**Windows (PowerShell):**
```
$env:GROQ_API_KEY="gsk_your_key_here"
$env:SAMBANOVA_API_KEY="your_key_here"
```
These only last for the current terminal session — set them again if you open a new terminal, or add them to your `.env` file loading if you prefer (not wired up by default here, since this script is meant to run standalone).

You can run with just one key set (it'll use only that provider) — both is faster.

## 3. Install the one new dependency

```
pip install openai
```
(Both Groq and SambaNova expose OpenAI-compatible endpoints, so the standard `openai` package works for both — no provider-specific SDK needed.)

## 4. Run it

```
python hybrid_tagging.py
```

This will:
1. Tag clear-cut products via rules (instant)
2. Send the entire remaining ambiguous set to Groq + SambaNova, running concurrently
3. Anything not reached (e.g. only one key set, or you stop it early) falls back to the basket-size heuristic — every product still ends up tagged either way

## Checking / tuning rate limits

The `rpm_limit` values in `cloud_tagging.py`'s `PROVIDERS` dict are conservative starting
points:
- Groq: documented at 30 RPM free tier — set to 25 for safety margin
- SambaNova: free-tier RPM wasn't fully confirmed from public docs — set to 15 to be safe

After your first run, check the actual response headers your account gets
(`x-ratelimit-remaining-requests`, etc.) or your provider dashboard, and raise these
numbers if you have headroom, or lower them if you're seeing repeated 429 retries in
the console output.

## If you hit persistent 429s

The script already retries with backoff (15s × attempt number) on rate-limit errors.
If a provider is consistently rate-limited, lower its `rpm_limit` and/or `batch_size`
in `cloud_tagging.py` and rerun — it's safe to rerun any number of times, since it
only processes products not already tagged.

## Verifying results

```sql
SELECT tag_source, COUNT(*) FROM product_tags GROUP BY tag_source;
```
This is the number to report in your review — real % tagged via each cloud provider
vs. rules vs. fallback.
