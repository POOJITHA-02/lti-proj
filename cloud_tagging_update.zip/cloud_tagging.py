"""
Cloud tagging — splits the ambiguous product set across Groq and SambaNova free
tiers, running both concurrently. Each provider's free tier is a separate quota,
so running them in parallel roughly doubles effective throughput at $0 cost.

Setup:
    pip install openai
    export GROQ_API_KEY=...       # https://console.groq.com/keys
    export SAMBANOVA_API_KEY=...  # https://cloud.sambanova.ai/apis

Both providers expose OpenAI-compatible endpoints, so one client class covers
both — only base_url, api_key, and model differ.

IMPORTANT — rate limits below are conservative starting points, not guarantees.
Check the actual x-ratelimit-* response headers (or your provider dashboard)
after a few real calls and adjust RPM_LIMIT per provider if you have headroom,
or lower it if you're getting 429s.
"""

import json
import os
import re
import threading
import time
from collections import deque
from datetime import datetime

from openai import OpenAI

from db import get_connection

PROVIDERS = {
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "api_key_env": "GROQ_API_KEY",
        "model": "llama-3.1-8b-instant",
        "rpm_limit": 25,     # documented free tier: 30 RPM — 25 leaves safety margin
        "batch_size": 25,    # amortizes fixed prompt overhead against the ~6000 TPM ceiling
        "tag_source": "llm_groq",
    },
    "sambanova": {
        "base_url": "https://api.sambanova.ai/v1",
        "api_key_env": "SAMBANOVA_API_KEY",
        "model": "Meta-Llama-3.3-70B-Instruct",
        "rpm_limit": 15,     # conservative — free-tier RPM wasn't fully confirmed, verify on your dashboard
        "batch_size": 20,
        "tag_source": "llm_sambanova",
    },
}

BATCH_PROMPT = """Classify each grocery product on two dimensions using the name and stats given.

1. household_orientation: "solo" or "family" — higher avg_basket_size_when_purchased leans "family"
2. convenience: "ready_to_eat" (no/minimal prep) or "raw_ingredients" (needs cooking)

There are exactly {n} products. Return exactly {n} JSON objects, one per product, same order.

Products (id: name | count | reorder_rate | avg_basket_size):
{product_list}

Respond with ONLY a JSON array, no other text:
[{{"product_id": <id>, "household_orientation": "<solo|family>", "convenience": "<ready_to_eat|raw_ingredients>"}}, ...]
"""


class RateLimiter:
    """Sliding-window limiter — blocks until a call is safely within rpm_limit."""

    def __init__(self, rpm_limit: int):
        self.rpm_limit = rpm_limit
        self.calls = deque()
        self.lock = threading.Lock()

    def wait(self) -> None:
        with self.lock:
            now = time.time()
            while self.calls and now - self.calls[0] > 60:
                self.calls.popleft()
            if len(self.calls) >= self.rpm_limit:
                sleep_for = 60 - (now - self.calls[0]) + 0.1
            else:
                sleep_for = 0
            if sleep_for > 0:
                time.sleep(sleep_for)
            self.calls.append(time.time())


def extract_json_array(text: str) -> list[dict]:
    text = text.strip()
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            return parsed
    except json.JSONDecodeError:
        pass

    fence_match = re.search(r"```(?:json)?\s*(.*?)\s*```", text, re.DOTALL)
    if fence_match:
        try:
            parsed = json.loads(fence_match.group(1))
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass

    bracket_match = re.search(r"\[.*\]", text, re.DOTALL)
    if bracket_match:
        try:
            parsed = json.loads(bracket_match.group(0))
            if isinstance(parsed, list):
                return parsed
        except json.JSONDecodeError:
            pass

    return []


def call_provider(client: OpenAI, model: str, batch: list[tuple]) -> list[dict]:
    product_list = "\n".join(
        f"{pid}: {name} | {count} | {rr:.2f} | {ab:.1f}" for pid, name, count, rr, ab in batch
    )
    prompt = BATCH_PROMPT.format(n=len(batch), product_list=product_list)

    max_retries = 4
    for attempt in range(1, max_retries + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=60 * len(batch),
            )
            content = response.choices[0].message.content
            parsed = extract_json_array(content)
            if parsed:
                return parsed
            print(f"    [retry {attempt}] couldn't extract JSON array from response")
        except Exception as e:
            is_rate_limit = "429" in str(e) or "rate_limit" in str(e).lower()
            wait = 15 * attempt if is_rate_limit else 2 * attempt
            print(f"    [retry {attempt}/{max_retries}] {'rate limited' if is_rate_limit else 'error'}: {e} — waiting {wait}s")
            time.sleep(wait)

    return []


def save_tags(conn, tags: list[dict], tag_source: str, lock: threading.Lock) -> int:
    now = datetime.utcnow().isoformat()
    saved = 0
    with lock:
        for t in tags:
            try:
                conn.execute(
                    """INSERT INTO product_tags (product_id, household_orientation, convenience, tag_source, tagged_at)
                       VALUES (?, ?, ?, ?, ?)
                       ON CONFLICT(product_id) DO UPDATE SET
                           household_orientation = excluded.household_orientation,
                           convenience = excluded.convenience,
                           tag_source = excluded.tag_source,
                           tagged_at = excluded.tagged_at""",
                    (t["product_id"], t["household_orientation"], t["convenience"], tag_source, now),
                )
                saved += 1
            except (KeyError, TypeError) as e:
                print(f"    skipped malformed tag {t}: {e}")
        conn.commit()
    return saved


def provider_worker(provider_name: str, products: list[tuple], db_lock: threading.Lock, progress: dict) -> None:
    cfg = PROVIDERS[provider_name]
    api_key = os.environ.get(cfg["api_key_env"])
    if not api_key:
        print(f"[{provider_name}] SKIPPED — {cfg['api_key_env']} not set")
        return

    client = OpenAI(base_url=cfg["base_url"], api_key=api_key)
    limiter = RateLimiter(cfg["rpm_limit"])
    batch_size = cfg["batch_size"]
    conn = get_connection()  # opened in this thread — SQLite connections aren't thread-safe to share

    print(f"[{provider_name}] starting — {len(products)} products, batch size {batch_size}, {cfg['rpm_limit']} RPM cap")

    tagged = 0
    for i in range(0, len(products), batch_size):
        batch = products[i:i + batch_size]
        limiter.wait()
        result = call_provider(client, cfg["model"], batch)
        saved = save_tags(conn, result, cfg["tag_source"], db_lock)
        tagged += saved
        progress[provider_name] = tagged
        if saved < len(batch):
            print(f"[{provider_name}] batch at {i}: only {saved}/{len(batch)} tagged")

    conn.close()
    print(f"[{provider_name}] done — {tagged}/{len(products)} tagged")


def tag_products_cloud(products: list[tuple]) -> int:
    """Splits `products` (list of (product_id, name, count, reorder_rate, avg_basket) tuples)
    across all configured providers with a set API key, running them concurrently.
    Returns total number successfully tagged."""
    db_lock = threading.Lock()
    progress = {}

    active_providers = [p for p in PROVIDERS if os.environ.get(PROVIDERS[p]["api_key_env"])]
    if not active_providers:
        print("No provider API keys found in environment. Set GROQ_API_KEY and/or SAMBANOVA_API_KEY.")
        return 0

    print(f"Active providers: {active_providers}")
    split_size = len(products) // len(active_providers)
    splits = {}
    for idx, provider_name in enumerate(active_providers):
        start = idx * split_size
        end = None if idx == len(active_providers) - 1 else start + split_size
        splits[provider_name] = products[start:end]

    threads = [
        threading.Thread(target=provider_worker, args=(name, splits[name], db_lock, progress))
        for name in active_providers
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    return sum(progress.values())
