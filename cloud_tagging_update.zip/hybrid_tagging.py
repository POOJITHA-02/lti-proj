"""
Hybrid product tagging — rules where they're reliable, cloud LLMs (Groq +
SambaNova, running concurrently on free tiers) for everything genuinely
ambiguous. See cloud_tagging.py for the provider setup/API key instructions.

Flow:
  1. Fast rule pass (instant) — name patterns + family-implying aisles.
  2. Everything else (no name/aisle signal) goes to tag_products_cloud(),
     which splits the full list across Groq + SambaNova and runs both
     concurrently, respecting each provider's own rate limit.
  3. Anything the cloud step doesn't reach (no API keys set, or it was
     interrupted) keeps the basket-size fallback so every product still
     ends up tagged.
"""

from datetime import datetime

from cloud_tagging import tag_products_cloud
from db import get_connection, init_db
from rule_based_tagging import (
    FAMILY_AISLES,
    FAMILY_NAME_PATTERNS,
    SOLO_NAME_PATTERNS,
    classify_convenience,
    get_family_threshold,
)


def has_name_or_aisle_signal(name: str, aisle_id: int) -> bool:
    return bool(
        SOLO_NAME_PATTERNS.search(name)
        or FAMILY_NAME_PATTERNS.search(name)
        or aisle_id in FAMILY_AISLES
    )


def classify_by_rule(name: str, aisle_id: int) -> tuple[str, str]:
    if SOLO_NAME_PATTERNS.search(name):
        return "solo", "rule_name"
    if FAMILY_NAME_PATTERNS.search(name):
        return "family", "rule_name"
    return "family", "rule_aisle"


def save_tag(conn, product_id: int, household: str, convenience: str, source: str, now: str) -> None:
    conn.execute(
        """INSERT INTO product_tags (product_id, household_orientation, convenience, tag_source, tagged_at)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(product_id) DO UPDATE SET
               household_orientation = excluded.household_orientation,
               convenience = excluded.convenience,
               tag_source = excluded.tag_source,
               tagged_at = excluded.tagged_at""",
        (product_id, household, convenience, source, now),
    )


def run() -> None:
    init_db()
    conn = get_connection()
    now = datetime.utcnow().isoformat()

    all_products = conn.execute(
        """SELECT p.product_id, p.product_name, p.aisle_id,
                  COALESCE(ps.purchase_count, 0), COALESCE(ps.reorder_rate, 0.0),
                  COALESCE(ps.avg_basket_size_when_purchased, 0.0)
           FROM products p
           LEFT JOIN product_stats ps ON p.product_id = ps.product_id
           LEFT JOIN product_tags pt ON p.product_id = pt.product_id
           WHERE pt.product_id IS NULL"""
    ).fetchall()

    clear_cut = []
    ambiguous = []
    for pid, name, aisle_id, count, rr, avg_basket in all_products:
        if has_name_or_aisle_signal(name, aisle_id):
            clear_cut.append((pid, name, aisle_id))
        else:
            ambiguous.append((pid, name, aisle_id, count, rr, avg_basket))

    print(f"{len(clear_cut):,} products have a clear name/aisle signal — tagging via rules.")
    for pid, name, aisle_id in clear_cut:
        household, source = classify_by_rule(name, aisle_id)
        save_tag(conn, pid, household, classify_convenience(aisle_id), source, now)
    conn.commit()

    print(f"{len(ambiguous):,} products are genuinely ambiguous — sending ALL of them to cloud LLMs.")
    ambiguous.sort(key=lambda row: row[3], reverse=True)
    cloud_payload = [(pid, name, count, rr, avg_basket) for pid, name, aisle_id, count, rr, avg_basket in ambiguous]
    aisle_lookup = {pid: aisle_id for pid, name, aisle_id, count, rr, avg_basket in ambiguous}

    cloud_tagged = tag_products_cloud(cloud_payload)
    print(f"Cloud LLMs tagged {cloud_tagged:,}/{len(ambiguous):,} products.")

    conn.commit()
    tagged_by_cloud = {r[0] for r in conn.execute(
        "SELECT product_id FROM product_tags WHERE tag_source IN ('llm_groq', 'llm_sambanova')"
    )}
    for pid in tagged_by_cloud:
        if pid in aisle_lookup:
            conn.execute(
                "UPDATE product_tags SET convenience = ? WHERE product_id = ?",
                (classify_convenience(aisle_lookup[pid]), pid),
            )
    conn.commit()

    remaining = [row for row in ambiguous if row[0] not in tagged_by_cloud]
    if remaining:
        print(f"{len(remaining):,} products not reached by cloud LLMs — using basket-size fallback.")
        threshold = get_family_threshold(conn)
        for pid, name, aisle_id, count, rr, avg_basket in remaining:
            household = "family" if avg_basket >= threshold else "solo"
            save_tag(conn, pid, household, classify_convenience(aisle_id), "fallback_basket_size", now)
        conn.commit()

    print("\n=== Tag source breakdown ===")
    total = conn.execute("SELECT COUNT(*) FROM product_tags").fetchone()[0]
    for source, count in conn.execute(
        "SELECT tag_source, COUNT(*) FROM product_tags GROUP BY tag_source ORDER BY COUNT(*) DESC"
    ):
        print(f"  {source:22} {count:6,} ({count/total:5.1%})")

    conn.close()


if __name__ == "__main__":
    run()
