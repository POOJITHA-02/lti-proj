import re
import statistics
from datetime import datetime

from db import get_connection, init_db

FAMILY_NAME_PATTERNS = re.compile(
    r"family size|value pack|bulk|jumbo|\b\d{2,}\s*ct\b|\b\d{2,}\s*pack\b|party size|club pack",
    re.IGNORECASE,
)
SOLO_NAME_PATTERNS = re.compile(
    r"single serve|single-serve|mini\b|snack size|individual|travel size|\bsolo\b|on.the.go",
    re.IGNORECASE,
)

# Aisles that strongly imply family/household purchasing regardless of product name
# (diapers, baby food, pet food, etc. — Instacart aisle_ids)
FAMILY_AISLES = {56, 82, 102, 129, 132, 133}

# Aisles that are raw/needs-cooking ingredients rather than ready-to-eat
RAW_INGREDIENT_AISLES = {
    83, 86, 131,   # meat counter, seafood counter, poultry counter
    35, 42, 48,    # fresh vegetables, packaged produce, fresh fruits
    89, 96,        # baking ingredients, flour
}


def classify_household(name: str, aisle_id: int, avg_basket_size: float, threshold: float) -> str:
    if SOLO_NAME_PATTERNS.search(name):
        return "solo"
    if FAMILY_NAME_PATTERNS.search(name):
        return "family"
    if aisle_id in FAMILY_AISLES:
        return "family"
    return "family" if avg_basket_size >= threshold else "solo"


def classify_convenience(aisle_id: int) -> str:
    return "raw_ingredients" if aisle_id in RAW_INGREDIENT_AISLES else "ready_to_eat"


def get_family_threshold(conn) -> float:
    rows = [r[0] for r in conn.execute(
        "SELECT avg_basket_size_when_purchased FROM product_stats WHERE avg_basket_size_when_purchased > 0"
    )]
    return statistics.median(rows) if rows else 10.0


def run(overwrite: bool = False) -> None:
    init_db()
    conn = get_connection()
    now = datetime.utcnow().isoformat()
    threshold = get_family_threshold(conn)
    print(f"Using median basket-size threshold of {threshold:.1f} for the family/solo fallback.")

    rows = conn.execute(
        """SELECT p.product_id, p.product_name, p.aisle_id,
                  COALESCE(ps.avg_basket_size_when_purchased, 0)
           FROM products p
           LEFT JOIN product_stats ps ON p.product_id = ps.product_id"""
    ).fetchall()

    tagged = 0
    for pid, name, aisle_id, avg_basket in rows:
        if not overwrite:
            existing = conn.execute("SELECT 1 FROM product_tags WHERE product_id = ?", (pid,)).fetchone()
            if existing:
                continue

        household = classify_household(name, aisle_id, avg_basket, threshold)
        convenience = classify_convenience(aisle_id)
        source = (
            "rule_name" if (SOLO_NAME_PATTERNS.search(name) or FAMILY_NAME_PATTERNS.search(name))
            else "rule_aisle" if aisle_id in FAMILY_AISLES
            else "fallback_basket_size"
        )

        conn.execute(
            """INSERT INTO product_tags (product_id, household_orientation, convenience, tag_source, tagged_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(product_id) DO UPDATE SET
                   household_orientation = excluded.household_orientation,
                   convenience = excluded.convenience,
                   tag_source = excluded.tag_source,
                   tagged_at = excluded.tagged_at""",
            (pid, household, convenience, source, now),
        )
        tagged += 1

    conn.commit()
    print(f"Tagged {tagged:,} products.")

    print("\nhousehold_orientation distribution:")
    for r in conn.execute("SELECT household_orientation, COUNT(*) FROM product_tags GROUP BY household_orientation"):
        print(f"  {r[0]}: {r[1]:,} ({r[1]/max(tagged,1):.1%})")

    print("\nconvenience distribution:")
    for r in conn.execute("SELECT convenience, COUNT(*) FROM product_tags GROUP BY convenience"):
        print(f"  {r[0]}: {r[1]:,} ({r[1]/max(tagged,1):.1%})")

    conn.close()


if __name__ == "__main__":
    run()
