from pathlib import Path

import pandas as pd

from db import get_connection, init_db

RAW_DIR = Path(__file__).parent / "data" / "raw"


def load_reference_data(conn) -> None:
    departments = pd.read_csv(RAW_DIR / "departments.csv")
    aisles = pd.read_csv(RAW_DIR / "aisles.csv")
    products = pd.read_csv(RAW_DIR / "products.csv")

    departments.to_sql("departments", conn, if_exists="append", index=False)
    aisles.to_sql("aisles", conn, if_exists="append", index=False)
    products.to_sql("products", conn, if_exists="append", index=False)

    print(f"Loaded {len(departments)} departments, {len(aisles)} aisles, {len(products)} products")


def load_orders(conn, orders_file: str = "orders.csv") -> None:
    print(f"Loading {orders_file} into source_orders...")
    orders = pd.read_csv(RAW_DIR / orders_file)

    # 'test' orders have no order_products data anywhere in the dataset
    # (they're Kaggle's holdout set) — drop them, keep 'prior' + 'train'.
    before = len(orders)
    orders = orders[orders["eval_set"] != "test"]
    print(f"  {before:,} total rows -> {len(orders):,} after dropping eval_set='test'")

    orders.to_sql("source_orders", conn, if_exists="append", index=False)
    print(f"  {len(orders):,} orders loaded into source_orders")


def load_order_items(conn, order_products_file: str, chunksize: int = 200_000) -> None:
    print(f"Loading {order_products_file} into source_order_items (chunked)...")
    total = 0
    for chunk in pd.read_csv(RAW_DIR / order_products_file, chunksize=chunksize):
        chunk.to_sql("source_order_items", conn, if_exists="append", index=False)
        total += len(chunk)
        print(f"  ...{total:,} rows loaded")
    print(f"{order_products_file} done: {total:,} rows total.")


if __name__ == "__main__":
    init_db()
    conn = get_connection()

    load_reference_data(conn)
    load_orders(conn, orders_file="orders.csv")

    # Both files share the same schema and load into the same table —
    # together they cover every order kept in source_orders (prior + train).
    load_order_items(conn, "order_products__prior.csv")
    load_order_items(conn, "order_products__train.csv")

    conn.close()
    print("All 6 files loaded.")
