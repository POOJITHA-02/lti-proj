from pathlib import Path

import pandas as pd

from db import get_connection, init_db

RAW_DIR = Path(__file__).parent / "data" / "raw"


def load_reference_data(conn) -> None:
    departments = pd.read_csv(RAW_DIR / "departments.csv")
    aisles = pd.read_csv(RAW_DIR / "aisles.csv")
    products = pd.read_csv(RAW_DIR / "products.csv")

    departments.to_sql("departments", conn, if_exists="append", index=False)
    aisles.to_sql("aisles", conn, if_exists="append", index=False)
    products.to_sql("products", conn, if_exists="append", index=False)

    print(f"Loaded {len(departments)} departments, {len(aisles)} aisles, {len(products)} products")


def load_source_pool(conn, orders_file: str, order_products_file: str) -> None:
    print(f"Loading {orders_file} into source_orders...")
    orders = pd.read_csv(RAW_DIR / orders_file)
    orders.to_sql("source_orders", conn, if_exists="append", index=False)
    print(f"  {len(orders):,} orders loaded")

    print(f"Loading {order_products_file} into source_order_items (chunked)...")
    total = 0
    for chunk in pd.read_csv(RAW_DIR / order_products_file, chunksize=200_000):
        chunk.to_sql("source_order_items", conn, if_exists="append", index=False)
        total += len(chunk)
        print(f"  ...{total:,} rows loaded")

    print("Source pool ready.")


if __name__ == "__main__":
    init_db()
    conn = get_connection()

    load_reference_data(conn)

    # Swap to "order_products__prior.csv" once you've downloaded the full
    # Instacart dataset from Kaggle — train.csv is a smaller subset, good
    # for a fast first test run of the pipeline.
    load_source_pool(
        conn,
        orders_file="orders.csv",
        order_products_file="order_products__train.csv",
    )

    conn.close()
