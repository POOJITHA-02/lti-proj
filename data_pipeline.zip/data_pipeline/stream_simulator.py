import random
import time
from datetime import datetime

from db import get_connection

DELAY_SECONDS = 1.5   # gap between simulated buyers — set to 0 for a fast test run
RANDOM_SEED = 42      # fixed seed so the shuffle order is reproducible across restarts


def get_shuffled_order_ids(conn) -> list[int]:
    ids = [r[0] for r in conn.execute("SELECT order_id FROM source_orders ORDER BY order_id")]
    random.Random(RANDOM_SEED).shuffle(ids)
    return ids


def get_cursor(conn) -> int:
    return conn.execute("SELECT last_order_index FROM stream_state WHERE id = 1").fetchone()[0]


def set_cursor(conn, idx: int) -> None:
    conn.execute("UPDATE stream_state SET last_order_index = ? WHERE id = 1", (idx,))
    conn.commit()


def fetch_source_order(conn, order_id: int):
    return conn.execute(
        """SELECT order_id, user_id, order_number, order_dow,
                  order_hour_of_day, days_since_prior_order
           FROM source_orders WHERE order_id = ?""",
        (order_id,),
    ).fetchone()


def ingest_order(conn, order_row) -> tuple[int, int, float]:
    order_id, user_id, order_number, order_dow, order_hour, days_since_prior = order_row
    now = datetime.utcnow().isoformat()
    cur = conn.cursor()

    cur.execute(
        """INSERT INTO live_orders
           (order_id, user_id, order_number, order_dow, order_hour_of_day,
            days_since_prior_order, ingested_at)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (order_id, user_id, order_number, order_dow, order_hour, days_since_prior, now),
    )

    cur.execute(
        """INSERT INTO live_order_items (order_id, product_id, add_to_cart_order, reordered)
           SELECT order_id, product_id, add_to_cart_order, reordered
           FROM source_order_items WHERE order_id = ?""",
        (order_id,),
    )

    basket_size, reorder_ratio = cur.execute(
        "SELECT COUNT(*), AVG(reordered) FROM live_order_items WHERE order_id = ?",
        (order_id,),
    ).fetchone()

    conn.commit()
    return user_id, basket_size, reorder_ratio or 0.0


def update_customer_features(conn, user_id: int) -> None:
    total_orders, total_items, reorder_rate, avg_days, last_order_id = conn.execute(
        """SELECT COUNT(DISTINCT lo.order_id),
                  COUNT(li.product_id),
                  AVG(li.reordered),
                  AVG(lo.days_since_prior_order),
                  MAX(lo.order_id)
           FROM live_orders lo
           JOIN live_order_items li ON lo.order_id = li.order_id
           WHERE lo.user_id = ?""",
        (user_id,),
    ).fetchone()

    avg_basket_size = total_items / total_orders if total_orders else 0
    now = datetime.utcnow().isoformat()

    conn.execute(
        """INSERT INTO customer_features
               (user_id, total_orders, total_items, avg_basket_size, reorder_rate,
                avg_days_between_orders, last_order_id, last_ingested_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(user_id) DO UPDATE SET
               total_orders = excluded.total_orders,
               total_items = excluded.total_items,
               avg_basket_size = excluded.avg_basket_size,
               reorder_rate = excluded.reorder_rate,
               avg_days_between_orders = excluded.avg_days_between_orders,
               last_order_id = excluded.last_order_id,
               last_ingested_at = excluded.last_ingested_at,
               updated_at = excluded.updated_at""",
        (user_id, total_orders, total_items, avg_basket_size, reorder_rate or 0,
         avg_days or 0, last_order_id, now, now),
    )
    conn.commit()


def run() -> None:
    conn = get_connection()
    order_ids = get_shuffled_order_ids(conn)
    total = len(order_ids)
    idx = get_cursor(conn)

    print(f"Live stream simulator started at position {idx}/{total}. Ctrl+C to stop.")

    try:
        while idx < total:
            order_id = order_ids[idx]
            order_row = fetch_source_order(conn, order_id)

            user_id, basket_size, reorder_ratio = ingest_order(conn, order_row)
            update_customer_features(conn, user_id)
            idx += 1
            set_cursor(conn, idx)

            print(
                f"[{datetime.utcnow().strftime('%H:%M:%S')}] "
                f"order {order_id} ingested — user {user_id}, "
                f"basket size {basket_size}, reorder ratio {reorder_ratio:.2f} "
                f"| progress {idx}/{total}"
            )
            time.sleep(DELAY_SECONDS)

        print("All historical orders ingested. Stream exhausted.")
    except KeyboardInterrupt:
        print(f"\nStopped at position {idx}/{total}. Cursor saved — rerun to resume.")
    finally:
        conn.close()


if __name__ == "__main__":
    run()
