# Before you send this prompt

A new chat does not have my files. Attach these as zips first (code only):

- `data_pipeline/` — all `.py` files, `schema.sql`, READMEs, requirements files
- `webapp_v2/` — the whole `app/` folder, `requirements.txt`, `.env.example`, `README.md`

**Do NOT attach:** `venv/`, `*.db`, `data/raw/*.csv`, `mlruns/`, `mlflow.db`, `.env` (contains real keys).

---

# PROMPT (copy everything below this line)

## Role and goal

You are a senior data/ML engineer helping me finish a portfolio project. My working code is attached as zips. Your job is to turn it into one clean, reproducible GitHub repository that a reviewer can clone and run with a single `docker compose up --build`, plus a documented local (non-Docker) path for Windows.

Harden and connect what exists. Do not rebuild working parts from scratch or restyle the UI.

## Project: Signature-Driven Inventory — Profiling Shopper Behavior From Basket Data

**Problem:** Retail inventory decisions rely on aggregate demand instead of underlying shopping patterns, causing overstocking and underserving.

**Dataset:** Instacart Market Basket Analysis (Kaggle) — 6 CSVs: `orders.csv` (~3.4M orders), `order_products__prior.csv` (~32M rows), `order_products__train.csv`, `products.csv` (49,688), `aisles.csv` (134), `departments.csv` (21). `eval_set='test'` orders are dropped (no basket data).

**Five shopper-signature dimensions:**

| Dimension | Values | How it is derived |
|---|---|---|
| household_orientation | solo / family | Per product: name regex → family aisles → LLM → basket-size fallback |
| convenience | ready_to_eat / raw_ingredients | Per product: deterministic aisle mapping |
| shopping_mission | topup / stockup | Per shopper: rule on `customer_features` |
| basket_behavior | small / large | Per shopper: rule on `avg_basket_size` |
| purchase_behavior | routine / exploration | Per shopper: rule on `reorder_rate` |

Every product tag carries a `tag_source`: `rule_name`, `rule_aisle`, `llm` (local Ollama), `llm_groq`, `llm_sambanova`, or `fallback_basket_size`.

**Current pipeline (run order):**

1. `load_reference_data.py` — loads CSVs into `source_*` tables (idempotent via `load_manifest`)
2. `stream_simulator.py` — `MODE="bulk"` copies history into `live_*` tables and computes `customer_features`
3. `backdate_synthetic_dates.py` — spreads orders across simulated months (Instacart has no real dates)
4. `compute_product_stats.py` — purchase_count, reorder_rate, avg_basket_size_when_purchased per product
5. `hybrid_tagging.py` — rules first, then Groq + SambaNova concurrently (`cloud_tagging.py`), fallback for anything unreached; re-targets `fallback_basket_size` rows for upgrade
6. `pattern_discovery.py` — UMAP + K-Means / GMM / Hierarchical / DBSCAN, MLflow-tracked, best model written to `shopper_signatures`
7. `advanced_cluster_analysis.py` — silhouette k-sweep, bootstrap ARI stability, surrogate decision-tree feature importance
8. `comparative_analysis.py` — department/aisle mix and reorder behavior per cluster (CSV outputs)
9. `live_order_generator.py` — long-running; generates new synthetic orders one at a time and updates `customer_features`

**Web app (FastAPI + Jinja2 + vanilla JS):**

- Auth: signup → 6-digit OTP via Gmail SMTP (App Password; prints to console when SMTP is unset) → verify → login (JWT in HttpOnly cookie) → forgot/reset password → change password
- Pages: Dashboard (5 signature filters, cluster charts, polling live order feed), Trends (month-year → month-year % change as percentage points and relative %, single-month snapshot, donut composition), Shopper Lookup, Insights (auto-generated per-cluster recommendations), Compare (two clusters head-to-head), Account
- Design: black/red gradient glassmorphism, CSS-only 3D floating objects, Chart.js bundled locally (external CDNs are blocked on my network)
- Two databases: `app.db` (SQLAlchemy, auth users) and `instacart.db` (sqlite3 analytics; the web app opens it read-only)

## Hard environment constraints

- Windows office laptop, CPU-only, low RAM, restricted network (external CDNs blocked)
- Available: Python venv, VS Code, DB Browser for SQLite, Docker Desktop, Power BI Desktop
- No Power BI Service/Pro and no Azure, so no Power BI Embedded. The in-app dashboard uses native charts; Power BI Desktop is a separate deliverable
- No Postgres, Redis, Kafka, or Celery. SQLite only
- Local Ollama is too slow (~86 s/product). LLM tagging uses Groq + SambaNova **free tiers only**, keys read from `.env`
- Zero paid services anywhere

## Known issues you must fix (found in my own testing)

1. **`shopping_mission` and `basket_behavior` are identical.** In `pattern_discovery.py` both are `avg_basket_size >= 15`. Redefine `shopping_mission` from trip frequency plus basket size (for example, stock-up = long `avg_days_between_orders` and large basket; top-up = short gaps and small basket), derive thresholds from data quantiles instead of hardcoding, and rerun clustering.
2. **Fragile paths.** I hit `FileNotFoundError` from a `.parent` bug and `unicodeescape` errors from Windows backslash literals. Put all paths in one config module, resolved from the repo root or env vars. No hardcoded absolute paths.
3. **SQLite concurrency.** The generator writes while the web app reads. Enable WAL mode and `busy_timeout`. In Docker, keep the DB on a named volume, not a Windows bind mount (file locking is unreliable there).
4. **Env loading.** Every entrypoint must call `load_dotenv()`. One `.env.example` at the repo root documents every variable.
5. **Deprecations.** Replace every `datetime.utcnow()` with timezone-aware `datetime.now(timezone.utc)`.
6. **OTP security.** A 6-digit code with no attempt limit is brute-forceable. Add max 5 attempts then lockout, a 60-second resend cooldown, `SameSite=Lax` cookies (`Secure` when HTTPS), and print OTPs to console only when `DEBUG=true`.
7. **Dependency conflicts.** My global environment had protobuf/numpy clashes from TensorFlow. Pin Python 3.11, pin versions per component, no TensorFlow.
8. **Simulated dates.** Trends uses fabricated months. Label this clearly in the UI and README.
9. **Honest tag coverage.** Show the `tag_source` breakdown on the dashboard and in the README. Do not present fallback-derived tags as LLM output.

## Deliverables — one phase per response

**Phase 1 — Repo structure and config.** Proposed layout: `pipeline/`, `webapp/`, `powerbi/`, `scripts/`, `tests/`, `docs/`. Single `config.py`, root `.env.example`, `.gitignore` (venv, `.env`, `*.db`, `data/raw/`, `mlruns/`, `__pycache__/`), `pyproject.toml` or pinned requirements per component. Show me the final tree before moving any files.

**Phase 2 — Pipeline hardening.** Fix issues 1–5 and 9. Add a single orchestrator, `python -m pipeline.run --demo` or `--full`, that runs steps 1–8 in order, skips completed steps, and logs with `logging` instead of `print`.

**Phase 3 — Demo dataset.** The real CSVs cannot go to GitHub (`order_products__prior.csv` is ~550 MB; GitHub rejects files over 100 MB). Add a deterministic `scripts/make_demo_data.py` that generates a small synthetic dataset in the Instacart schema (target under 5 MB) so the whole app runs with no downloads and no API keys. Check the Instacart dataset's license before committing any real sample; default to synthetic.

**Phase 4 — Web app hardening.** Fix issue 6. Add a `/health` endpoint. Add a small "simulated data" banner on Trends. Keep the existing design unchanged.

**Phase 5 — Tests and CI.** pytest for: the auth flow via FastAPI `TestClient` (signup → OTP → login → protected page), tagging rules, the pipeline on demo data, and the Trends % math. GitHub Actions workflow runs tests plus `docker compose build`.

**Phase 6 — Docker.** `Dockerfile` (slim Python 3.11, non-root user) and `docker-compose.yml` with:
- `pipeline`: one-shot init on demo data by default
- `generator`: long-running `live_order_generator.py`, starts after `pipeline` completes
- `web`: uvicorn on port 8000 with a healthcheck
- `mlflow`: optional, behind a compose profile

Shared named volume for `instacart.db`. Must work with zero API keys (tagging falls back to rules). Include the Windows Docker Desktop notes I need.

**Phase 7 — Power BI.** `powerbi/export_powerbi.py` writes star-schema CSVs: `fact_order_items`, `fact_orders`, `dim_product` (with tags and `tag_source`), `dim_shopper` (signatures and cluster), `dim_department`, `dim_aisle`, `dim_date` (simulated). Include a `measures.dax` file and a step-by-step build guide for Power BI Desktop via CSV import (no ODBC driver, since I may not be allowed to install one). You cannot create a `.pbix` file; say so rather than pretending.

**Phase 8 — GitHub.** README with problem statement, a Mermaid architecture diagram, screenshot placeholders, Docker quick start, Windows local setup, pipeline explanation, results, and an honest Limitations section. Add a LICENSE, then give me the exact PowerShell git commands to init, commit, create the remote, and push.

## Acceptance criteria

- `git clone` → `copy .env.example .env` → `docker compose up --build` → open `http://localhost:8000` → sign up → OTP appears in `docker compose logs web` → log in → all 7 pages render with data, no browser console errors, no external network calls
- The local Windows PowerShell path works with documented commands
- `pytest` passes and CI is green
- No secrets or `.db` files committed; repo size under 20 MB
- Every issue in "Known issues" is fixed, or explicitly marked as a documented limitation

## Working rules

1. One phase per response. End each phase with: files changed, PowerShell commands to run, how to verify, and what you could not verify. Wait for me to say "continue".
2. Give full contents for any file you create or change. No diffs, no `...` placeholders.
3. Preserve working behavior and the UI design. Refactor only what the phase requires.
4. You cannot push to my GitHub or run Docker on my machine. Give me exact commands and I will run them.
5. If you cannot verify something (real Groq/SambaNova calls, Docker on Windows, SMTP delivery), say so plainly instead of claiming it works.
6. Ask before adding any new infrastructure, paid service, or heavy dependency.
7. Prefer honest, critical assessments. If a design choice in my code is weak, say so and propose a fix.

Start with Phase 1.
