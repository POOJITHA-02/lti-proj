"""
Hybrid product tagging — rules where they're reliable, LLM where they're not.

Design: rule_based_tagging.py showed that only ~8.5% of products get a real signal
from name patterns or aisle (household_orientation). The other ~91.5% were falling
back to a weak basket-size heuristic. This script keeps the fast rule pass for the
cases it's actually good at, and sends ONLY the genuinely ambiguous cases to the LLM
— capped to the highest-purchase-count ones, so total LLM work stays small enough
for low-capacity/CPU-only hardware while still meaningfully using it.

Every product gets a tag_source so you can report exactly what fraction came from
rules vs LLM vs fallback, instead of leaving that hidden.
"""

from datetime import datetime

from db import get_connection, init_db
from llm_feature_engineering import tag_batch
from rule_based_tagging import (
    FAMILY_AISLES,
    FAMILY_NAME_PATTERNS,
    SOLO_NAME_PATTERNS,
    classify_convenience,
    get_family_threshold,
)

LLM_CAP = 300  # how many ambiguous products get sent to the LLM — raise this once you've
               # timed a small batch and know your hardware's real per-call speed


def has_name_or_aisle_signal(name: str, aisle_id: int) -> bool:
    return bool(
        SOLO_NAME_PATTERNS.search(name)
        or FAMILY_NAME_PATTERNS.search(name)
        or aisle_id in FAMILY_AISLES
    )


def classify_by_rule(name: str, aisle_id: int) -> tuple[str, str]:
    """Only called when has_name_or_aisle_signal() is True — returns (household_orientation, source)."""
    if SOLO_NAME_PATTERNS.search(name):
        return "solo", "rule_name"
    if FAMILY_NAME_PATTERNS.search(name):
        return "family", "rule_name"
    return "family", "rule_aisle"  # must be the FAMILY_AISLES case


def save_tag(conn, product_id: int, household: str, convenience: str, source: str, now: str) -> None:
    conn.execute(
        """INSERT INTO product_tags (product_id, household_orientation, convenience, tag_source, tagged_at)
           VALUES (?, ?, ?, ?, ?)
           ON CONFLICT(product_id) DO UPDATE SET
               household_orientation = excluded.household_orientation,
               convenience = excluded.convenience,
               tag_source = excluded.tag_source,
               tagged_at = excluded.tagged_at""",
        (product_id, household, convenience, source, now),
    )


def run() -> None:
    init_db()
    conn = get_connection()
    now = datetime.utcnow().isoformat()

    all_products = conn.execute(
        """SELECT p.product_id, p.product_name, p.aisle_id,
                  COALESCE(ps.purchase_count, 0), COALESCE(ps.reorder_rate, 0.0),
                  COALESCE(ps.avg_basket_size_when_purchased, 0.0)
           FROM products p
           LEFT JOIN product_stats ps ON p.product_id = ps.product_id"""
    ).fetchall()

    clear_cut = []
    ambiguous = []
    for pid, name, aisle_id, count, rr, avg_basket in all_products:
        if has_name_or_aisle_signal(name, aisle_id):
            clear_cut.append((pid, name, aisle_id))
        else:
            ambiguous.append((pid, name, aisle_id, count, rr, avg_basket))

    print(f"{len(clear_cut):,} products have a clear name/aisle signal — tagging via rules.")
    for pid, name, aisle_id in clear_cut:
        household, source = classify_by_rule(name, aisle_id)
        save_tag(conn, pid, household, classify_convenience(aisle_id), source, now)
    conn.commit()

    # Send the highest-purchase-count ambiguous products to the LLM first — that's
    # where getting it right actually matters most for downstream clustering.
    ambiguous.sort(key=lambda row: row[3], reverse=True)
    llm_batch = ambiguous[:LLM_CAP]
    fallback_batch = ambiguous[LLM_CAP:]

    print(f"{len(ambiguous):,} products are genuinely ambiguous (no name/aisle signal).")
    print(f"  -> sending top {len(llm_batch):,} (by purchase_count) to the LLM...")

    llm_tagged = 0
    for pid, name, aisle_id, count, rr, avg_basket in llm_batch:
        result = tag_batch([(pid, name, count, rr, avg_basket)])
        if result:
            household = result[0].get("household_orientation", "solo")
            save_tag(conn, pid, household, classify_convenience(aisle_id), "llm", now)
            llm_tagged += 1
        if llm_tagged % 25 == 0 and llm_tagged > 0:
            conn.commit()
            print(f"    ...{llm_tagged}/{len(llm_batch)} LLM-tagged")
    conn.commit()
    print(f"  {llm_tagged}/{len(llm_batch)} tagged successfully via LLM.")

    print(f"  -> remaining {len(fallback_batch):,} ambiguous products use the basket-size fallback.")
    threshold = get_family_threshold(conn)
    for pid, name, aisle_id, count, rr, avg_basket in fallback_batch:
        household = "family" if avg_basket >= threshold else "solo"
        save_tag(conn, pid, household, classify_convenience(aisle_id), "fallback_basket_size", now)
    conn.commit()

    print("\n=== Tag source breakdown ===")
    total = len(all_products)
    for source, count in conn.execute(
        "SELECT tag_source, COUNT(*) FROM product_tags GROUP BY tag_source ORDER BY COUNT(*) DESC"
    ):
        print(f"  {source:22} {count:6,} ({count/total:5.1%})")

    conn.close()


if __name__ == "__main__":
    run()
