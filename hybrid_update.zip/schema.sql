-- ============================================================
-- Reference / dimension tables — static, loaded once
-- ============================================================
CREATE TABLE IF NOT EXISTS departments (
    department_id INTEGER PRIMARY KEY,
    department TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS aisles (
    aisle_id INTEGER PRIMARY KEY,
    aisle TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS products (
    product_id INTEGER PRIMARY KEY,
    product_name TEXT NOT NULL,
    aisle_id INTEGER REFERENCES aisles(aisle_id),
    department_id INTEGER REFERENCES departments(department_id)
);

-- ============================================================
-- Source pool (landing zone) — the full historical dataset,
-- loaded once via batch ingestion. Represents orders that
-- exist but have not yet been "seen" by the live system.
-- ============================================================
CREATE TABLE IF NOT EXISTS source_orders (
    order_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    eval_set TEXT,
    order_number INTEGER,
    order_dow INTEGER,
    order_hour_of_day INTEGER,
    days_since_prior_order REAL
);
CREATE INDEX IF NOT EXISTS idx_source_orders_user ON source_orders(user_id);

CREATE TABLE IF NOT EXISTS source_order_items (
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    add_to_cart_order INTEGER,
    reordered INTEGER,
    PRIMARY KEY (order_id, product_id)
);

-- ============================================================
-- Live tables — populated incrementally by the stream
-- simulator, one order at a time, as if each buyer just
-- checked out.
-- ============================================================
CREATE TABLE IF NOT EXISTS live_orders (
    order_id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    order_number INTEGER,
    order_dow INTEGER,
    order_hour_of_day INTEGER,
    days_since_prior_order REAL,
    ingested_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_live_orders_user ON live_orders(user_id);

CREATE TABLE IF NOT EXISTS live_order_items (
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    add_to_cart_order INTEGER,
    reordered INTEGER,
    PRIMARY KEY (order_id, product_id)
);

-- ============================================================
-- Continuously-updated rolling aggregate per shopper.
-- This is the table your dashboard/API reads from.
-- ============================================================
CREATE TABLE IF NOT EXISTS customer_features (
    user_id INTEGER PRIMARY KEY,
    total_orders INTEGER DEFAULT 0,
    total_items INTEGER DEFAULT 0,
    avg_basket_size REAL DEFAULT 0,
    reorder_rate REAL DEFAULT 0,
    avg_days_between_orders REAL DEFAULT 0,
    last_order_id INTEGER,
    last_ingested_at TEXT,
    updated_at TEXT
);

-- ============================================================
-- Precomputed per-product purchase statistics — calculated
-- once from actual order data, then fed to the LLM alongside
-- the product name so tagging is grounded in real behavior,
-- not just name text.
-- ============================================================
CREATE TABLE IF NOT EXISTS product_stats (
    product_id INTEGER PRIMARY KEY REFERENCES products(product_id),
    purchase_count INTEGER,
    reorder_rate REAL,
    avg_basket_size_when_purchased REAL,
    computed_at TEXT
);

-- ============================================================
-- LLM-tagged product features — tagged once per product (not
-- per order). household_orientation and convenience are the
-- two dimensions an LLM can reasonably judge from product
-- name/aisle/department; shopping mission, purchase behavior,
-- and basket behavior are computed later from basket stats.
-- ============================================================
CREATE TABLE IF NOT EXISTS product_tags (
    product_id INTEGER PRIMARY KEY REFERENCES products(product_id),
    household_orientation TEXT,   -- 'solo' or 'family'
    convenience TEXT,             -- 'ready_to_eat' or 'raw_ingredients'
    tag_source TEXT,              -- 'rule_name' | 'rule_aisle' | 'llm' | 'fallback_basket_size'
    tagged_at TEXT NOT NULL
);

-- ============================================================
-- Shopper signatures — the final per-user feature set (rule-
-- based dimensions + aggregated LLM tags) plus cluster
-- assignment from pattern discovery. This is what the
-- dashboard/comparative analysis reads from.
-- ============================================================
CREATE TABLE IF NOT EXISTS shopper_signatures (
    user_id INTEGER PRIMARY KEY REFERENCES customer_features(user_id),
    household_orientation TEXT,   -- 'solo' or 'family' (aggregated from product_tags)
    convenience TEXT,             -- 'ready_to_eat' or 'raw_ingredients' (aggregated)
    shopping_mission TEXT,        -- 'topup' or 'stockup' (rule-based, from avg_basket_size)
    purchase_behavior TEXT,       -- 'routine' or 'exploration' (rule-based, from reorder_rate)
    basket_behavior TEXT,         -- 'small' or 'large' (rule-based, from avg_basket_size)
    cluster_label INTEGER,        -- assigned by the chosen clustering algorithm
    algorithm TEXT,               -- which algorithm produced this run's cluster_label
    computed_at TEXT
);

-- ============================================================
-- Product purchase stats — computed once from source_order_items,
-- fed into the LLM prompt alongside the product name so tagging
-- is grounded in real purchase behavior, not name text alone.
-- ============================================================
CREATE TABLE IF NOT EXISTS product_stats (
    product_id INTEGER PRIMARY KEY REFERENCES products(product_id),
    purchase_count INTEGER,
    reorder_rate REAL,
    avg_basket_size_when_purchased REAL,
    computed_at TEXT
);

-- ============================================================
-- Load manifest — tracks which raw files have already been
-- ingested, so re-running load_reference_data.py is safe and
-- doesn't re-insert (and collide on) already-loaded data.
-- ============================================================
CREATE TABLE IF NOT EXISTS load_manifest (
    filename TEXT PRIMARY KEY,
    rows_loaded INTEGER,
    loaded_at TEXT
);

-- ============================================================
-- Stream cursor — lets the simulator stop and resume without
-- replaying orders it already ingested.
-- ============================================================
CREATE TABLE IF NOT EXISTS stream_state (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    last_order_index INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO stream_state (id, last_order_index) VALUES (1, 0);
