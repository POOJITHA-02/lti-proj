# UPI Reliability Analytics — Forecasting, Live Change-Point Detection & Risk Scoring

Three modules that run directly on top of the `npci_upi.db` database produced by
the ingestion pipeline.

## What changed in this version
- **Every bank is now included**, not just ones with 6+ months of history.
  Sparse-history banks fall back to a naive forecast (last known value carried
  forward) rather than being silently excluded.
- **Forecasting is date-aware**: it checks today's real date and forecasts the
  current month + next month relative to *today*, skipping straight past any
  gap if a bank's data is stale (rather than forecasting every missing month
  in between).
- **Custom month/year queries**: ask for a forecast for any specific future
  month for one bank, not just the default near-term pair. Requests further
  out than the immediate next month get an explicit warning that the estimate
  is provisional and may change materially once more real data is published.
- **Change-point detection is now "live"**: alongside detecting shifts already
  confirmed by real historical data, it also checks the forecasted current/next
  month against each bank's recent baseline and flags an **emerging** shift if
  it deviates meaningfully - clearly marked `is_provisional=True` with a
  warning, distinguished from confirmed real-data shifts.

## On upsampling — still not needed
Row count isn't the constraint here - per-bank time-series length is. See the
in-code comments in `config.py` and `forecasting.py` for the full reasoning.

## 1. Install
```
pip install -r requirements.txt
```

## 2. Requires
`npci_upi.db` (from the ingestion pipeline) in the **same folder** as this
project, containing the `upi_remitter_stats` table.

## 3. Run everything (batch mode, all banks)
```
python run_all_analytics.py
```
Produces three CSVs:
- `forecast_results.csv` — current-month + next-month prediction per bank (Prophet + naive baseline comparison), for ALL banks
- `changepoint_results.csv` — confirmed shifts (real data) AND emerging shifts (forecast-based, provisional) in one combined table
- `risk_scores.csv` — volume-weighted Impact Score per bank-month, ranked

## 4. Custom single-bank, single-month query
```
python analytics/forecasting.py "STATE BANK OF INDIA" 2027-03
```
Prints the last real data update, the forecast for exactly that month, and a
warning if the request is far enough ahead to be considered long-range
(controlled by `LONG_RANGE_WARNING_THRESHOLD_MONTHS` in `forecasting.py`).

Example output:
```
Bank: STATE BANK OF INDIA
Last real data update: 2026-06 (0.24%)
Forecast for 2027-03: 0.276% (range: 0% - 0.66%)

WARNING: This is a long-range forecast beyond the immediate next month...
```

## 5. What each module does

### Forecasting (`analytics/forecasting.py`)
- `run_forecasting_for_all_banks()` — default batch behavior, current + next month, every bank.
- `query_single_bank_forecast(bank_name, target_month)` — the custom query described above.
- `get_forecast_for_month(series, target_month=None)` — the shared core function both use.
- Backtests Prophet vs. a naive baseline on real held-out months wherever there's
  enough history to do so honestly (real finding on this dataset: Prophet only
  beats naive ~31% of the time - reported honestly, not hidden).
- Forecasts are clipped to a valid 0-100% range.
- Any Prophet/Stan fitting failure (e.g. pathological input data) falls back
  to a naive forecast instead of crashing the batch - see the try/except in
  `_fit_prophet` and the top-level safety net in `run_forecasting_for_all_banks`.

### Change-Point Detection (`analytics/changepoint.py`)
- **Confirmed shifts**: PELT (primary) + Binary Segmentation (comparison) on
  real historical data only.
- **Emerging shifts** (the "live" part): a dedicated z-score deviation check
  comparing the forecasted current/next month against each bank's recent
  6-month baseline. This is intentionally a *separate* mechanism from PELT -
  PELT cannot detect a shift inside only 1-2 forecasted points, since it needs
  at least `MIN_SEGMENT_SIZE` points to form a valid segment there.
- Both types land in one combined table, distinguished by `is_provisional`
  (False = confirmed by real data, True = based on an unconfirmed forecast).
- Tune sensitivity via `EMERGING_SHIFT_Z_THRESHOLD` in `changepoint.py` (default 1.5).

### Risk Scoring (`analytics/risk_scoring.py`)
- `Impact Score = decline_rate (%) x volume_share (%)` - unchanged, still a
  transparent formula rather than a trained model, appropriate for a
  compliance-monitoring context.

## 6. Config you can change (`analytics/config.py`)
- `TARGET_METRIC` — `td_pct` (default) or `bd_pct`.
- `MIN_MONTHS_REQUIRED` — minimum history before *backtesting* is attempted
  (all banks still get a forecast attempt regardless).
- `BACKTEST_HOLDOUT_MONTHS` — how many recent months held out for accuracy testing.

In `analytics/forecasting.py`:
- `LONG_RANGE_WARNING_THRESHOLD_MONTHS` — how many months beyond "next month"
  before a custom query gets flagged as long-range.

In `analytics/changepoint.py`:
- `EMERGING_SHIFT_Z_THRESHOLD` — how many standard deviations a forecast must
  deviate from baseline to be flagged as an emerging shift.
- `RECENT_BASELINE_MONTHS` — how many recent real months define "normal" for
  that comparison.
