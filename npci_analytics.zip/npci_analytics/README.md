# UPI Reliability Analytics — Forecasting, Live Change-Point Detection & Risk Scoring

Three modules that run directly on top of the `npci_upi.db` database produced by
the ingestion pipeline.

## Critical fix in this version: bank-name fragmentation was corrupting forecasts
Found via real-data investigation: 19 banks (including ICICI, Federal Bank,
IDBI, IDFC First, Airtel Payments Bank) appeared under 2-3 different name
variants across source files (e.g. "AIRTEL PAYMENTS BANK" vs "AIRTEL
PAYMENTS BANK LTD" vs "AIRTEL PAYMENTS BANK LIMITED"). Each variant was
treated as a SEPARATE bank with only a few fragmented months of history,
which caused forecasting to extrapolate wildly implausible values - a real
observed case predicted 42.5% TD for a bank whose actual historical maximum
was 2.4%, purely because the forecast was built on a 5-month fragment
instead of the bank's real 29-month history.

**Fixed with two layers of defense** (`analytics/data_loader.py`,
`analytics/forecasting.py`):
1. `normalize_bank_name()` merges known corporate-suffix variants (LTD,
   LIMITED, PVT LTD) into one canonical bank identity before any analysis runs.
2. Prophet now requires at least `MIN_MONTHS_REQUIRED` (6) real months before
   attempting a fit - fewer than that falls back to the naive forecast, which
   is more honest than an unreliable extrapolation from 2-3 points.
3. A documented sanity ceiling (`FORECAST_SANITY_CEILING`) clamps any
   remaining implausible forecast and logs it clearly, based on real evidence
   (NPCI's official TD target is <1%, BD target is <5%; see the RAG module's
   domain-knowledge base for full sourcing).

**One known remaining edge case**: a small number of banks that underwent a
genuine institutional rebrand (e.g. a regional Gramin bank restructured under
a larger bank's name) appear under names too different for automatic suffix-
stripping to merge (e.g. "Baroda Uttar Pradesh Grameen Bank" -> "Baroda U.P.
Bank"). These are NOT silently hidden - the output's `months_of_history` and
`forecast_method` columns make it immediately visible when a bank's forecast
is based on limited data, so this remains transparent even where the
automatic fix doesn't fully resolve a rename.

## What changed in this version
- **Every bank is now included**, not just ones with 6+ months of history.
  Sparse-history banks fall back to a naive forecast (last known value carried
  forward) rather than being silently excluded.
- **Forecasting is date-aware**: it checks today's real date and forecasts the
  current month + next month relative to *today*, skipping straight past any
  gap if a bank's data is stale (rather than forecasting every missing month
  in between).
- **Custom month/year queries**: ask for a forecast for any specific future
  month for one bank, not just the default near-term pair. Requests further
  out than the immediate next month get an explicit warning that the estimate
  is provisional and may change materially once more real data is published.
- **Change-point detection is now "live"**: alongside detecting shifts already
  confirmed by real historical data, it also checks the forecasted current/next
  month against each bank's recent baseline and flags an **emerging** shift if
  it deviates meaningfully - clearly marked `is_provisional=True` with a
  warning, distinguished from confirmed real-data shifts.

## On upsampling — still not needed
Row count isn't the constraint here - per-bank time-series length is. See the
in-code comments in `config.py` and `forecasting.py` for the full reasoning.

## 1. Install
```
pip install -r requirements.txt
```

## 2. Requires
`npci_upi.db` (from the ingestion pipeline) in the **same folder** as this
project, containing the `upi_remitter_stats` table.

## 3. Run everything (batch mode, all banks, all metrics)
```
python run_all_analytics.py
```
This now runs forecasting + change-point detection across **four metrics**
(`td_pct`, `bd_pct`, `reversal_failure_pct`, `total_debit_reversal_count_mn`),
plus risk scoring for the three rate-style metrics. The default metric
(`td_pct`) keeps its original unsuffixed filenames for backward
compatibility with the RAG layer and dashboard; every other metric gets a
suffixed filename (e.g. `forecast_results_bd_pct.csv`).

To run a single metric on its own:
```
python analytics/forecasting.py --metric reversal_failure_pct
python analytics/changepoint.py --metric total_debit_reversal_count_mn
python analytics/risk_scoring.py --metric bd_pct
```

### New metric: reversal_failure_pct
A derived column (`100 - debit_reversal_success_pct`, computed in
`data_loader.load_bank_data()`), reframing the raw "success %" field already
in the source data as a "higher = worse" failure rate - directly comparable
to td_pct/bd_pct for forecasting and change-point detection, rather than
needing separate "higher = better" logic throughout the pipeline.

### New metric: total_debit_reversal_count_mn
A raw count/volume metric, not a percentage. Forecasting and change-point
detection both work on it unchanged (Prophet and PELT don't care about
scale), but the percentage-style sanity ceiling (`FORECAST_SANITY_CEILING`)
does not apply to it - only non-negativity is enforced, since a large bank
can genuinely have tens of millions of reversals. Not included in risk
scoring, since the Impact Score formula (`decline_rate x volume_share`) is
built for rate-style metrics, not raw counts.

### Real finding validating the pipeline
Testing on the real dataset surfaced a genuine, severe anomaly: Kotak
Mahindra Bank's actual reversal success rate collapsed from ~89% to 2.75%
(Feb 2025), then 0.94% (Mar), then 1.20% (Apr) - a real 3-month
reversal-processing breakdown - before recovering to 97%+ by June. This is
exactly the kind of event the change-point detection is built to catch, and
it did, confirming the pipeline works correctly on real, messy production data.

## 4. Custom single-bank, single-month query
```
python analytics/forecasting.py "STATE BANK OF INDIA" 2027-03
```
Prints the last real data update, the forecast for exactly that month, and a
warning if the request is far enough ahead to be considered long-range
(controlled by `LONG_RANGE_WARNING_THRESHOLD_MONTHS` in `forecasting.py`).

Example output:
```
Bank: STATE BANK OF INDIA
Last real data update: 2026-06 (0.24%)
Forecast for 2027-03: 0.276% (range: 0% - 0.66%)

WARNING: This is a long-range forecast beyond the immediate next month...
```

## 5. What each module does

### Forecasting (`analytics/forecasting.py`)
- `run_forecasting_for_all_banks()` — default batch behavior, current + next month, every bank.
- `query_single_bank_forecast(bank_name, target_month)` — the custom query described above.
- `get_forecast_for_month(series, target_month=None)` — the shared core function both use.
- Backtests Prophet vs. a naive baseline on real held-out months wherever there's
  enough history to do so honestly (real finding on this dataset: Prophet only
  beats naive ~31% of the time - reported honestly, not hidden).
- Forecasts are clipped to a valid 0-100% range.
- Any Prophet/Stan fitting failure (e.g. pathological input data) falls back
  to a naive forecast instead of crashing the batch - see the try/except in
  `_fit_prophet` and the top-level safety net in `run_forecasting_for_all_banks`.

### Change-Point Detection (`analytics/changepoint.py`)
- **Confirmed shifts**: PELT (primary) + Binary Segmentation (comparison) on
  real historical data only.
- **Emerging shifts** (the "live" part): a dedicated z-score deviation check
  comparing the forecasted current/next month against each bank's recent
  6-month baseline. This is intentionally a *separate* mechanism from PELT -
  PELT cannot detect a shift inside only 1-2 forecasted points, since it needs
  at least `MIN_SEGMENT_SIZE` points to form a valid segment there.
- Both types land in one combined table, distinguished by `is_provisional`
  (False = confirmed by real data, True = based on an unconfirmed forecast).
- Tune sensitivity via `EMERGING_SHIFT_Z_THRESHOLD` in `changepoint.py` (default 1.5).

### Risk Scoring (`analytics/risk_scoring.py`)
- `Impact Score = decline_rate (%) x volume_share (%)` - unchanged, still a
  transparent formula rather than a trained model, appropriate for a
  compliance-monitoring context.
- Handles real-world data gaps safely: a bank-month with a missing decline
  rate, or a month with zero/missing total volume (division-by-zero), now
  produces a missing Impact Score and gets ranked last within that month -
  rather than crashing the whole batch run (this was a real bug found and
  fixed after testing against a larger 2020-2026 dataset with more historical
  gaps than the original 2024-2026 test data).

### Change-Point History Viewer (`view_changepoint_history.py`)
Browse the full change-point history with filters, without needing to open
the CSV manually:
```
python view_changepoint_history.py                                    # everything
python view_changepoint_history.py --direction WORSENED               # only worsening shifts
python view_changepoint_history.py --direction IMPROVED               # only improving shifts
python view_changepoint_history.py --bank "STATE BANK OF INDIA"       # one bank's full history
python view_changepoint_history.py --confirmed-only                    # exclude emerging/provisional
python view_changepoint_history.py --provisional-only                  # only emerging/provisional
```
Filters can be combined (e.g. `--direction WORSENED --bank "YES BANK LTD"`).
Prints a running WORSENED/IMPROVED count for whatever's currently filtered.


## 6. Config you can change (`analytics/config.py`)
- `TARGET_METRIC` — `td_pct` (default) or `bd_pct`.
- `MIN_MONTHS_REQUIRED` — minimum history before *backtesting* is attempted
  (all banks still get a forecast attempt regardless).
- `BACKTEST_HOLDOUT_MONTHS` — how many recent months held out for accuracy testing.

In `analytics/forecasting.py`:
- `LONG_RANGE_WARNING_THRESHOLD_MONTHS` — how many months beyond "next month"
  before a custom query gets flagged as long-range.

In `analytics/changepoint.py`:
- `EMERGING_SHIFT_Z_THRESHOLD` — how many standard deviations a forecast must
  deviate from baseline to be flagged as an emerging shift.
- `RECENT_BASELINE_MONTHS` — how many recent real months define "normal" for
  that comparison.

## 7. RAG Explanation Layer (`rag/`)

Generates a contextual explanation for every flagged shift (confirmed or
emerging) in `changepoint_results.csv`, grounded in a small curated corpus of
**real RBI/NPCI regulatory documents** - not fabricated content.

### Run it (after `run_all_analytics.py`)
```
python run_rag_explanations.py
```
Produces `rag_explanations.csv` - one row per flagged shift, with the
explanation text, which document(s) were retrieved, and the mode used.

### Two modes
- **Extractive (default, always works, zero cost)**: retrieves the most
  relevant document(s) from the corpus and presents their summary directly -
  no LLM call, no API key, no hallucination risk, since nothing is generated,
  only retrieved.
- **Grounded-generative (optional)**: if `ANTHROPIC_API_KEY` or
  `OPENAI_API_KEY` is set as an environment variable, an LLM rewrites the
  explanation more naturally - but the prompt strictly restricts it to the
  retrieved document text only, and instructs it to say so explicitly if
  nothing relevant was found rather than inventing a cause. This is a paid
  API call, unlike everything else in this project.

### Retrieval: sentence-transformers with automatic TF-IDF fallback
Semantic embeddings (`all-MiniLM-L6-v2`) give better retrieval quality, but
require downloading a model from huggingface.co - **this was tested and found
to be blocked in some restricted network environments** (a real risk on a
locked-down office laptop). The retriever automatically detects this and
falls back to local TF-IDF (scikit-learn, zero internet dependency) with no
code changes needed - you'll see a one-line notice printed either way, e.g.:
```
[RAG] Sentence-transformer model unavailable (...). Falling back to local TF-IDF retrieval...
```
To enable the higher-quality embedding path, install
`requirements-optional.txt` on a network that can reach huggingface.co.

### The document corpus (`rag/document_store.py`)
Five documents, each built from real, verifiable RBI/NPCI content
(paraphrased, with accurate source URLs and dates for citation):
1. RBI Master Directions on Cyber Resilience and Digital Payment Security
   Controls (30 July 2024)
2. NPCI circulars restricting UPI API call frequency after the April 2025
   system overload incident
3. Industry analysis (PwC) on UPI backend infrastructure strain from
   redundant API calls
4. The statutory basis (PSS Act, 2007) for RBI's oversight of payment system
   reliability
5. RBI's Digital Payments Index and Payment System Report, confirming decline
   rates are a formal tracked metric

**Honest scope, stated directly in the code and worth repeating in your
presentation**: no RBI/NPCI document publicly explains why one specific
bank's decline rate moved in one specific month. This layer surfaces
*relevant regulatory/industry context* that may plausibly relate to a flagged
anomaly's timing (e.g., a documented industry-wide API-overload incident) -
it is not proof of causation for any individual bank's numbers, and the
explanation wording reflects this distinction rather than overstating it.

### Query construction matters
Retrieval quality depends heavily on the query built from each anomaly - see
`_build_query()` in `rag/explain.py`. A generic query pulled the two least
useful documents in early testing; adding direction-specific keywords
(overload/downtime/outage for worsening shifts vs. compliance/governance for
improving ones) fixed this. Worth knowing if you add more documents later and
retrieval quality seems off - check the query terms first.

