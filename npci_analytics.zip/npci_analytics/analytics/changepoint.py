"""
Change-point detection module - finds the exact month a bank's reliability
trend genuinely shifted, as opposed to normal month-to-month noise.

Uses PELT (Pruned Exact Linear Time) via the `ruptures` library - the
standard, efficient algorithm for this exact task. Binary Segmentation is
also run for comparison, since presenting only one algorithm with no
comparison is a weaker methodological story.

"LIVE" BEHAVIOR:
  By default, this module appends the current-month and next-month
  FORECASTS (from forecasting.py) onto each bank's real historical series
  before running change-point detection. This means the detector can flag
  an emerging shift that starts in the forecasted period, not just shifts
  already fully confirmed by real data.

  Any change-point that falls inside the forecasted region is explicitly
  labeled is_provisional=True with a warning - it is based on a PREDICTION,
  not a confirmed real value, and may not materialize once the actual data
  for that month is published.
"""

import os
import sys
import pandas as pd
import numpy as np
import ruptures as rpt

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analytics.config import TARGET_METRIC, MIN_MONTHS_REQUIRED
from analytics.data_loader import load_bank_data, get_bank_series, get_all_bank_names
from analytics.forecasting import get_forecast_for_month

MIN_SEGMENT_SIZE = 3
PELT_PENALTY = 1.0

PROVISIONAL_WARNING = (
    "This is an EMERGING signal based on the forecasted current/next month, "
    "not yet confirmed by real data. It reflects the model's current trend "
    "projection and may not occur, or may occur differently, once the actual "
    "data for this month is published."
)

# How many standard deviations a forecasted month must deviate from the recent
# baseline average before it's flagged as an emerging shift. Note: PELT itself
# CANNOT detect a shift inside only 1-2 appended forecast points (it needs at
# least MIN_SEGMENT_SIZE points to form a valid segment) - so "live" detection
# of an emerging shift uses this dedicated, simpler deviation check instead.
EMERGING_SHIFT_Z_THRESHOLD = 1.5
RECENT_BASELINE_MONTHS = 6


def detect_changepoints_pelt(values):
    signal = np.array(values).reshape(-1, 1)
    algo = rpt.Pelt(model="rbf", min_size=MIN_SEGMENT_SIZE).fit(signal)
    breakpoints = algo.predict(pen=PELT_PENALTY)
    return breakpoints[:-1]


def detect_changepoints_binseg(values, n_bkps_guess=2):
    signal = np.array(values).reshape(-1, 1)
    algo = rpt.Binseg(model="rbf", min_size=MIN_SEGMENT_SIZE).fit(signal)
    try:
        breakpoints = algo.predict(n_bkps=n_bkps_guess)
        return breakpoints[:-1]
    except Exception:
        return []


def summarize_shift(series_df, breakpoint_idx, metric):
    """Describes a PELT-detected shift in REAL historical data only."""
    before = series_df[metric].iloc[:breakpoint_idx]
    after = series_df[metric].iloc[breakpoint_idx:]

    if len(before) == 0 or len(after) == 0:
        return None

    return {
        "change_month": series_df["date"].iloc[breakpoint_idx].strftime("%Y-%m"),
        "avg_before": round(before.mean(), 3),
        "avg_after": round(after.mean(), 3),
        "direction": "WORSENED" if after.mean() > before.mean() else "IMPROVED",
        "magnitude_pct_points": round(after.mean() - before.mean(), 3),
        "is_provisional": False,
        "warning": None,
    }


def detect_emerging_shift(series, metric):
    """
    Dedicated 'live' check: compares the forecasted current/next month against
    the recent real baseline, using a z-score style deviation test. This is
    separate from PELT because PELT structurally cannot detect a shift inside
    only 1-2 forecasted points - there simply aren't enough forecasted points
    to form a valid MIN_SEGMENT_SIZE-length segment there.

    Returns a list of flagged emerging-shift dicts (usually 0-2 - one per
    forecasted month), or an empty list if nothing deviates meaningfully.
    """
    try:
        forecast = get_forecast_for_month(series, target_month=None, metric=metric)
    except Exception:
        return []

    if forecast["forecast_method"] != "prophet":
        return []  # naive fallback has no meaningful trend/uncertainty to test against

    recent = series[metric].tail(RECENT_BASELINE_MONTHS)
    baseline_mean = recent.mean()
    baseline_std = recent.std()

    if baseline_std == 0 or pd.isna(baseline_std):
        return []

    flagged = []
    for f in forecast["forecasts"]:
        if f["forecast_value"] is None:
            continue
        z = (f["forecast_value"] - baseline_mean) / baseline_std
        if abs(z) >= EMERGING_SHIFT_Z_THRESHOLD:
            flagged.append({
                "change_month": f["forecast_month"],
                "avg_before": round(baseline_mean, 3),
                "avg_after": f["forecast_value"],
                "direction": "WORSENED" if f["forecast_value"] > baseline_mean else "IMPROVED",
                "magnitude_pct_points": round(f["forecast_value"] - baseline_mean, 3),
                "is_provisional": True,
                "warning": PROVISIONAL_WARNING,
                "z_score": round(z, 2),
            })
    return flagged


def run_changepoint_detection_for_all_banks(include_forecast=True, metric=TARGET_METRIC):
    """
    Main entry point. For every bank:
      1. Runs PELT + Binseg on REAL historical data only -> confirmed shifts.
      2. If include_forecast=True, also checks the forecasted current/next
         month against the recent baseline -> emerging (provisional) shifts.

    `metric`: which column to analyze - td_pct (default), bd_pct,
    reversal_failure_pct, or total_debit_reversal_count_mn.

    Both types are returned in one combined table, distinguished by
    `is_provisional` (False = confirmed by real data, True = based on a
    forecast that hasn't happened yet).
    """
    df = load_bank_data()
    all_banks = get_all_bank_names(df)

    print("Running %s change-point detection for ALL %d banks (live emerging-shift check: %s).\n" % (
        metric, len(all_banks), include_forecast))

    results = []
    for bank in all_banks:
        try:
            series = get_bank_series(df, bank, metric)
            if len(series) < MIN_MONTHS_REQUIRED:
                continue

            values = series[metric].tolist()

            # --- Confirmed shifts (real data only) ---
            if len(values) >= MIN_SEGMENT_SIZE * 2:
                pelt_bkps = detect_changepoints_pelt(values)
                binseg_bkps = detect_changepoints_binseg(values)

                for bp in pelt_bkps:
                    shift = summarize_shift(series, bp, metric)
                    if shift is None:
                        continue
                    shift["bank_name"] = bank
                    shift["detected_by_pelt"] = True
                    shift["also_detected_by_binseg"] = bp in binseg_bkps
                    shift["z_score"] = None
                    results.append(shift)
                    print("  %-45s -> CONFIRMED shift at %s: %s -> %s (%s)" % (
                        bank, shift["change_month"], shift["avg_before"], shift["avg_after"], shift["direction"]))

            # --- Emerging shifts (forecast-based, "live") ---
            if include_forecast:
                emerging = detect_emerging_shift(series, metric)
                for shift in emerging:
                    shift["bank_name"] = bank
                    shift["detected_by_pelt"] = False
                    shift["also_detected_by_binseg"] = False
                    results.append(shift)
                    print("  %-45s -> EMERGING signal at %s: baseline %s -> forecast %s (%s) [PROVISIONAL, z=%s]" % (
                        bank, shift["change_month"], shift["avg_before"], shift["avg_after"],
                        shift["direction"], shift["z_score"]))

        except Exception as e:
            print("  %-45s -> SKIPPED (unexpected error): %s" % (bank, str(e)[:150]))
            continue

    if not results:
        print("  No significant change-points or emerging shifts detected in the current dataset.")
        return pd.DataFrame()

    result_df = pd.DataFrame(results)
    result_df["metric"] = metric
    cols = ["bank_name", "metric", "change_month", "avg_before", "avg_after", "magnitude_pct_points",
            "direction", "is_provisional", "warning", "z_score", "detected_by_pelt", "also_detected_by_binseg"]
    return result_df[cols]


if __name__ == "__main__":
    # Usage:
    #   python analytics/changepoint.py                     -> default metric (td_pct)
    #   python analytics/changepoint.py --metric bd_pct       -> a different metric
    metric_arg = TARGET_METRIC
    if "--metric" in sys.argv:
        metric_arg = sys.argv[sys.argv.index("--metric") + 1]

    results_df = run_changepoint_detection_for_all_banks(include_forecast=True, metric=metric_arg)
    output_file = "changepoint_results.csv" if metric_arg == TARGET_METRIC else "changepoint_results_%s.csv" % metric_arg
    results_df.to_csv(output_file, index=False)
    print("\nSaved %d detected shift(s) to %s" % (len(results_df), output_file))

    if len(results_df) > 0:
        confirmed = (~results_df["is_provisional"]).sum()
        provisional = results_df["is_provisional"].sum()
        worsened = (results_df["direction"] == "WORSENED").sum()
        print("%d CONFIRMED (real data) shifts, %d EMERGING (forecast-based, provisional) shifts." % (
            confirmed, provisional))
        print("%d of %d total shifts were WORSENING trends." % (worsened, len(results_df)))
