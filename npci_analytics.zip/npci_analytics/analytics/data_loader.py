import re
import sqlite3
import pandas as pd
from analytics.config import DB_PATH


def normalize_bank_name(name):
    """
    Merges corporate-suffix variants of the same bank into one canonical name.

    Found via real-data investigation: 19 banks (including ICICI, Federal
    Bank, IDBI, IDFC First, Airtel Payments Bank) appear under 2-3 different
    name variants across different source files (e.g. "AIRTEL PAYMENTS BANK"
    vs "AIRTEL PAYMENTS BANK LTD" vs "AIRTEL PAYMENTS BANK LIMITED"). Without
    this fix, each variant is treated as a SEPARATE bank with only a few
    months of fragmented history - which caused forecasting to extrapolate
    wildly implausible values (a real observed case: 42.5% predicted TD for
    a bank whose actual historical maximum was 2.4%, because the forecast
    was built on a 5-month fragment instead of the bank's full 29-month
    history). This normalization is applied before any analysis runs.
    """
    if not isinstance(name, str):
        return name
    cleaned = name.strip().upper()
    cleaned = re.sub(r"\s+(LIMITED|LTD\.?|PVT\.?\s*LTD\.?|PRIVATE\s+LIMITED)\s*$", "", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def load_bank_data():
    """Loads the full cleaned dataset, normalizes bank name variants into one
    canonical identity per bank, adds derived metrics, and returns it sorted
    chronologically."""
    conn = sqlite3.connect(DB_PATH)
    df = pd.read_sql("SELECT * FROM upi_remitter_stats", conn)
    conn.close()

    df["bank_name"] = df["bank_name"].apply(normalize_bank_name)

    # Derived metric: reversal FAILURE rate, the complement of the raw
    # "success %" field already in the source data. Framing it as a failure
    # rate (rather than only having a success rate) makes it directly
    # comparable to td_pct/bd_pct for forecasting and change-point detection -
    # all three are then "higher = worse" metrics, consistent with each other.
    if "debit_reversal_success_pct" in df.columns:
        df["reversal_failure_pct"] = (100 - df["debit_reversal_success_pct"]).clip(lower=0, upper=100)

    df["date"] = pd.to_datetime(df["period"], format="%Y-%m")
    df = df.sort_values(["bank_name", "date"]).reset_index(drop=True)
    return df


def get_bank_series(df, bank_name, metric):
    """Returns one bank's time series for a given metric, as a clean 2-column frame: date, value.
    If duplicate rows exist for the same bank+date after normalization (two
    source variants both reporting the same month), keeps the first and warns,
    rather than silently double-counting that month."""
    bank_df = df[df["bank_name"] == bank_name][["date", metric]].dropna()
    bank_df = bank_df.sort_values("date").reset_index(drop=True)

    dupes = bank_df["date"].duplicated()
    if dupes.any():
        print("  [WARNING] %s has %d duplicate-month row(s) after name normalization - "
              "keeping the first occurrence for each month." % (bank_name, dupes.sum()))
        bank_df = bank_df.drop_duplicates(subset="date", keep="first").reset_index(drop=True)

    return bank_df


def list_banks_with_enough_history(df, min_months, metric="td_pct"):
    """Returns bank names that have at least `min_months` of non-null values for
    the given metric. Used only to decide whether BACKTESTING is meaningful for
    a bank - not used to exclude banks from forecasting entirely (every bank
    still gets a forecast, see get_all_bank_names)."""
    counts = df.groupby("bank_name")[metric].count()
    return counts[counts >= min_months].index.tolist()


def get_all_bank_names(df):
    """Returns every distinct (normalized) bank in the dataset, regardless of history length.
    Every bank gets a forecast attempt - banks with very little history simply
    fall back to a naive forecast (see forecasting.py) rather than being silently excluded."""
    return sorted(df["bank_name"].unique().tolist())
