"""
Forecasting module - predicts decline rate (TD% by default) per bank.

Two models are run for every bank, deliberately:
  1. Prophet          - captures trend + any seasonality
  2. Naive baseline    - "next month = same as last month"

The naive baseline exists so we can PROVE Prophet is actually adding value,
not just assume it. If Prophet doesn't beat the naive baseline on backtested
accuracy for a given bank, that's flagged rather than hidden.

DEFAULT BEHAVIOR (run_forecasting_for_all_banks):
  Forecasts the CURRENT real-world month and the month after it, for every
  bank in the dataset - including banks with very little history, which
  fall back to a naive forecast instead of being silently excluded.

CUSTOM MONTH QUERIES (get_forecast_for_month / query_single_bank_forecast):
  Lets you ask for a forecast for ANY specific future month/year, not just
  the default near-term pair. The further out the requested month is beyond
  the immediate next month, the less reliable the forecast becomes - this
  is flagged explicitly with a warning, not hidden.
"""

import warnings
import os
import sys
import pandas as pd
import numpy as np
from datetime import datetime
from prophet import Prophet

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analytics.config import TARGET_METRIC, MIN_MONTHS_REQUIRED, BACKTEST_HOLDOUT_MONTHS
from analytics.data_loader import load_bank_data, get_bank_series, get_all_bank_names

warnings.filterwarnings("ignore")  # Prophet/cmdstanpy are very verbose by default

# Beyond this many months ahead of "next month", a forecast is flagged as
# long-range and carries an explicit warning that it may change materially
# once more real data is published.
LONG_RANGE_WARNING_THRESHOLD_MONTHS = 2

LONG_RANGE_WARNING = (
    "This is a long-range forecast beyond the immediate next month. "
    "It is based on limited history and current trend only - actual results "
    "may differ significantly as more real data is published. Treat this as "
    "a provisional estimate, not a firm prediction."
)


def _fit_prophet(train_df):
    """train_df must have columns 'ds' and 'y'. Returns a fitted Prophet model, or None if
    Prophet/Stan fails to fit (this happens on certain edge-case series - e.g. long runs of
    near-identical values, or too few points - and should never crash the whole batch)."""
    if train_df["y"].notna().sum() < 2:
        return None  # Prophet cannot fit fewer than 2 real points - don't even try
    model = Prophet(
        yearly_seasonality=False,
        weekly_seasonality=False,
        daily_seasonality=False,
        changepoint_prior_scale=0.1,
    )
    try:
        model.fit(train_df)
        return model
    except Exception as e:
        print("    [Prophet fit failed for this series - falling back to naive] %s" % str(e)[:120])
        return None


def _naive_forecast(train_df, horizon):
    last_value = train_df["y"].iloc[-1]
    return np.array([last_value] * horizon)


def _mape(actual, predicted):
    actual, predicted = np.array(actual), np.array(predicted)
    mask = actual != 0
    if mask.sum() == 0:
        return None
    return round(float(np.mean(np.abs((actual[mask] - predicted[mask]) / actual[mask])) * 100), 2)


def backtest_bank(series_df, holdout_months=BACKTEST_HOLDOUT_MONTHS):
    """Holds out the last `holdout_months` real months and compares Prophet vs. naive
    accuracy on them. Returns None if there isn't enough history to honestly backtest."""
    if len(series_df) < holdout_months + 4:
        return None

    train = series_df.iloc[:-holdout_months].rename(columns={"date": "ds", TARGET_METRIC: "y"})
    test = series_df.iloc[-holdout_months:].rename(columns={"date": "ds", TARGET_METRIC: "y"})

    model = _fit_prophet(train[["ds", "y"]])
    naive_pred = _naive_forecast(train, holdout_months)

    if model is None:
        return {
            "prophet_mape": None,
            "naive_mape": _mape(test["y"].values, naive_pred),
            "prophet_beats_naive": None,
        }

    future = model.make_future_dataframe(periods=holdout_months, freq="MS")
    forecast = model.predict(future)
    prophet_pred = forecast["yhat"].iloc[-holdout_months:].values

    prophet_mape = _mape(test["y"].values, prophet_pred)
    naive_mape = _mape(test["y"].values, naive_pred)

    return {
        "prophet_mape": prophet_mape,
        "naive_mape": naive_mape,
        "prophet_beats_naive": (prophet_mape < naive_mape) if (prophet_mape is not None and naive_mape is not None) else None,
    }


def _months_between(d1, d2):
    return (d2.year - d1.year) * 12 + (d2.month - d1.month)


def get_forecast_for_month(series_df, target_month=None):
    """
    Core forecasting function. Two modes:

    DEFAULT (target_month=None):
      Forecasts the current real-world month and the month after it, relative
      to today's actual date - skipping straight past any gap if a bank's data
      is stale, rather than forecasting every missing month in between.

    CUSTOM (target_month="YYYY-MM"):
      Forecasts exactly that one month. If it's further out than the default
      near-term horizon, a warning is attached.

    Always reports `last_data_update` - when this bank's real data actually ends.
    """
    train = series_df.rename(columns={"date": "ds", TARGET_METRIC: "y"})[["ds", "y"]]
    last_actual_date = train["ds"].iloc[-1]
    last_actual_value = train["y"].iloc[-1]

    today = pd.Timestamp(datetime.now().replace(day=1))

    if target_month is not None:
        target_ts = pd.Timestamp(target_month + "-01")
        target_list = [target_ts]
        default_next = max(today, last_actual_date + pd.DateOffset(months=1))
        is_long_range = _months_between(default_next, target_ts) >= LONG_RANGE_WARNING_THRESHOLD_MONTHS
        warnings_list = [LONG_RANGE_WARNING] if is_long_range else []
        if target_ts <= last_actual_date:
            warnings_list.append(
                "Requested month is on or before the last actual data point - "
                "showing the model's fitted estimate for that month, not a forward forecast."
            )
    else:
        current_month = today if last_actual_date < today else last_actual_date + pd.DateOffset(months=1)
        next_month = current_month + pd.DateOffset(months=1)
        target_list = [current_month, next_month]
        warnings_list = []

    months_ahead_needed = max(1, _months_between(last_actual_date, max(target_list)))

    model = _fit_prophet(train)
    base_result = {
        "last_data_update": last_actual_date.strftime("%Y-%m"),
        "last_actual_value": round(last_actual_value, 3),
        "warnings": "; ".join(warnings_list) if warnings_list else None,
    }

    if model is None:
        forecasts = []
        for month_ts in target_list:
            forecasts.append({
                "forecast_month": month_ts.strftime("%Y-%m"),
                "forecast_value": round(last_actual_value, 3),
                "lower_bound": None,
                "upper_bound": None,
            })
        return dict(base_result, forecast_method="naive_fallback", forecasts=forecasts)

    future = model.make_future_dataframe(periods=months_ahead_needed, freq="MS")
    forecast = model.predict(future)
    forecast = forecast.set_index(forecast["ds"].dt.strftime("%Y-%m"))

    forecasts = []
    for month_ts in target_list:
        key = month_ts.strftime("%Y-%m")
        if key in forecast.index:
            r = forecast.loc[key]
            forecasts.append({
                "forecast_month": key,
                "forecast_value": round(max(0, min(100, r["yhat"])), 3),
                "lower_bound": round(max(0, r["yhat_lower"]), 3),
                "upper_bound": round(min(100, r["yhat_upper"]), 3),
            })
        else:
            forecasts.append({"forecast_month": key, "forecast_value": None, "lower_bound": None, "upper_bound": None})

    return dict(base_result, forecast_method="prophet", forecasts=forecasts)


def run_forecasting_for_all_banks():
    """
    Main entry point for the default behavior: forecasts the current month and
    next month for EVERY bank in the dataset, including sparse-history banks
    (which fall back to naive rather than being excluded). Returns one row per
    bank with two forecast columns (month 1 / month 2).
    """
    df = load_bank_data()
    all_banks = get_all_bank_names(df)
    counts = df.groupby("bank_name")["td_pct"].count()
    eligible_for_backtest = set(counts[counts >= MIN_MONTHS_REQUIRED].index)

    print("Forecasting %s for ALL %d banks in the dataset "
          "(%d have enough history to backtest; the rest use a naive fallback "
          "where Prophet isn't reliable).\n" % (TARGET_METRIC, len(all_banks), len(eligible_for_backtest)))

    results = []
    for bank in all_banks:
        try:
            series = get_bank_series(df, bank, TARGET_METRIC)
            if len(series) == 0:
                continue

            backtest = backtest_bank(series) if bank in eligible_for_backtest else None
            forecast = get_forecast_for_month(series, target_month=None)

            f1, f2 = forecast["forecasts"][0], forecast["forecasts"][1]

            row = {
                "bank_name": bank,
                "months_of_history": len(series),
                "last_data_update": forecast["last_data_update"],
                "last_actual_value": forecast["last_actual_value"],
                "forecast_month_1": f1["forecast_month"],
                "forecast_month_1_value": f1["forecast_value"],
                "lower_bound_month_1": f1["lower_bound"],
                "upper_bound_month_1": f1["upper_bound"],
                "forecast_month_2": f2["forecast_month"],
                "forecast_month_2_value": f2["forecast_value"],
                "lower_bound_month_2": f2["lower_bound"],
                "upper_bound_month_2": f2["upper_bound"],
                "forecast_method": forecast["forecast_method"],
            }
            if backtest:
                row.update(backtest)
            else:
                row.update({"prophet_mape": None, "naive_mape": None, "prophet_beats_naive": None})

            results.append(row)

            status = (
                "OK" if backtest and backtest["prophet_beats_naive"] else
                "Prophet did not beat naive baseline" if backtest and backtest["prophet_beats_naive"] is not None else
                "too little history to backtest" if not backtest else
                "naive fallback used"
            )
            print("  %-45s -> last update: %s  |  %s: %s%%  |  %s: %s%%  (%s)" % (
                bank, row["last_data_update"], row["forecast_month_1"], row["forecast_month_1_value"],
                row["forecast_month_2"], row["forecast_month_2_value"], status))

        except Exception as e:
            print("  %-45s -> SKIPPED (unexpected error): %s" % (bank, str(e)[:150]))
            continue

    return pd.DataFrame(results)


def query_single_bank_forecast(bank_name, target_month):
    """
    Convenience function for an arbitrary custom query - e.g.:
        query_single_bank_forecast("STATE BANK OF INDIA", "2027-03")
    Prints and returns the forecast for exactly that month, with a warning if
    it's a long-range request.
    """
    df = load_bank_data()
    lookup = bank_name.strip().upper()
    matches = [b for b in get_all_bank_names(df) if b == lookup]
    if not matches:
        print("Bank '%s' not found. Check exact spelling (bank names are stored in uppercase)." % bank_name)
        return None

    series = get_bank_series(df, matches[0], TARGET_METRIC)
    result = get_forecast_for_month(series, target_month=target_month)

    print("\nBank: %s" % matches[0])
    print("Last real data update: %s (%s%%)" % (result["last_data_update"], result["last_actual_value"]))
    for f in result["forecasts"]:
        print("Forecast for %s: %s%% (range: %s%% - %s%%)" % (
            f["forecast_month"], f["forecast_value"], f["lower_bound"], f["upper_bound"]))
    if result["warnings"]:
        print("\nWARNING: %s" % result["warnings"])

    return result


if __name__ == "__main__":
    # Usage: python analytics/forecasting.py "BANK NAME" 2027-03   -> single custom query
    if len(sys.argv) == 3:
        query_single_bank_forecast(sys.argv[1], sys.argv[2])
    else:
        results_df = run_forecasting_for_all_banks()
        results_df.to_csv("forecast_results.csv", index=False)
        print("\nSaved %d bank forecasts to forecast_results.csv" % len(results_df))

        valid_backtests = results_df["prophet_beats_naive"].dropna()
        if len(valid_backtests) > 0:
            beat_rate = valid_backtests.mean() * 100
            print("\nProphet beat the naive baseline on %.0f%% of the %d banks with enough data to backtest." % (
                beat_rate, len(valid_backtests)))
        else:
            print("\nNo banks had enough history to backtest.")
