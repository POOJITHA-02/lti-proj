"""
Risk scoring module - computes a transparent, auditable Impact Score per
bank per month, combining decline rate with real transaction volume share.

Deliberately NOT a machine-learning model. In a compliance/monitoring
context, a simple, explainable formula is more appropriate and more
defensible than a black-box score - this is a design choice, not a
limitation, and is worth stating explicitly (see project write-up).

    Impact Score = decline_rate (%) x volume_share (% of that month's total)

A bank with a small decline rate but huge volume share can outrank a bank
with a scarier-looking decline rate but tiny real-world transaction volume -
which is exactly the point of this metric.
"""

import os
import sys
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from analytics.config import TARGET_METRIC
from analytics.data_loader import load_bank_data


def compute_volume_share(df):
    """Adds a column: what % of that month's TOTAL volume this bank represents.
    Guards against a month where total volume is zero or missing (which would
    otherwise produce inf/NaN and break downstream ranking)."""
    monthly_totals = df.groupby("period")["total_volume_mn"].transform("sum")
    volume_share = (df["total_volume_mn"] / monthly_totals) * 100
    volume_share = volume_share.replace([float("inf"), float("-inf")], pd.NA)  # zero/missing monthly total -> missing, not inf
    df["volume_share_pct"] = volume_share.round(4)
    return df


def compute_impact_score(df, metric=TARGET_METRIC):
    """
    Impact Score = decline rate x volume share.
    Higher score = more real-world transactions affected by this bank's decline rate,
    not just a high percentage in isolation.

    Designed for percentage-style metrics (td_pct, bd_pct, reversal_failure_pct).
    Rows with a missing decline-rate value or missing volume share (e.g. a bank
    with no recorded volume that month, or an older/sparser period with gaps in
    the source data) correctly produce a missing Impact Score, rather than
    crashing - see rank_monthly_risk for how these are ranked.
    """
    df["impact_score"] = round(df[metric] * df["volume_share_pct"], 4)
    return df


def rank_monthly_risk(df):
    """
    Adds a rank column: 1 = highest Impact Score within that month.
    Bank-months with a missing/non-finite Impact Score (e.g. no volume data
    recorded that month) are ranked last within their month via na_option,
    and the rank itself is stored as a nullable integer so a missing rank is
    reported as blank rather than crashing the whole pipeline on one bad row.
    """
    ranks = df.groupby("period")["impact_score"].rank(ascending=False, method="min", na_option="bottom")
    df["risk_rank_in_month"] = ranks.astype("Int64")  # pandas nullable integer - supports NA safely
    return df


def run_risk_scoring(metric=TARGET_METRIC):
    """
    `metric`: which decline-rate-style column drives the Impact Score - td_pct
    (default), bd_pct, or reversal_failure_pct. (total_debit_reversal_count_mn
    is a raw count, not a rate, so it isn't a natural fit for this specific
    formula - use the forecasting/change-point modules for that metric instead.)
    """
    df = load_bank_data()
    df = compute_volume_share(df)
    df = compute_impact_score(df, metric=metric)
    df = rank_monthly_risk(df)

    df = df.sort_values(["period", "risk_rank_in_month"])

    output_cols = ["period", "bank_name", metric, "total_volume_mn",
                   "volume_share_pct", "impact_score", "risk_rank_in_month"]

    print("Top 5 highest-impact bank-months across the entire dataset (metric: %s):\n" % metric)
    top5 = df.sort_values("impact_score", ascending=False).head(5)
    for _, row in top5.iterrows():
        print(f"  {row['period']}  {row['bank_name']:40s}  "
              f"{metric}={row[metric]}%  volume_share={row['volume_share_pct']}%  "
              f"-> Impact Score = {row['impact_score']}")

    return df[output_cols]


if __name__ == "__main__":
    # Usage: python analytics/risk_scoring.py [--metric bd_pct|reversal_failure_pct]
    metric_arg = TARGET_METRIC
    if "--metric" in sys.argv:
        metric_arg = sys.argv[sys.argv.index("--metric") + 1]

    results_df = run_risk_scoring(metric=metric_arg)
    output_file = "risk_scores.csv" if metric_arg == TARGET_METRIC else "risk_scores_%s.csv" % metric_arg
    results_df.to_csv(output_file, index=False)
    print(f"\nSaved {len(results_df)} bank-month risk scores to {output_file}")

    latest_period = results_df["period"].max()
    latest_top3 = results_df[results_df["period"] == latest_period].nsmallest(3, "risk_rank_in_month")
    print(f"\nTop 3 highest-risk banks for the most recent month ({latest_period}):")
    for _, row in latest_top3.iterrows():
        print(f"  #{row['risk_rank_in_month']}  {row['bank_name']}  (Impact Score: {row['impact_score']})")
