"""
Runs all analytics modules in sequence and saves their outputs as CSVs.
Usage:
    python run_all_analytics.py                          -> full batch run, all banks
    python analytics/forecasting.py "BANK NAME" 2027-03    -> single custom-month query (run separately)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from analytics.forecasting import run_forecasting_for_all_banks
from analytics.changepoint import run_changepoint_detection_for_all_banks
from analytics.risk_scoring import run_risk_scoring

if __name__ == "__main__":
    print("=" * 70)
    print("STEP 1/3: FORECASTING (current month + next month, ALL banks)")
    print("=" * 70)
    forecast_df = run_forecasting_for_all_banks()
    forecast_df.to_csv("forecast_results.csv", index=False)
    print("-> Saved forecast_results.csv (%d banks)\n" % len(forecast_df))

    print("=" * 70)
    print("STEP 2/3: CHANGE-POINT DETECTION (confirmed + live emerging shifts)")
    print("=" * 70)
    changepoint_df = run_changepoint_detection_for_all_banks(include_forecast=True)
    changepoint_df.to_csv("changepoint_results.csv", index=False)
    if len(changepoint_df) > 0:
        n_confirmed = (~changepoint_df["is_provisional"]).sum()
        n_provisional = changepoint_df["is_provisional"].sum()
    else:
        n_confirmed = n_provisional = 0
    print("-> Saved changepoint_results.csv (%d confirmed, %d emerging/provisional)\n" % (n_confirmed, n_provisional))

    print("=" * 70)
    print("STEP 3/3: RISK SCORING")
    print("=" * 70)
    risk_df = run_risk_scoring()
    risk_df.to_csv("risk_scores.csv", index=False)
    print("-> Saved risk_scores.csv (%d bank-months)\n" % len(risk_df))

    print("=" * 70)
    print("ALL DONE. Three output files ready:")
    print("  forecast_results.csv    - current + next month prediction, every bank")
    print("  changepoint_results.csv - confirmed shifts (real data) + emerging shifts")
    print("                            (forecast-based, is_provisional=True, with a warning)")
    print("  risk_scores.csv          - volume-weighted Impact Score per bank-month")
    print("=" * 70)
    print("\nFor a custom future month query on one bank, run separately:")
    print('  python analytics/forecasting.py "BANK NAME" 2027-03')
