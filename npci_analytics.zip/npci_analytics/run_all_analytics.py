"""
Runs all analytics modules across ALL tracked metrics and saves their
outputs as CSVs.

Metrics covered:
  - td_pct                        (Technical Decline - default/primary)
  - bd_pct                        (Business Decline)
  - reversal_failure_pct           (derived: 100 - Debit Reversal Success %)
  - total_debit_reversal_count_mn   (raw reversal volume - forecasting/change-point only,
                                     not risk-scored since it's a count, not a rate)

Usage:
    python run_all_analytics.py                          -> full batch run, all metrics, all banks
    python analytics/forecasting.py "BANK NAME" 2027-03    -> single custom-month query (run separately)

The default metric (td_pct) keeps its original, unsuffixed filenames
(forecast_results.csv, changepoint_results.csv, risk_scores.csv) for
backward compatibility with the RAG explanation layer and dashboard, which
expect those exact names. Every other metric gets a metric-suffixed filename.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from analytics.config import TARGET_METRIC
from analytics.forecasting import run_forecasting_for_all_banks
from analytics.changepoint import run_changepoint_detection_for_all_banks
from analytics.risk_scoring import run_risk_scoring

FORECAST_AND_CHANGEPOINT_METRICS = ["td_pct", "bd_pct", "reversal_failure_pct", "total_debit_reversal_count_mn"]
RISK_SCORING_METRICS = ["td_pct", "bd_pct", "reversal_failure_pct"]  # count metric excluded - not a rate


def _suffixed(base_name, metric):
    return base_name if metric == TARGET_METRIC else base_name.replace(".csv", "_%s.csv" % metric)


if __name__ == "__main__":
    all_forecast_files = []
    all_changepoint_files = []
    all_risk_files = []

    for metric in FORECAST_AND_CHANGEPOINT_METRICS:
        print("=" * 70)
        print("FORECASTING: %s (current month + next month, ALL banks)" % metric)
        print("=" * 70)
        forecast_df = run_forecasting_for_all_banks(metric=metric)
        fname = _suffixed("forecast_results.csv", metric)
        forecast_df.to_csv(fname, index=False)
        all_forecast_files.append(fname)
        print("-> Saved %s (%d banks)\n" % (fname, len(forecast_df)))

        print("=" * 70)
        print("CHANGE-POINT DETECTION: %s (confirmed + live emerging shifts)" % metric)
        print("=" * 70)
        changepoint_df = run_changepoint_detection_for_all_banks(include_forecast=True, metric=metric)
        cname = _suffixed("changepoint_results.csv", metric)
        changepoint_df.to_csv(cname, index=False)
        all_changepoint_files.append(cname)
        if len(changepoint_df) > 0:
            n_confirmed = (~changepoint_df["is_provisional"]).sum()
            n_provisional = changepoint_df["is_provisional"].sum()
        else:
            n_confirmed = n_provisional = 0
        print("-> Saved %s (%d confirmed, %d emerging/provisional)\n" % (cname, n_confirmed, n_provisional))

    for metric in RISK_SCORING_METRICS:
        print("=" * 70)
        print("RISK SCORING: %s" % metric)
        print("=" * 70)
        risk_df = run_risk_scoring(metric=metric)
        rname = _suffixed("risk_scores.csv", metric)
        risk_df.to_csv(rname, index=False)
        all_risk_files.append(rname)
        print("-> Saved %s (%d bank-months)\n" % (rname, len(risk_df)))

    print("=" * 70)
    print("ALL DONE. Output files ready:")
    print("  Forecasts:      %s" % ", ".join(all_forecast_files))
    print("  Change-points:  %s" % ", ".join(all_changepoint_files))
    print("  Risk scores:    %s" % ", ".join(all_risk_files))
    print("=" * 70)
    print("\nFor a custom future month query on one bank/metric, run separately:")
    print('  python analytics/forecasting.py "BANK NAME" 2027-03 [metric]')
