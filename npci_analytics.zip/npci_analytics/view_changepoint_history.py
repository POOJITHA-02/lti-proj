"""
Lets the user browse the full change-point history (confirmed + emerging),
filtered by direction (WORSENED / IMPROVED / both), bank, and metric.

Usage:
    python view_changepoint_history.py                          -> everything (td_pct)
    python view_changepoint_history.py --metric bd_pct           -> a different metric's results
    python view_changepoint_history.py --direction WORSENED      -> only worsening shifts
    python view_changepoint_history.py --direction IMPROVED      -> only improving shifts
    python view_changepoint_history.py --bank "STATE BANK OF INDIA"
    python view_changepoint_history.py --direction WORSENED --bank "YES BANK LTD"
    python view_changepoint_history.py --confirmed-only          -> exclude provisional/emerging rows
    python view_changepoint_history.py --provisional-only        -> only provisional/emerging rows
    python view_changepoint_history.py --csv custom_file.csv     -> point directly at any CSV
"""

import argparse
import pandas as pd


def load_history(csv_path="changepoint_results.csv"):
    return pd.read_csv(csv_path)


def filter_history(df, direction=None, bank=None, confirmed_only=False, provisional_only=False):
    result = df.copy()

    if direction:
        result = result[result["direction"].str.upper() == direction.upper()]

    if bank:
        result = result[result["bank_name"].str.upper() == bank.strip().upper()]

    if confirmed_only:
        result = result[~result["is_provisional"]]

    if provisional_only:
        result = result[result["is_provisional"]]

    return result.sort_values(["bank_name", "change_month"])


def print_history(df):
    if len(df) == 0:
        print("No change-points match this filter.")
        return

    for _, row in df.iterrows():
        tag = "[EMERGING/PROVISIONAL]" if row["is_provisional"] else "[CONFIRMED]"
        print("%-40s %s  %s -> %s  (%s%s)  %s" % (
            row["bank_name"], row["change_month"], row["avg_before"], row["avg_after"],
            row["direction"], "" if not row["is_provisional"] else ", z=%s" % row.get("z_score", ""), tag
        ))

    print("\nTotal matching rows: %d" % len(df))
    if "direction" in df.columns and len(df) > 0:
        print("  WORSENED: %d   IMPROVED: %d" % (
            (df["direction"] == "WORSENED").sum(), (df["direction"] == "IMPROVED").sum()
        ))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Browse change-point history with filters.")
    parser.add_argument("--direction", choices=["WORSENED", "IMPROVED", "worsened", "improved"], default=None)
    parser.add_argument("--bank", default=None, help="Exact bank name to filter to")
    parser.add_argument("--confirmed-only", action="store_true", help="Exclude emerging/provisional rows")
    parser.add_argument("--provisional-only", action="store_true", help="Only emerging/provisional rows")
    parser.add_argument("--csv", default=None, help="Path to a changepoint_results CSV directly")
    parser.add_argument("--metric", default="td_pct",
                         help="Shortcut instead of --csv: td_pct (default), bd_pct, reversal_failure_pct, "
                              "or total_debit_reversal_count_mn - resolves to the matching output filename")
    args = parser.parse_args()

    if args.csv:
        csv_path = args.csv
    elif args.metric == "td_pct":
        csv_path = "changepoint_results.csv"
    else:
        csv_path = "changepoint_results_%s.csv" % args.metric

    df = load_history(csv_path)
    filtered = filter_history(
        df, direction=args.direction, bank=args.bank,
        confirmed_only=args.confirmed_only, provisional_only=args.provisional_only
    )
    print_history(filtered)
