# NPCI UPI Data Pipeline — Setup & Usage

A self-updating pipeline: drop new monthly NPCI Excel files in, run one script,
get a clean, duplicate-free SQLite database ready for Power BI.

## 1. Install dependencies
```
pip install -r requirements.txt
```

## 2. Folder structure
```
npci_pipeline/
├── incoming/          <- put new .xlsx files here (as downloaded from npci.org.in)
├── processed/         <- files move here automatically after being ingested
├── npci_upi.db         <- the SQLite database (created on first run)
├── pipeline/
│   ├── config.py
│   ├── clean_utils.py  <- all the data-cleaning logic
│   ├── db_utils.py      <- database schema and helpers
│   └── ingest.py         <- the main script you run
├── check_status.py      <- quick command-line summary of what's in the DB
├── run_pipeline.bat      <- for Windows Task Scheduler automation
└── requirements.txt
```

## 3. Run it
1. Put one or more `.xlsx` files (e.g. `Ecosystem-Statistics-UPI-Top-50-member-performance-2026-Aug-Remitter.xlsx`) into `incoming/`
2. Run:
   ```
   python pipeline/ingest.py
   ```
3. Check what happened anytime:
   ```
   python check_status.py
   ```

That's the entire live-update loop. Every time NPCI publishes a new month, drop the file into `incoming/` and run the script again — nothing else changes.

## 4. Why this is safe to re-run (important)
NPCI's own site has a real, observed quirk: if you download a month before it's actually published, it silently gives you a repeat of the previous month's data under the new month's filename. This pipeline catches that automatically by comparing the **actual data values**, not just the filename or the month printed inside the file — so a re-served duplicate is always detected and skipped, never double-counted. You'll see it flagged clearly as `skipped_duplicate` when it happens.

This also means the pipeline is fully **idempotent** — running it 10 times on the same files only ever ingests each real month once.

## 5. View the data live — DB Browser for SQLite
Open `npci_upi.db` in DB Browser for SQLite anytime to see:
- `upi_remitter_stats` — the actual clean data, one row per bank per month
- `ingestion_log` — a full audit trail of every file ever processed and what happened to it

**Important:** close DB Browser before re-running `ingest.py` — SQLite locks the file while DB Browser has it open for writing, and the script needs write access.

## 6. Automate it — Windows Task Scheduler
1. Open **Task Scheduler** → Create Basic Task
2. Trigger: Monthly (or however often you want to check)
3. Action: "Start a program" → point it at `run_pipeline.bat` in this folder
4. Done — it will run silently and log its output to `pipeline_run_log.txt` in this folder

You'd still need to manually download the new file from NPCI's site into `incoming/` before the scheduled run (NPCI has no public bulk API), but the cleaning, deduplication, and database update all become fully automatic from there.

## 7. Connect Power BI
SQLite isn't natively supported by Power BI Desktop. Two options:
- **Easiest:** install the free "SQLite ODBC Driver," then in Power BI use Get Data → ODBC → point it at `npci_upi.db`
- **Cleanest for a "live" dashboard:** periodically push this SQLite data to a free cloud Postgres (Supabase/Neon) using `pandas.to_sql()`, and connect Power BI to that instead — this is what makes the dashboard update without needing your laptop on, and is the approach discussed earlier for the full project pipeline.

## 8. What each script actually does
- **`clean_utils.py`** — fixes the real messiness in NPCI's files: inconsistent column names, percentages stored as both `"94.10%"` text and `0.79` decimals, and bank names in inconsistent casing.
- **`db_utils.py`** — creates the two database tables and provides simple insert/lookup functions.
- **`ingest.py`** — the orchestrator: reads each new file, cleans it, checks it against everything already ingested (by content, not filename), inserts genuinely new data, and archives the file.
- **`check_status.py`** — a read-only summary so you don't have to open DB Browser just to check row counts.
