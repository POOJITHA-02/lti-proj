"""Quick sanity check - prints a summary of what's currently in the database.
Run this anytime with: python check_status.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pipeline.db_utils import get_db

with get_db() as conn:
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) as c FROM upi_remitter_stats")
    total_rows = cur.fetchone()["c"]

    cur.execute("SELECT COUNT(DISTINCT period) as c FROM upi_remitter_stats")
    total_periods = cur.fetchone()["c"]

    cur.execute("SELECT MIN(period) as mn, MAX(period) as mx FROM upi_remitter_stats")
    row = cur.fetchone()
    date_range = f"{row['mn']} to {row['mx']}"

    cur.execute("SELECT DISTINCT period FROM upi_remitter_stats ORDER BY period")
    periods = [r["period"] for r in cur.fetchall()]

    cur.execute("SELECT source_file, status, claimed_period, processed_at FROM ingestion_log ORDER BY id DESC LIMIT 10")
    recent_log = cur.fetchall()

    print("=" * 60)
    print("NPCI UPI DATABASE STATUS")
    print("=" * 60)
    print(f"Total rows:          {total_rows}")
    print(f"Distinct months:     {total_periods}")
    print(f"Date range covered:  {date_range}")
    print(f"\nAll periods present: {periods}")
    print(f"\nLast 10 ingestion log entries:")
    for r in recent_log:
        print(f"  [{r['processed_at']}] {r['source_file']:65s} -> {r['status']} (claimed {r['claimed_period']})")
