import pandas as pd
import re
import os
from pipeline.config import CANONICAL_COLUMNS, MONTH_MAP


def clean_percent(value):
    """Handles both '94.10%' strings and raw decimals like 0.7906 - returns a 0-100 scale float."""
    if pd.isna(value):
        return None
    if isinstance(value, str):
        value = value.strip().replace("%", "")
        try:
            value = float(value)
        except ValueError:
            return None
    val = float(value)
    if val <= 1.5:
        val = val * 100
    return round(val, 2)


def clean_number(value):
    """Handles '-' or blank as missing, strips commas, returns float."""
    if pd.isna(value):
        return None
    if isinstance(value, str):
        v = value.strip().replace(",", "")
        if v in ("-", "", "NaN"):
            return None
        try:
            return float(v)
        except ValueError:
            return None
    return float(value)


def extract_month_year_from_title(title_text):
    """Extracts month/year from the sheet's own title row, e.g. \"...(Apr'24)\" -> ('Apr', 2024).
    This is deliberately used INSTEAD of the filename, since NPCI filenames have been observed
    to disagree with the actual month printed inside the file."""
    m = re.search(r"\((\w{3})'(\d{2})\)", str(title_text))
    if not m:
        return None, None
    month_str, year_str = m.group(1), m.group(2)
    return month_str, 2000 + int(year_str)


def process_file(filepath):
    """Reads one raw NPCI 'Top 50 Remitter' Excel file and returns a cleaned DataFrame,
    or None if the file's title can't be parsed (and should be skipped/flagged)."""
    raw = pd.read_excel(filepath, header=None)
    title_text = raw.iloc[0, 0]
    month_str, year = extract_month_year_from_title(title_text)

    if month_str is None:
        return None

    month_num = MONTH_MAP.get(month_str)

    data = raw.iloc[2:].copy()
    data.columns = CANONICAL_COLUMNS[:data.shape[1]]
    data = data.dropna(how="all")

    data["bank_name"] = data["bank_name"].astype(str).str.strip().str.upper()
    data["bank_name"] = data["bank_name"].str.replace(r"\s+", " ", regex=True)
    data["bank_name"] = data["bank_name"].str.replace(r"\.$", "", regex=True)

    data["total_volume_mn"] = data["total_volume_mn"].apply(clean_number)
    data["approved_pct"] = data["approved_pct"].apply(clean_percent)
    data["bd_pct"] = data["bd_pct"].apply(clean_percent)
    data["td_pct"] = data["td_pct"].apply(clean_percent)
    data["total_debit_reversal_count_mn"] = data["total_debit_reversal_count_mn"].apply(clean_number)
    data["debit_reversal_success_pct"] = data["debit_reversal_success_pct"].apply(clean_percent)

    data["month"] = month_str
    data["month_num"] = month_num
    data["year"] = year
    data["period"] = f"{year}-{month_num:02d}"
    data["source_file"] = os.path.basename(filepath)

    data = data.drop(columns=["sr_no"])
    data = data.dropna(subset=["bank_name"])
    data = data[data["bank_name"] != "NAN"]

    return data


def content_signature(df):
    """Builds a hashable signature of the actual data values (bank/volume/bd/td),
    independent of whatever period label the file's title claims. Used to catch
    NPCI serving identical repeat data under two different month labels."""
    subset = df.sort_values("bank_name")[["bank_name", "total_volume_mn", "bd_pct", "td_pct"]]
    return tuple(subset.itertuples(index=False, name=None))
