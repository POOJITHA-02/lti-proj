import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

INCOMING_FOLDER = os.path.join(BASE_DIR, "incoming")
PROCESSED_FOLDER = os.path.join(BASE_DIR, "processed")
DB_PATH = os.path.join(BASE_DIR, "npci_upi.db")

CANONICAL_COLUMNS = [
    "sr_no", "bank_name", "total_volume_mn", "approved_pct",
    "bd_pct", "td_pct", "total_debit_reversal_count_mn", "debit_reversal_success_pct"
]

MONTH_MAP = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
    "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12
}
