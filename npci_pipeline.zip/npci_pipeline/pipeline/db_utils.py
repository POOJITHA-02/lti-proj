import sqlite3
from contextlib import contextmanager
from pipeline.config import DB_PATH


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS upi_remitter_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bank_name TEXT NOT NULL,
            total_volume_mn REAL,
            approved_pct REAL,
            bd_pct REAL,
            td_pct REAL,
            total_debit_reversal_count_mn REAL,
            debit_reversal_success_pct REAL,
            month TEXT,
            month_num INTEGER,
            year INTEGER,
            period TEXT,
            source_file TEXT,
            ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Tracks every file ever processed (by content signature) so re-running the
    # pipeline never inserts the same data twice, even if NPCI relabels a filename.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ingestion_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_file TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            claimed_period TEXT,
            status TEXT NOT NULL,      -- 'ingested', 'skipped_duplicate', 'skipped_unparseable'
            row_count INTEGER,
            processed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


@contextmanager
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def get_known_content_hashes():
    """Returns the set of content hashes already ingested, so new files can be checked against them."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT content_hash FROM ingestion_log WHERE status = 'ingested'")
        return {row["content_hash"] for row in cur.fetchall()}


def insert_stats(df):
    with get_db() as conn:
        df.to_sql("upi_remitter_stats", conn, if_exists="append", index=False)


def log_ingestion(source_file, content_hash, claimed_period, status, row_count):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO ingestion_log (source_file, content_hash, claimed_period, status, row_count)
               VALUES (?, ?, ?, ?, ?)""",
            (source_file, content_hash, claimed_period, status, row_count),
        )
        conn.commit()
