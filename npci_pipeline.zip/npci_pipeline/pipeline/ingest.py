"""
NPCI UPI Remitter Data Ingestion Pipeline
------------------------------------------
Drop new monthly .xlsx files (as downloaded from npci.org.in) into the
'incoming' folder and run this script. It will:

  1. Clean and standardize each file (fixing column-name drift, mixed
     percent formats, and trusting the in-file title over the filename)
  2. Check each file's actual DATA content against everything already
     ingested - so if NPCI serves the same data twice under different
     month labels (this has happened - see README), it's skipped, not
     double-counted
  3. Insert genuinely new data into the SQLite database (npci_upi.db)
  4. Move successfully processed files into 'processed/' so re-running
     this script is always safe and never reprocesses old files

Run it manually, or schedule it (see README.md) to run automatically.
"""

import os
import shutil
import glob
import hashlib
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pipeline.config import INCOMING_FOLDER, PROCESSED_FOLDER, DB_PATH
from pipeline.clean_utils import process_file, content_signature
from pipeline.db_utils import init_db, get_known_content_hashes, insert_stats, log_ingestion


def hash_signature(sig):
    return hashlib.sha256(str(sig).encode()).hexdigest()


def run_pipeline():
    os.makedirs(INCOMING_FOLDER, exist_ok=True)
    os.makedirs(PROCESSED_FOLDER, exist_ok=True)

    init_db()
    known_hashes = get_known_content_hashes()

    files = sorted(glob.glob(os.path.join(INCOMING_FOLDER, "*.xlsx")))

    if not files:
        print(f"No new files found in {INCOMING_FOLDER}/. Nothing to do.")
        return

    print(f"Found {len(files)} file(s) to process.\n")

    ingested_count = 0
    skipped_count = 0

    for filepath in files:
        fname = os.path.basename(filepath)
        df = process_file(filepath)

        if df is None:
            print(f"  SKIPPED (unparseable title/format): {fname}")
            log_ingestion(fname, "N/A", "N/A", "skipped_unparseable", 0)
            continue

        claimed_period = df["period"].iloc[0]
        sig = content_signature(df)
        sig_hash = hash_signature(sig)

        if sig_hash in known_hashes:
            print(f"  SKIPPED (duplicate content - already ingested under a different name/label): {fname} "
                  f"(claimed period: {claimed_period})")
            log_ingestion(fname, sig_hash, claimed_period, "skipped_duplicate", 0)
            skipped_count += 1
        else:
            insert_stats(df)
            log_ingestion(fname, sig_hash, claimed_period, "ingested", len(df))
            known_hashes.add(sig_hash)
            print(f"  INGESTED: {fname} -> period {claimed_period} ({len(df)} banks)")
            ingested_count += 1

        # Move file out of incoming/ regardless of outcome, so it's never reprocessed
        shutil.move(filepath, os.path.join(PROCESSED_FOLDER, fname))

    print(f"\nDone. {ingested_count} file(s) ingested, {skipped_count} duplicate(s) skipped.")
    print(f"Database: {DB_PATH}")
    print("Open this file in DB Browser for SQLite to inspect the data anytime "
          "(close DB Browser before re-running this script, so it isn't locked).")


if __name__ == "__main__":
    run_pipeline()
