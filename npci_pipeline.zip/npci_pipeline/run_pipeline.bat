@echo off
REM This batch file runs the NPCI ingestion pipeline.
REM Point Windows Task Scheduler at this file to automate monthly ingestion.

cd /d "%~dp0"
python pipeline\ingest.py >> pipeline_run_log.txt 2>&1
