# RAG Explanation Layer — Always-Substantive Anomaly Explanations

Explains flagged change-points (from the analytics module) using real
documents where available, and genuine data-driven analysis always — never
a dead-end "nothing found" message. Handles both CONFIRMED (real data) and
EMERGING/PROVISIONAL (forecast-based) shifts, with the provisional warning
carried through.

## Core design principle
**Every explanation always states the actual quantitative shift, a
cross-bank/seasonal analytical read, AND relevant domain knowledge about why
TD/BD happens in general - all computed/retrieved locally, with zero
dependency on finding a specific news article or circular.** A matching
event-specific document (RBI notice, NPCI circular, or news article) is
added context on top of this - never a requirement for the explanation to
be useful.

## Domain knowledge base (`rag/domain_knowledge.py`)
Seven curated, evergreen reference documents - not date-specific news, but
genuine ground-truth about the metrics themselves:
1. Definition and causes of Technical Decline (TD)
2. Definition and causes of Business Decline (BD)
3. Historical trend of UPI technical decline rates (2016's 8-10% down to today's ~0.3-0.8%)
4. Common sub-causes breakdown (server timeout, wrong PIN, insufficient balance, etc.)
5. Seasonal/cyclical factors (documented NPCI-attributed FY-end and festive-season load spikes)
6. Definition and causes of Debit Reversal Failure
7. Why reversal count differs from decline-rate volume

Content is paraphrased in original wording from publicly known facts (e.g.
NPCI Circular OC-149's TD<1%/BD<5% benchmarks, widely-reported historical
decline-rate trends) - not reproduced verbatim from any single source.
These are seeded into the same document store as fetched RSS content (via
`seed_domain_knowledge()`, called automatically by the pipeline, including
in `--skip-fetch` offline mode since they need no network access), and are
**always retrieved and included** in every explanation
(`retrieve_domain_knowledge()` in `explain.py`) - kept separate from the
event-specific search tiers (via `exclude_doc_types`) so they never crowd
out a genuine bank-specific document match, but are always added as a
grounding layer regardless of whether one is found.

**Verified in testing**: with a completely empty event-specific document
store (the realistic scenario on a fresh setup), all 91 test explanations
still averaged ~1,600 characters of substantive, grounded content - purely
from the quantitative summary + cross-bank analysis + domain knowledge
layers, zero dependency on any external document being found.

## Four-tier retrieval, tried in order
1. **Precise match** - static document store (RBI + NPCI feeds), bank/month-specific query.
2. **Broad fallback** - static store, general UPI-reliability query (drops bank/month specifics).
3. **Live Google News search** (`rag/news_search.py`) - queried live per bank/month at
   explanation time, since day-to-day outage incidents show up in news coverage
   long before (or instead of) any official regulatory document.
4. **Analytical fallback** (always available, zero dependencies) - if nothing
   matches, the explanation is still built from:
   - The exact quantitative shift (before/after values, magnitude)
   - **Cross-bank pattern context**: how many *other* banks showed a similar
     shift the same month, computed from your own `changepoint_results.csv`
     - many banks affected together suggests a systemic/industry-wide cause;
     an isolated shift suggests something bank-specific
   - **Seasonal context**: whether the month coincides with a known
     industry-wide high-volume period in India (financial year-end in March,
     festive season in Oct/Nov) - stated as context, never as a confirmed cause

## Important fix: a false-positive guard on document matching
Testing surfaced a real problem worth knowing about: TF-IDF similarity can
score two completely unrelated documents as "matching" purely because they
share generic words like "Bank" or "Directions" - an RBI notice about an
entirely different bank's unrelated regulatory action scored 0.33 (above
the old 0.30 threshold) against a UPI-reliability query. Fixed by requiring
the word "UPI" to actually appear in a candidate document before it's
accepted as a match, regardless of similarity score (`rag/retriever.py`,
`require_keyword` parameter, default `"upi"`). Disable it by passing
`require_keyword=None` if you retarget this pipeline to a different topic.

## Two document sources for the static store

### RBI (general regulator feeds)
`rag/fetch_documents.py` pulls RBI's public RSS feeds (press releases,
notifications) - RSS 2.0 format.

### NPCI (UPI operator, genuinely more relevant)
Also pulls NPCI's own UPI-specific circulars via a community-maintained
Atom-format mirror (`captnemo.in/npci-rss-feeds`, sourced from
`npci.org.in/what-we-do/upi/circular`) - since NPCI operates UPI directly,
its circulars are inherently more relevant than RBI's general regulatory
feed. Honest caveat: this is a third-party mirror, not run by NPCI itself,
updated twice daily via GitHub Actions - reliable in testing, but worth
knowing it depends on someone else's community project staying maintained.
Both RSS 2.0 and Atom formats are auto-detected and parsed by the same
`parse_rss_content` function.

Both sources are deduplicated by URL and stored safely - re-running never double-inserts.

## How it stays "live" / regularly updated
- `rag/fetch_documents.py` only inserts genuinely new documents each run.
- The retrieval index (`rag/embeddings.py`) updates incrementally.
- No Task Scheduler required - see "Automation without Task Scheduler" below.

## 1. Install
```
pip install -r requirements.txt
```

## 2. Important network notes
- `fetch_documents.py` needs normal internet access to `rbi.org.in` and `captnemo.in`.
- `news_search.py` needs access to `news.google.com`.
- If you're on a restricted corporate network, any of these may be blocked
  by a proxy - handled gracefully everywhere (clear diagnostic output, safe
  fallback to the next tier) rather than crashing. Worst case, everything
  falls through to the analytical-only explanation, which is still fully substantive.

## 3. Required input
`changepoint_results.csv`, produced by the analytics module - copy it into this folder before running.

## 4. Run the full pipeline
```
python run_rag_pipeline.py                  # td_pct (default)
python run_rag_pipeline.py --metric bd_pct   # a specific metric
python run_rag_pipeline.py --all-metrics      # all 4 metrics in one run
```
Or offline (skip the live document fetch, use whatever's already stored):
```
python run_rag_pipeline.py --all-metrics --skip-fetch
```

Expects the matching `changepoint_results` CSV(s) from the analytics
module's `run_all_analytics.py` copied into this folder:
```
changepoint_results.csv                              (td_pct)
changepoint_results_bd_pct.csv
changepoint_results_reversal_failure_pct.csv
changepoint_results_total_debit_reversal_count_mn.csv
```

Produces one `rag_explanations` CSV per metric run (same naming pattern),
with columns: bank_name, change_month, direction, status, explanation,
match_type, domain_knowledge_included, top_source_title, top_source_link,
top_source_score.

**Metric-aware throughout**: every explanation correctly labels and units
its metric - "technical decline rate...%", "business decline rate...%",
"debit reversal failure rate...%", or "debit reversal count...Mn" - reading
the `metric` column already present in the analytics module's
`changepoint_results.csv` output. Domain-knowledge retrieval, event-specific
search queries, and news search are all separately tailored per metric too
(e.g. a reversal-failure shift searches for reversal/refund-specific terms
and cites the reversal-specific domain-knowledge document first, not a
generic TD document).

## 5. Two explanation modes

### Extractive (default, zero cost, zero extra setup)
No API key needed. Always includes the quantitative summary and cross-bank/
seasonal analysis; adds a document or news citation on top when a genuine match exists.

### LLM-polished (optional)
Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` in a `.env` file. The LLM is
given both the retrieved documents AND the same cross-bank/seasonal
analytical context, and instructed to use only that - never adding outside
information. Falls back to extractive automatically on any API failure.

## 6. Retrieval backend - TF-IDF by default, on purpose
Defaults to TF-IDF (pure scikit-learn, no model download, works immediately
after `pip install`) rather than a neural embedding model, since the
semantic model needs to download from huggingface.co on first use - the
same class of problem as SMTP being blocked on a locked-down office
network. Upgrade to semantic matching by setting `USE_SEMANTIC_EMBEDDINGS =
True` in `rag/embeddings.py`, but test `huggingface.co` reachability first.

## 7. Automation without Task Scheduler
Three options, in order of simplicity:
- **Manual**: run `python run_rag_pipeline.py` before you need fresh results.
- **A simple loop script**, no admin rights needed:
  ```python
  import time, subprocess
  while True:
      subprocess.run(["python", "run_rag_pipeline.py"])
      time.sleep(24 * 60 * 60)
  ```
- **GitHub Actions** (if this is in a Git repo) - runs on GitHub's servers,
  works even if your laptop is off:
  ```yaml
  name: Refresh RAG
  on:
    schedule: [{cron: '0 6 * * *'}]
    workflow_dispatch:
  jobs:
    refresh:
      runs-on: ubuntu-latest
      steps:
        - uses: actions/checkout@v4
        - uses: actions/setup-python@v5
          with: {python-version: '3.11'}
        - run: pip install -r requirements.txt
        - run: python run_rag_pipeline.py
  ```

## 8. Config you can change
- `rag/config.py`: `MIN_RELEVANCE_SCORE`, `TOP_K_RESULTS`, `ALL_FEEDS`
- `rag/retriever.py`: `require_keyword` parameter on `retrieve()`
- `rag/explain.py`: `SEASONAL_CONTEXT` dict

## 9. What was actually tested before this was packaged
- RSS 2.0 parsing (RBI) and Atom parsing (NPCI) against real fetched content
- Deduplication (re-inserting the same documents correctly skips all of them)
- The false-positive guard: confirmed a spurious 0.33-score match was
  correctly rejected once the keyword filter was added, while genuine
  UPI-relevant matches (score 0.60) still passed correctly
- Google News query construction and parsing (their HTML-encoded description
  format), plus graceful failure when the network is blocked
- Full end-to-end runs producing substantive explanations in all scenarios:
  genuine document match, no document match with cross-bank context, and
  mixed CONFIRMED/EMERGING batches
