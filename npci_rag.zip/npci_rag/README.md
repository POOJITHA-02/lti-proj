# RAG Explanation Layer — Grounded Anomaly Explanations Using RBI Documents

Explains flagged change-points (from the analytics module) by retrieving and
citing real RBI press releases and notifications — never freely generating a
guess. Handles both CONFIRMED (real data) and EMERGING/PROVISIONAL
(forecast-based) shifts, with the provisional warning carried through.

## How it stays "live" / regularly updated
- `rag/fetch_documents.py` pulls from RBI's real public RSS feeds
  (`pressreleases_rss.xml`, `notifications_rss.xml`) and stores only
  genuinely new documents each run (deduplicated by URL) — safe to run daily,
  weekly, or on any schedule you like, exactly like the NPCI ingestion pipeline.
- `refresh_rag.bat` + Windows Task Scheduler automates this (see below).
- The retrieval index (`rag/embeddings.py`) updates incrementally too — it
  only processes newly-added documents, not the whole store, each time.

## 1. Install
```
pip install -r requirements.txt
```

## 2. Important network note
`fetch_documents.py` needs normal internet access to `rbi.org.in`. If you're
on a restricted network where this is blocked, this one step needs to run
somewhere with unrestricted access (or ask IT to allowlist `rbi.org.in`,
same as you'd need for the SMTP server earlier). Everything else in this
pipeline (retrieval, explanation generation) works fully offline once
documents are stored in the database.

## 3. Required input
`changepoint_results.csv`, produced by the analytics module
(`run_all_analytics.py` in the `npci_analytics` project) — copy it into this
folder before running.

## 4. Run the full pipeline
```
python run_rag_pipeline.py
```
Or, if you're offline and just want to test against documents already fetched:
```
python run_rag_pipeline.py --skip-fetch
```

Produces `rag_explanations.csv` with columns: bank_name, change_month,
direction, status (CONFIRMED / EMERGING (PROVISIONAL)), explanation,
top_source_title, top_source_link, top_source_score.

## 5. Two explanation modes — both tested, both work

### Extractive (default, zero cost, zero extra setup)
No API key needed. Reports the single most relevant retrieved RBI document
(title, date, excerpt, link) with its similarity score. If nothing in the
document store is genuinely relevant (score below `MIN_RELEVANCE_SCORE`,
default 0.30), it says so honestly instead of forcing a weak match.

**Honest finding from testing:** RBI's general press-release/notification
feed only occasionally covers UPI-specific technical issues directly — most
items are about auctions, monetary penalties, KYC rules, etc. Expect many
change-points to have **no strongly relevant match**, which is itself
correctly reported rather than hidden. This is a real limitation of relying
on the general public feed rather than a UPI-specific regulatory channel.

### LLM-polished (optional)
Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` in a `.env` file (copy
`.env.example`) to get a short, natural-language explanation instead of a
raw excerpt. The LLM is explicitly instructed to use **only** the retrieved
document text — never to add outside information — which is what keeps this
RAG (grounded) rather than free generation (ungrounded, hallucination-prone).
Automatically falls back to the extractive mode if the API call fails for
any reason (rate limit, network, invalid key).

## 6. Retrieval backend — TF-IDF by default, on purpose
`rag/embeddings.py` defaults to **TF-IDF** (pure scikit-learn), not a
downloaded neural embedding model. This was a deliberate choice made after
testing: the semantic embedding model (Sentence-Transformers) needs to
download from huggingface.co on first use, which failed in a network-
restricted test environment during development — the same class of problem
you hit earlier with SMTP being blocked on your office laptop. TF-IDF needs
no such download and works immediately after `pip install`.

If your network can reach huggingface.co, you can upgrade to semantic
matching (better at matching different wording, e.g. "technical decline" to
"processing errors") by setting `USE_SEMANTIC_EMBEDDINGS = True` at the top
of `rag/embeddings.py` — test this first with:
```
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('all-MiniLM-L6-v2')"
```
If that succeeds, the upgrade is safe to enable.

## 7. Automate the refresh — Windows Task Scheduler
1. Open Task Scheduler → Create Basic Task
2. Trigger: daily or weekly, your choice
3. Action: "Start a program" → point it at `refresh_rag.bat` in this folder
4. Output logs to `rag_refresh_log.txt` automatically

Note: this refreshes the RBI *document store*. To regenerate explanations
for new change-points, you still need an updated `changepoint_results.csv`
from the analytics module — consider scheduling both in sequence.

## 8. Config you can change (`rag/config.py`)
- `MIN_RELEVANCE_SCORE` — how relevant a document must be to count as a real match (default 0.30)
- `TOP_K_RESULTS` — how many documents to retrieve per query (default 3)
- `RBI_FEEDS` — add more RBI RSS feeds here if needed (speeches, publications, etc. — all listed on rbi.org.in)

## 9. What was actually tested before this was packaged
- RSS parsing (HTML stripping, date parsing) against real fetched RBI content
- Deduplication (re-inserting the same documents correctly skips all of them)
- TF-IDF indexing and incremental updates (no-op on unchanged data)
- Retrieval ranking: a UPI/technical-decline query correctly surfaced a
  UPI-relevant test document (score 0.60) while an unrelated query
  ("cricket match score") correctly returned nothing
- Full end-to-end run against a realistic mock `changepoint_results.csv`
  matching both CONFIRMED and EMERGING/PROVISIONAL row types
