# RAG Explanation Layer — Always-Substantive Anomaly Explanations

Explains flagged change-points (from the analytics module) using real
documents where available, and genuine data-driven analysis always — never
a dead-end "nothing found" message. Handles both CONFIRMED (real data) and
EMERGING/PROVISIONAL (forecast-based) shifts, with the provisional warning
carried through.

## Core design principle
**Every explanation always states the actual quantitative shift and a
cross-bank/seasonal analytical read, computed directly from your own data.**
A matching document (RBI notice, NPCI circular, or news article) is added
context on top of this - never a requirement for the explanation to be
useful. This was a deliberate fix after testing showed the "no document
found" case reading as an unhelpful dead end - now it always leads with
real analysis instead.

## Four-tier retrieval, tried in order
1. **Precise match** - static document store (RBI + NPCI feeds), bank/month-specific query.
2. **Broad fallback** - static store, general UPI-reliability query (drops bank/month specifics).
3. **Live Google News search** (`rag/news_search.py`) - queried live per bank/month at
   explanation time, since day-to-day outage incidents show up in news coverage
   long before (or instead of) any official regulatory document.
4. **Analytical fallback** (always available, zero dependencies) - if nothing
   matches, the explanation is still built from:
   - The exact quantitative shift (before/after values, magnitude)
   - **Cross-bank pattern context**: how many *other* banks showed a similar
     shift the same month, computed from your own `changepoint_results.csv`
     - many banks affected together suggests a systemic/industry-wide cause;
     an isolated shift suggests something bank-specific
   - **Seasonal context**: whether the month coincides with a known
     industry-wide high-volume period in India (financial year-end in March,
     festive season in Oct/Nov) - stated as context, never as a confirmed cause

## Important fix: a false-positive guard on document matching
Testing surfaced a real problem worth knowing about: TF-IDF similarity can
score two completely unrelated documents as "matching" purely because they
share generic words like "Bank" or "Directions" - an RBI notice about an
entirely different bank's unrelated regulatory action scored 0.33 (above
the old 0.30 threshold) against a UPI-reliability query. Fixed by requiring
the word "UPI" to actually appear in a candidate document before it's
accepted as a match, regardless of similarity score (`rag/retriever.py`,
`require_keyword` parameter, default `"upi"`). Disable it by passing
`require_keyword=None` if you retarget this pipeline to a different topic.

## Two document sources for the static store

### RBI (general regulator feeds)
`rag/fetch_documents.py` pulls RBI's public RSS feeds (press releases,
notifications) - RSS 2.0 format.

### NPCI (UPI operator, genuinely more relevant)
Also pulls NPCI's own UPI-specific circulars via a community-maintained
Atom-format mirror (`captnemo.in/npci-rss-feeds`, sourced from
`npci.org.in/what-we-do/upi/circular`) - since NPCI operates UPI directly,
its circulars are inherently more relevant than RBI's general regulatory
feed. Honest caveat: this is a third-party mirror, not run by NPCI itself,
updated twice daily via GitHub Actions - reliable in testing, but worth
knowing it depends on someone else's community project staying maintained.
Both RSS 2.0 and Atom formats are auto-detected and parsed by the same
`parse_rss_content` function.

Both sources are deduplicated by URL and stored safely - re-running never double-inserts.

## How it stays "live" / regularly updated
- `rag/fetch_documents.py` only inserts genuinely new documents each run.
- The retrieval index (`rag/embeddings.py`) updates incrementally.
- No Task Scheduler required - see "Automation without Task Scheduler" below.

## 1. Install
```
pip install -r requirements.txt
```

## 2. Important network notes
- `fetch_documents.py` needs normal internet access to `rbi.org.in` and `captnemo.in`.
- `news_search.py` needs access to `news.google.com`.
- If you're on a restricted corporate network, any of these may be blocked
  by a proxy - handled gracefully everywhere (clear diagnostic output, safe
  fallback to the next tier) rather than crashing. Worst case, everything
  falls through to the analytical-only explanation, which is still fully substantive.

## 3. Required input
`changepoint_results.csv`, produced by the analytics module - copy it into this folder before running.

## 4. Run the full pipeline
```
python run_rag_pipeline.py
```
Or offline (skip the live document fetch, use whatever's already stored):
```
python run_rag_pipeline.py --skip-fetch
```

Produces `rag_explanations.csv` with columns: bank_name, change_month,
direction, status, explanation, match_type, top_source_title,
top_source_link, top_source_score.

`match_type` is one of: `precise`, `broad_fallback`, `news_search`, `none`
(`none` still gets a full analytical explanation, just without a document citation).

## 5. Two explanation modes

### Extractive (default, zero cost, zero extra setup)
No API key needed. Always includes the quantitative summary and cross-bank/
seasonal analysis; adds a document or news citation on top when a genuine match exists.

### LLM-polished (optional)
Set `ANTHROPIC_API_KEY` or `OPENAI_API_KEY` in a `.env` file. The LLM is
given both the retrieved documents AND the same cross-bank/seasonal
analytical context, and instructed to use only that - never adding outside
information. Falls back to extractive automatically on any API failure.

## 6. Retrieval backend - TF-IDF by default, on purpose
Defaults to TF-IDF (pure scikit-learn, no model download, works immediately
after `pip install`) rather than a neural embedding model, since the
semantic model needs to download from huggingface.co on first use - the
same class of problem as SMTP being blocked on a locked-down office
network. Upgrade to semantic matching by setting `USE_SEMANTIC_EMBEDDINGS =
True` in `rag/embeddings.py`, but test `huggingface.co` reachability first.

## 7. Automation without Task Scheduler
Three options, in order of simplicity:
- **Manual**: run `python run_rag_pipeline.py` before you need fresh results.
- **A simple loop script**, no admin rights needed:
  ```python
  import time, subprocess
  while True:
      subprocess.run(["python", "run_rag_pipeline.py"])
      time.sleep(24 * 60 * 60)
  ```
- **GitHub Actions** (if this is in a Git repo) - runs on GitHub's servers,
  works even if your laptop is off:
  ```yaml
  name: Refresh RAG
  on:
    schedule: [{cron: '0 6 * * *'}]
    workflow_dispatch:
  jobs:
    refresh:
      runs-on: ubuntu-latest
      steps:
        - uses: actions/checkout@v4
        - uses: actions/setup-python@v5
          with: {python-version: '3.11'}
        - run: pip install -r requirements.txt
        - run: python run_rag_pipeline.py
  ```

## 8. Config you can change
- `rag/config.py`: `MIN_RELEVANCE_SCORE`, `TOP_K_RESULTS`, `ALL_FEEDS`
- `rag/retriever.py`: `require_keyword` parameter on `retrieve()`
- `rag/explain.py`: `SEASONAL_CONTEXT` dict

## 9. What was actually tested before this was packaged
- RSS 2.0 parsing (RBI) and Atom parsing (NPCI) against real fetched content
- Deduplication (re-inserting the same documents correctly skips all of them)
- The false-positive guard: confirmed a spurious 0.33-score match was
  correctly rejected once the keyword filter was added, while genuine
  UPI-relevant matches (score 0.60) still passed correctly
- Google News query construction and parsing (their HTML-encoded description
  format), plus graceful failure when the network is blocked
- Full end-to-end runs producing substantive explanations in all scenarios:
  genuine document match, no document match with cross-bank context, and
  mixed CONFIRMED/EMERGING batches
