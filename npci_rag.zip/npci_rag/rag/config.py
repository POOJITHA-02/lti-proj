import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "..", "data", "npci_upi.db")
DB_PATH = os.path.abspath(DB_PATH)
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

EMBEDDINGS_CACHE_PATH = os.path.join(BASE_DIR, "embeddings_cache.pkl")

# Real, public RBI RSS feeds - confirmed live as of this project's build date.
# If RBI changes these URLs in future, update here only.
RBI_FEEDS = {
    "press_release": "https://www.rbi.org.in/pressreleases_rss.xml",
    "notification": "https://www.rbi.org.in/notifications_rss.xml",
}

EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"  # free, local, runs fine on CPU

# Minimum similarity score (cosine, 0-1) for a retrieved document to be
# considered a genuine match. Below this, we say so honestly rather than
# forcing a low-confidence match into a confident-sounding explanation.
MIN_RELEVANCE_SCORE = 0.30

TOP_K_RESULTS = 3

# Optional: set OPENAI_API_KEY or ANTHROPIC_API_KEY in a .env file at the
# project root to enable LLM-polished explanations. Without either, the
# system falls back to a fully free, local, extractive explanation - no
# API cost, no internet dependency beyond the RSS fetch itself.
