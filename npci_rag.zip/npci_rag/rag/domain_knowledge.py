"""
Curated, evergreen domain-knowledge documents about WHAT Technical Decline
(TD) and Business Decline (BD) actually are, their typical causes, and
documented industry context - as distinct from date-specific news/circulars.

Why this exists: news articles and regulatory circulars only cover SPECIFIC
named incidents. But most flagged change-points won't have a specific news
story attached to them - what they DO always deserve is grounding in the
general, well-documented facts about why TD/BD happens at all. This module
provides that layer, so an explanation is never limited to "here's a news
article" - it always has real domain knowledge to draw on.

Content below is paraphrased in original wording from publicly known,
widely-reported facts about UPI performance benchmarks and failure
categories (e.g. NPCI's Circular OC-149 setting TD/BD targets, and widely
reported historical decline-rate trends) - not reproduced verbatim from any
single source. These are treated as REFERENCE documents (pub_date is fixed
as "Reference", not tied to a specific date), and are always included in the
retrieval index alongside date-specific RBI/NPCI/news documents.
"""

DOMAIN_KNOWLEDGE_DOCS = [
    {
        "title": "Definition and Causes of Technical Decline (TD) in UPI Transactions",
        "content": (
            "Technical Decline (TD) refers to UPI transaction failures caused by infrastructure "
            "or system-level issues on the bank's or NPCI's side, rather than by the customer. "
            "Typical causes include: bank server unavailability or timeout during peak load, "
            "core banking system downtime or maintenance windows, network connectivity failures "
            "between the bank and NPCI's switch, and NPCI-side switch capacity constraints during "
            "high-volume periods. Because TD reflects infrastructure reliability rather than user "
            "error, NPCI has set an industry benchmark target of TD remaining below 1% (per "
            "NPCI Circular OC-149, June 2022). A bank's TD rate rising meaningfully above this "
            "target, or above its own historical baseline, is generally read as a signal of "
            "genuine technical/infrastructure strain rather than routine variation."
        ),
        "link": "reference://domain-knowledge/technical-decline-definition",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Definition and Causes of Business Decline (BD) in UPI Transactions",
        "content": (
            "Business Decline (BD) refers to UPI transaction failures caused by the transaction "
            "itself or the customer's account/input, rather than by infrastructure failure. "
            "Typical causes include: insufficient account balance, incorrect UPI PIN or OTP entry, "
            "exceeding per-transaction or per-day transaction limits, an invalid or non-existent "
            "beneficiary VPA (virtual payment address), an expired or cancelled mandate, and "
            "customer-initiated cancellation mid-transaction. Because BD reflects user-side or "
            "transaction-specific factors rather than bank infrastructure, it is expected to run "
            "meaningfully higher than TD in normal operation - NPCI's benchmark target for BD is "
            "below 5% (per NPCI Circular OC-149, June 2022), five times the TD target, reflecting "
            "that a certain baseline rate of user error and insufficient-balance attempts is "
            "considered normal transaction behavior rather than a system health signal in itself."
        ),
        "link": "reference://domain-knowledge/business-decline-definition",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Historical Trend of UPI Technical Decline Rates",
        "content": (
            "System-wide UPI technical decline rates have improved substantially since the "
            "platform's early years. In UPI's initial rollout period (around 2016), system-wide "
            "technical decline rates were commonly reported in the 8-10% range, reflecting "
            "immature bank-side infrastructure and limited NPCI switch capacity relative to "
            "transaction volume. As banks modernized core banking systems and NPCI scaled its "
            "switching infrastructure over the following years, system-wide technical decline "
            "fell steadily, reaching roughly 0.7-0.8% by the mid-2020s and continuing to trend "
            "toward the sub-1% target range more recently. This long-run improvement trend means "
            "that a bank showing technical decline meaningfully above roughly 1-2% in the current "
            "period stands out as a genuine outlier relative to where the overall industry now "
            "operates, not merely a return to historically 'normal' variation."
        ),
        "link": "reference://domain-knowledge/historical-td-trend",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Common Sub-Causes Behind UPI Transaction Failures - A Breakdown",
        "content": (
            "Within Technical Decline, bank-side server timeouts and unavailability are typically "
            "the largest single contributor, followed by network connectivity issues between the "
            "bank and NPCI, and then NPCI switch-level capacity constraints during unusually high "
            "transaction volume. Within Business Decline, insufficient account balance and "
            "incorrect PIN/OTP entry together typically account for the majority of failures, with "
            "transaction-limit breaches and invalid beneficiary details making up most of the "
            "remainder. When a bank's decline rate shifts sharply in a short period, distinguishing "
            "whether the shift is concentrated in TD (pointing to an infrastructure/technical cause) "
            "or BD (pointing to a customer-behavior or transaction-pattern cause) is the first "
            "useful diagnostic step, since the two categories point toward entirely different "
            "root causes and remediation owners (the bank's IT/infrastructure team for TD, versus "
            "customer communication or fraud/limit-policy review for BD)."
        ),
        "link": "reference://domain-knowledge/failure-subcause-breakdown",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Seasonal and Cyclical Factors Affecting UPI Transaction Volume and Reliability",
        "content": (
            "UPI transaction volumes are not evenly distributed across the year, and this has "
            "documented effects on system reliability metrics. Financial year-end (March in India) "
            "sees a genuine, well-recognized surge in transaction volume tied to corporate and "
            "retail settlement activity, increasing load on both bank-side and NPCI-side "
            "infrastructure; industry commentary has specifically attributed periodic system "
            "slowdowns during this window to this year-end transaction rush. Similarly, India's "
            "festive season (broadly October-November, coinciding with Diwali-period retail and "
            "gifting activity) drives industry-wide transaction volume well above baseline. A "
            "decline-rate shift occurring during either of these windows is more plausibly linked "
            "to genuine, industry-wide seasonal load than to a bank-specific issue - particularly "
            "if multiple banks show a similar shift in the same period, which is consistent with a "
            "shared, volume-driven cause rather than an isolated institutional problem."
        ),
        "link": "reference://domain-knowledge/seasonal-factors",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Definition and Causes of Debit Reversal Failure in UPI Transactions",
        "content": (
            "When a UPI transaction fails or is declined after the payer's account has already "
            "been debited, NPCI's system is required to automatically reverse (refund) that debit "
            "back to the customer's account. The Debit Reversal Success Rate measures how often "
            "this automatic reversal completes correctly and promptly; a Debit Reversal Failure "
            "(the complement of this success rate) means a customer's money was debited but not "
            "correctly or promptly returned despite the underlying transaction failing. Typical "
            "causes of reversal failure include: a fault in the bank's or NPCI's reversal-processing "
            "workflow distinct from the original transaction path, a timeout in the reversal "
            "settlement window, a mismatch between the debit and credit legs during reconciliation, "
            "and core banking system issues specifically affecting the refund/reversal "
            "microservice rather than the primary payment path. Because a failed reversal leaves a "
            "customer's money in limbo even though the payment itself did not succeed, reversal "
            "failure is treated as a particularly customer-sensitive reliability metric - it can "
            "generate complaints and disputes even when the underlying transaction decline rate "
            "itself looks otherwise normal, since the customer experiences both a failed payment "
            "AND a delayed refund."
        ),
        "link": "reference://domain-knowledge/reversal-failure-definition",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
    {
        "title": "Why Debit Reversal Volume Differs from Transaction Decline Volume",
        "content": (
            "The Total Debit Reversal Count reflects how many transactions required a reversal in "
            "a given period - which is not the same number as the count of declined transactions, "
            "since not every decline requires a reversal (a transaction can be declined before the "
            "customer's account is ever debited) and reversal timing can lag the original decline "
            "across a reporting boundary. A rising reversal count without a corresponding rise in "
            "the technical or business decline rate can indicate a growing backlog or processing "
            "delay in the reversal workflow specifically, rather than a worsening of the underlying "
            "payment success rate - these are related but distinct signals, and a genuine reversal-"
            "specific issue should be diagnosed separately from a general decline-rate investigation."
        ),
        "link": "reference://domain-knowledge/reversal-count-vs-decline",
        "pub_date": "Reference",
        "doc_type": "domain_knowledge",
    },
]


def get_domain_knowledge_documents():
    """Returns the curated domain-knowledge document list, ready to be stored
    in the same rbi_documents table as fetched RSS content."""
    return DOMAIN_KNOWLEDGE_DOCS
