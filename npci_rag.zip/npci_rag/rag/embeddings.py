"""
Builds and maintains a local retrieval index over rbi_documents.

TWO BACKENDS, chosen automatically:

1. TF-IDF (default) - pure scikit-learn, works completely offline after the
   initial `pip install`. No model download, no internet dependency beyond
   fetching the RBI documents themselves. This is the safe default for a
   locked-down office laptop that may not have access to huggingface.co.

2. Sentence-Transformers (optional upgrade) - better semantic matching (can
   match "technical decline" to "processing errors" even without exact
   keyword overlap), but requires downloading a ~90MB model from
   huggingface.co on first use. Enable it by setting USE_SEMANTIC_EMBEDDINGS
   = True below IF your network allows it - test this first before relying
   on it, since some corporate networks block huggingface.co the same way
   they sometimes block SMTP or other external services.

Both backends are rebuilt incrementally - only new documents are processed
each time this runs, not the whole store from scratch.
"""

import os
import sys
import pickle
import sqlite3
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.config import DB_PATH, EMBEDDINGS_CACHE_PATH, EMBEDDING_MODEL_NAME

# Set this to True only after confirming your network can reach huggingface.co
# (run a quick test: python -c "from sentence_transformers import SentenceTransformer;
# SentenceTransformer('all-MiniLM-L6-v2')" - if that fails, leave this False).
USE_SEMANTIC_EMBEDDINGS = False

_model = None
_vectorizer = None


def _get_semantic_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return _model


def _load_cache():
    if os.path.exists(EMBEDDINGS_CACHE_PATH):
        with open(EMBEDDINGS_CACHE_PATH, "rb") as f:
            return pickle.load(f)
    return {"backend": None, "doc_ids": [], "vectors": None, "vectorizer": None, "texts": []}


def _save_cache(cache):
    with open(EMBEDDINGS_CACHE_PATH, "wb") as f:
        pickle.dump(cache, f)


def _fetch_all_documents():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT id, title, content FROM rbi_documents")
    docs = cur.fetchall()
    conn.close()
    return docs


def update_embeddings():
    """Rebuilds/updates the retrieval index. Returns the cache dict used by retriever.py."""
    all_docs = _fetch_all_documents()
    if not all_docs:
        print("No documents in rbi_documents yet - run fetch_documents.py first.")
        return _load_cache()

    cache = _load_cache()
    backend = "semantic" if USE_SEMANTIC_EMBEDDINGS else "tfidf"

    if cache.get("backend") not in (None, backend):
        print("Backend changed (%s -> %s) - rebuilding index from scratch." % (cache.get("backend"), backend))
        cache = {"backend": None, "doc_ids": [], "vectors": None, "vectorizer": None, "texts": []}

    known_ids = set(cache["doc_ids"])
    new_docs = [d for d in all_docs if d["id"] not in known_ids]

    if not new_docs and cache["doc_ids"]:
        print("Index already up to date - no new documents (%d total indexed)." % len(cache["doc_ids"]))
        return cache

    print("Indexing %d new document(s) using '%s' backend..." % (len(new_docs), backend))

    all_current_docs = [d for d in all_docs]  # TF-IDF needs to be refit on the full corpus each time
    all_texts = [d["title"] + ". " + d["content"] for d in all_current_docs]
    all_ids = [d["id"] for d in all_current_docs]

    if backend == "semantic":
        model = _get_semantic_model()
        vectors = model.encode(all_texts, show_progress_bar=False, normalize_embeddings=True)
        cache = {"backend": "semantic", "doc_ids": all_ids, "vectors": np.array(vectors, dtype=np.float32),
                 "vectorizer": None, "texts": all_texts}
    else:
        from sklearn.feature_extraction.text import TfidfVectorizer
        vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
        vectors = vectorizer.fit_transform(all_texts)
        cache = {"backend": "tfidf", "doc_ids": all_ids, "vectors": vectors,
                 "vectorizer": vectorizer, "texts": all_texts}

    _save_cache(cache)
    print("Index updated. Total documents indexed: %d" % len(cache["doc_ids"]))
    return cache


if __name__ == "__main__":
    update_embeddings()
