"""
Reads changepoint_results.csv (from the analytics module) and generates an
explanation for each flagged shift, using retrieved RBI documents where
possible.

KEY DESIGN PRINCIPLE: every explanation ALWAYS states the actual quantitative
shift first (before/after values, magnitude) - a matching RBI document is
additional context, not a requirement. This means the explanation is never a
dead-end "nothing found" message; it always tells you what the data itself
shows, then adds regulatory context on top if a genuinely relevant document
exists.

RETRIEVAL, in order:
  1. Precise query (bank name + month + direction) - most specific match.
  2. If nothing meets the relevance bar, a broader query (drops bank/month,
     searches just for the general type of event) - more likely to find
     SOMETHING, clearly labeled as general context rather than event-specific.
  3. If even that finds nothing, the explanation still stands on the
     quantitative summary alone, with an honest note about why (RBI's RSS
     feed only reflects recent items, not a full historical archive).

TWO EXPLANATION MODES:
  - Extractive (default, free, no API key, no internet beyond the RBI fetch).
  - LLM-polished (optional, if OPENAI_API_KEY/ANTHROPIC_API_KEY is set) -
    grounded strictly in retrieved text, never adding outside information.
    Falls back to extractive automatically if the API call fails for any
    reason (bad key, rate limit, no internet).
"""

import os
import sys
import pandas as pd
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.retriever import retrieve

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")


def build_query(row):
    direction_term = "decline worsening technical failure" if row["direction"] == "WORSENED" else "improvement reliability"
    return "%s UPI bank %s %s technical decline business decline" % (
        row["bank_name"], direction_term, row["change_month"]
    )


def build_broader_query(row):
    if row["direction"] == "WORSENED":
        return "UPI payment technical decline transaction failure banks"
    return "UPI payment reliability improvement banks"


def retrieve_with_fallback(row):
    """Tries the precise query first; if nothing meets the relevance bar, tries
    a broader query before giving up. Returns (results, match_type)."""
    results = retrieve(build_query(row))
    if results:
        return results, "precise"
    broader_results = retrieve(build_broader_query(row))
    if broader_results:
        return broader_results, "broad_fallback"
    return [], "none"


def _quant_summary(row):
    magnitude = row.get("magnitude_pct_points", row["avg_after"] - row["avg_before"])
    return "%s's decline rate moved from %.3f%% to %.3f%% around %s (a change of %.3f percentage points)." % (
        row["bank_name"], row["avg_before"], row["avg_after"], row["change_month"], magnitude
    )


def extractive_explanation(row, retrieved, match_type="precise"):
    """Free, local, no-API-key explanation. Always leads with the quantitative
    summary, regardless of whether a matching document was found."""
    quant_summary = _quant_summary(row)

    if not retrieved:
        return (
            "%s No RBI press release or notification in the current document store "
            "was found to be relevant to this event, even after broadening the search. "
            "This most likely means RBI's public feed simply didn't cover this specific "
            "bank/period (the RSS feed only reflects recent items, not a full historical "
            "archive) - it does not mean nothing happened, only that no matching public "
            "document is currently available in this store." % quant_summary
        )

    top = retrieved[0]
    doc = top["document"]
    excerpt = doc["content"][:280].rsplit(" ", 1)[0] + "..."
    caveat = (
        " (Note: no document specific to this bank/month was found - this is a general "
        "UPI-related document instead, shown as the closest available context, not a "
        "specific explanation of this event.)"
        if match_type == "broad_fallback" else ""
    )
    return (
        "%s Closest matching RBI document found (similarity score %.2f): \"%s\" (%s).%s "
        "Excerpt: %s [Source: %s]" % (
            quant_summary, top["score"], doc["title"], doc["pub_date"], caveat, excerpt, doc["link"]
        )
    )


def llm_explanation(row, retrieved, match_type="precise"):
    """Optional LLM-polished explanation, grounded strictly in retrieved text.
    Falls back to the extractive explanation (with the SAME arguments) on any failure."""
    if not retrieved:
        return extractive_explanation(row, retrieved, match_type)

    context = "\n\n".join(
        "Document: %s (%s)\n%s" % (r["document"]["title"], r["document"]["pub_date"], r["document"]["content"][:600])
        for r in retrieved
    )

    prompt = (
        "You are explaining a detected change in a bank's UPI technical/business decline rate, "
        "using ONLY the RBI documents provided below. Do not add any information not present in "
        "these documents. If the documents don't clearly explain the change, say so explicitly "
        "rather than guessing.\n\n"
        "Bank: %s\nMonth: %s\nDirection: %s (%.3f -> %.3f percentage points)\n\n"
        "Retrieved RBI documents:\n%s\n\n"
        "Write a 2-3 sentence grounded explanation, citing which document (by title) supports it."
    ) % (row["bank_name"], row["change_month"], row["direction"], row["avg_before"], row["avg_after"], context)

    try:
        if ANTHROPIC_API_KEY:
            import anthropic
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            response = client.messages.create(
                model="claude-haiku-4-5-20251001", max_tokens=200,
                messages=[{"role": "user", "content": prompt}]
            )
            return _quant_summary(row) + " " + response.content[0].text.strip()
        elif OPENAI_API_KEY:
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini", max_tokens=200,
                messages=[{"role": "user", "content": prompt}]
            )
            return _quant_summary(row) + " " + response.choices[0].message.content.strip()
    except Exception as e:
        print("  [LLM call failed, falling back to extractive explanation] %s" % str(e)[:150])
        return extractive_explanation(row, retrieved, match_type)

    return extractive_explanation(row, retrieved, match_type)


def explain_changepoints(changepoint_csv_path="changepoint_results.csv", output_path="rag_explanations.csv"):
    df = pd.read_csv(changepoint_csv_path)
    use_llm = bool(ANTHROPIC_API_KEY or OPENAI_API_KEY)
    print("Generating explanations for %d flagged shift(s) using %s mode.\n" % (
        len(df), "LLM-polished" if use_llm else "extractive (free, local)"))

    results = []
    match_stats = {"precise": 0, "broad_fallback": 0, "none": 0}

    for _, row in df.iterrows():
        retrieved, match_type = retrieve_with_fallback(row)
        match_stats[match_type] += 1

        if use_llm:
            explanation = llm_explanation(row, retrieved, match_type)
        else:
            explanation = extractive_explanation(row, retrieved, match_type)

        status = "CONFIRMED" if not row.get("is_provisional", False) else "EMERGING (PROVISIONAL)"
        full_explanation = explanation
        if row.get("is_provisional", False) and row.get("warning"):
            full_explanation = str(row["warning"]) + " " + explanation

        results.append({
            "bank_name": row["bank_name"],
            "change_month": row["change_month"],
            "direction": row["direction"],
            "status": status,
            "explanation": full_explanation,
            "match_type": match_type,
            "top_source_title": retrieved[0]["document"]["title"] if retrieved else None,
            "top_source_link": retrieved[0]["document"]["link"] if retrieved else None,
            "top_source_score": retrieved[0]["score"] if retrieved else None,
        })

        match_label = {"precise": "matched (bank-specific)", "broad_fallback": "matched (general context only)",
                       "none": "no relevant document - statistical summary only"}[match_type]
        print("  %-30s %s (%s) -> %s" % (row["bank_name"], row["change_month"], status, match_label))

    result_df = pd.DataFrame(results)
    result_df.to_csv(output_path, index=False)

    print("\nSaved %d explanations to %s" % (len(result_df), output_path))
    print("Match breakdown: %d bank-specific, %d general-context-only, %d statistical-summary-only." % (
        match_stats["precise"], match_stats["broad_fallback"], match_stats["none"]))
    return result_df


if __name__ == "__main__":
    explain_changepoints()
