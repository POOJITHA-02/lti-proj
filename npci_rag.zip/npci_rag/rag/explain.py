"""
Reads changepoint_results.csv (from the analytics module) and generates an
explanation for each flagged shift, using retrieved RBI documents where
possible.

KEY DESIGN PRINCIPLE: every explanation ALWAYS states the actual quantitative
shift first (before/after values, magnitude) - a matching RBI document is
additional context, not a requirement. This means the explanation is never a
dead-end "nothing found" message; it always tells you what the data itself
shows, then adds regulatory context on top if a genuinely relevant document
exists.

RETRIEVAL, in order:
  1. Precise query (bank name + month + direction) - most specific match.
  2. If nothing meets the relevance bar, a broader query (drops bank/month,
     searches just for the general type of event) - more likely to find
     SOMETHING, clearly labeled as general context rather than event-specific.
  3. If even that finds nothing, the explanation still stands on the
     quantitative summary alone, with an honest note about why (RBI's RSS
     feed only reflects recent items, not a full historical archive).

TWO EXPLANATION MODES:
  - Extractive (default, free, no API key, no internet beyond the RBI fetch).
  - LLM-polished (optional, if OPENAI_API_KEY/ANTHROPIC_API_KEY is set) -
    grounded strictly in retrieved text, never adding outside information.
    Falls back to extractive automatically if the API call fails for any
    reason (bad key, rate limit, no internet).
"""

import os
import sys
import pandas as pd
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.retriever import retrieve
from rag.news_search import search_bank_news

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# Human-readable label and display unit per metric - used throughout so an
# explanation says "technical decline rate...5.2%" for td_pct but "debit
# reversal count...12.4 Mn" for the count metric, never a generic
# "decline rate" label or a wrong "%" sign on a count value.
METRIC_LABELS = {
    "td_pct": ("technical decline rate", "%"),
    "bd_pct": ("business decline rate", "%"),
    "reversal_failure_pct": ("debit reversal failure rate", "%"),
    "total_debit_reversal_count_mn": ("debit reversal count", " Mn"),
}


def _get_metric_label(row):
    """Reads the metric from the row (present in changepoint_results.csv as of
    the multi-metric analytics update) and returns (label, unit). Falls back
    to td_pct's labeling if an older changepoint file without a 'metric'
    column is used, for backward compatibility."""
    metric = row.get("metric", "td_pct") if hasattr(row, "get") else "td_pct"
    if pd.isna(metric):
        metric = "td_pct"
    return METRIC_LABELS.get(metric, ("decline rate", "%")), metric


def build_query(row):
    (label, _), metric = _get_metric_label(row)
    if metric == "reversal_failure_pct":
        topic_terms = "debit reversal failure delayed reversal refund processing"
    elif metric == "total_debit_reversal_count_mn":
        topic_terms = "debit reversal volume count processing"
    elif metric == "bd_pct":
        topic_terms = "business decline insufficient balance transaction limit"
    else:
        topic_terms = "technical decline business decline"
    direction_term = "decline worsening technical failure" if row["direction"] == "WORSENED" else "improvement reliability"
    return "%s UPI bank %s %s %s" % (row["bank_name"], direction_term, row["change_month"], topic_terms)


# Indian financial/seasonal periods with well-documented, genuinely elevated
# UPI transaction volumes industry-wide - used only as descriptive context
# (never stated as a confirmed cause) to give the reader something concrete
# to reason about when no specific document explains an event.
SEASONAL_CONTEXT = {
    3: "March (financial year-end) - a period of industry-wide elevated transaction volumes in India",
    10: "October (festive/Diwali season) - a period of industry-wide elevated transaction volumes in India",
    11: "November (festive season) - a period of industry-wide elevated transaction volumes in India",
    1: "January (New Year) - a period of typically elevated retail transaction activity",
}


def build_cross_bank_context(row, full_df):
    """
    Checks how many OTHER banks had a shift in the SAME direction in the SAME
    month - this is genuinely informative even with zero matching documents:
    a shift shared by many banks at once points toward a systemic/industry-wide
    cause (e.g. NPCI infrastructure load, a festival volume spike); a shift
    isolated to one bank points toward a bank-specific/internal cause. This
    is descriptive pattern-matching from data we already have, not a guess.
    """
    same_month = full_df[full_df["change_month"] == row["change_month"]]
    same_month_same_direction = same_month[same_month["direction"] == row["direction"]]

    other_banks_affected = same_month_same_direction["bank_name"].nunique() - 1  # exclude this bank itself
    total_banks_with_any_shift_that_month = same_month["bank_name"].nunique()

    month_num = int(row["change_month"].split("-")[1])
    seasonal_note = SEASONAL_CONTEXT.get(month_num)

    direction_word = row["direction"].lower()
    article = "an" if direction_word.startswith(("i", "a", "e", "o", "u")) else "a"

    parts = []
    if other_banks_affected >= 3:
        parts.append(
            "This is NOT isolated: %d other bank(s) also showed %s %s shift in %s, suggesting a "
            "possible industry-wide or systemic factor (e.g. NPCI-side load, a shared infrastructure "
            "dependency, or a seasonal volume spike) rather than an issue specific to this bank alone."
            % (other_banks_affected, article, direction_word, row["change_month"])
        )
    elif other_banks_affected >= 1:
        parts.append(
            "%d other bank(s) also showed a similar %s shift in %s - a partial pattern worth checking "
            "against broader system-level events, though not conclusive on its own."
            % (other_banks_affected, direction_word, row["change_month"])
        )
    else:
        parts.append(
            "No other bank showed a similar shift in %s, suggesting this is specific to this bank's "
            "own systems or operations rather than an industry-wide event." % row["change_month"]
        )

    if seasonal_note:
        parts.append("This also coincides with %s, which is worth considering as general context." % seasonal_note)

    return " ".join(parts)


def build_broader_query(row):
    (label, _), metric = _get_metric_label(row)
    if metric == "reversal_failure_pct" or metric == "total_debit_reversal_count_mn":
        topic = "debit reversal failure processing"
    elif metric == "bd_pct":
        topic = "business decline transaction failure"
    else:
        topic = "technical decline transaction failure"
    if row["direction"] == "WORSENED":
        return "UPI payment %s banks" % topic
    return "UPI payment reliability improvement banks"


def retrieve_with_fallback(row, use_news_search=True):
    """
    Three-tier EVENT-SPECIFIC retrieval, tried in order (domain-knowledge
    reference documents are deliberately excluded here via exclude_doc_types,
    so they don't crowd out a genuine event-specific match - domain knowledge
    is retrieved separately, always, via retrieve_domain_knowledge below):
      1. Precise query against the static store (RBI + NPCI feeds) - most specific.
      2. Broader query against the static store - general regulatory context.
      3. Live Google News search for this specific bank/month - most likely to
         catch an actual reported incident, since neither RBI nor NPCI's
         official feeds cover day-to-day outage news.
    Returns (results, match_type) where match_type is one of:
    'precise', 'broad_fallback', 'news_search', or 'none'.
    """
    results = retrieve(build_query(row), exclude_doc_types=["domain_knowledge"])
    if results:
        return results, "precise"

    broader_results = retrieve(build_broader_query(row), exclude_doc_types=["domain_knowledge"])
    if broader_results:
        return broader_results, "broad_fallback"

    if use_news_search:
        (label, _), metric = _get_metric_label(row)
        news_results = search_bank_news(row["bank_name"], row["change_month"], row["direction"], metric=metric)
        if news_results:
            return [{"document": d, "score": None} for d in news_results], "news_search"

    return [], "none"


def retrieve_domain_knowledge(row, top_k=2):
    """
    Retrieves the most relevant curated domain-knowledge reference document(s)
    (TD/BD/reversal definitions, causes, historical trends, seasonal factors)
    for this row - run ALWAYS, independent of whether an event-specific
    document was found, since general domain knowledge about why this metric
    moves is useful context regardless. This is what makes explanations
    substantive even when no specific news/circular exists for this exact event.
    """
    (label, _), metric = _get_metric_label(row)
    direction_term = "worsening failure increase" if row["direction"] == "WORSENED" else "improvement reliability"

    if metric in ("reversal_failure_pct", "total_debit_reversal_count_mn"):
        query = "UPI debit reversal failure %s causes definition processing" % direction_term
    elif metric == "bd_pct":
        query = "UPI business decline %s causes definition insufficient balance" % direction_term
    else:
        query = "UPI technical decline %s causes definition server infrastructure" % direction_term

    return retrieve(query, top_k=top_k, doc_type_filter="domain_knowledge", min_score=0.05)


def _quant_summary(row):
    (label, unit), metric = _get_metric_label(row)
    magnitude = row.get("magnitude_pct_points", row["avg_after"] - row["avg_before"])
    return "%s's %s moved from %.3f%s to %.3f%s around %s (a change of %.3f%s)." % (
        row["bank_name"], label, row["avg_before"], unit, row["avg_after"], unit,
        row["change_month"], magnitude, unit
    )


def _format_domain_knowledge_note(domain_docs):
    """Formats the always-present domain-knowledge layer of an explanation."""
    if not domain_docs:
        return ""
    parts = []
    for d in domain_docs[:2]:
        doc = d["document"]
        excerpt = doc["content"][:320].rsplit(" ", 1)[0] + "..."
        parts.append("According to documented UPI industry definitions (\"%s\"): %s" % (doc["title"], excerpt))
    return " ".join(parts)


def extractive_explanation(row, retrieved, match_type="precise", full_df=None, domain_docs=None):
    """Free, local, no-API-key explanation. Always leads with the quantitative
    summary, ALWAYS includes cross-bank/seasonal analytical context, and
    ALWAYS includes relevant domain knowledge about TD/BD causes in general -
    an event-specific document match adds on top of these, it is never the
    only content, so this function never dead-ends on 'nothing found'."""
    quant_summary = _quant_summary(row)
    analytical_context = build_cross_bank_context(row, full_df) if full_df is not None else ""
    domain_note = _format_domain_knowledge_note(domain_docs)

    if not retrieved:
        source_note = (
            "No RBI press release, NPCI circular, or recent news coverage was found specific to "
            "this exact event (this does not mean nothing happened - only that no matching "
            "event-specific document or news report is currently available)."
        )
        return " ".join(p for p in [quant_summary, analytical_context, domain_note, source_note] if p)

    top = retrieved[0]
    doc = top["document"]
    excerpt = doc["content"][:280].rsplit(" ", 1)[0] + "..."

    if match_type == "broad_fallback":
        caveat = (" (Note: no document specific to this bank/month was found - this is a general "
                  "UPI-related regulatory document instead, shown as the closest available context, "
                  "not a specific explanation of this event.)")
        source_label = "Closest matching RBI/NPCI document found"
    elif match_type == "news_search":
        caveat = (" (Note: this is a NEWS report, not an official RBI/NPCI document - found via live "
                  "search since no matching regulatory circular was available. Verify against the "
                  "original source before treating this as confirmed.)")
        source_label = "Related news coverage found"
    else:
        caveat = ""
        source_label = "Closest matching RBI/NPCI document found"

    score_text = " (similarity score %.2f)" % top["score"] if top["score"] is not None else ""
    document_note = (
        "%s%s: \"%s\" (%s).%s Excerpt: %s [Source: %s]" % (
            source_label, score_text, doc["title"], doc["pub_date"], caveat, excerpt, doc["link"]
        )
    )
    return " ".join(p for p in [quant_summary, analytical_context, domain_note, document_note] if p)


def llm_explanation(row, retrieved, match_type="precise", full_df=None, domain_docs=None):
    """Optional LLM-polished explanation, grounded strictly in retrieved text
    plus the same cross-bank/seasonal analytical context and domain-knowledge
    layer used in the extractive mode. Falls back to the extractive
    explanation (same arguments) on any failure."""
    analytical_context = build_cross_bank_context(row, full_df) if full_df is not None else ""
    domain_note = _format_domain_knowledge_note(domain_docs)

    if not retrieved:
        return extractive_explanation(row, retrieved, match_type, full_df, domain_docs)

    context = "\n\n".join(
        "Document: %s (%s)\n%s" % (r["document"]["title"], r["document"]["pub_date"], r["document"]["content"][:600])
        for r in retrieved
    )

    prompt = (
        "You are explaining a detected change in a bank's UPI technical/business decline rate. "
        "Use the RBI/NPCI/news documents below, the domain-knowledge context, AND the data-driven "
        "cross-bank pattern context provided - do not add any information beyond these sources. "
        "If the event-specific documents don't clearly explain the change, rely on the domain "
        "knowledge and cross-bank pattern context instead, stated plainly.\n\n"
        "Bank: %s\nMonth: %s\nDirection: %s (%.3f -> %.3f percentage points)\n\n"
        "Domain knowledge (general TD/BD causes and definitions): %s\n\n"
        "Cross-bank pattern context (derived from the actual dataset): %s\n\n"
        "Retrieved event-specific documents:\n%s\n\n"
        "Write a 3-4 sentence grounded explanation, citing which document (by title) supports it, "
        "and referencing the domain knowledge and cross-bank context where relevant."
    ) % (row["bank_name"], row["change_month"], row["direction"], row["avg_before"], row["avg_after"],
         domain_note, analytical_context, context)

    try:
        if ANTHROPIC_API_KEY:
            import anthropic
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            response = client.messages.create(
                model="claude-haiku-4-5-20251001", max_tokens=250,
                messages=[{"role": "user", "content": prompt}]
            )
            return _quant_summary(row) + " " + response.content[0].text.strip()
        elif OPENAI_API_KEY:
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini", max_tokens=250,
                messages=[{"role": "user", "content": prompt}]
            )
            return _quant_summary(row) + " " + response.choices[0].message.content.strip()
    except Exception as e:
        print("  [LLM call failed, falling back to extractive explanation] %s" % str(e)[:150])
        return extractive_explanation(row, retrieved, match_type, full_df, domain_docs)

    return extractive_explanation(row, retrieved, match_type, full_df, domain_docs)


def explain_changepoints(changepoint_csv_path="changepoint_results.csv", output_path="rag_explanations.csv"):
    df = pd.read_csv(changepoint_csv_path)
    use_llm = bool(ANTHROPIC_API_KEY or OPENAI_API_KEY)
    print("Generating explanations for %d flagged shift(s) using %s mode.\n" % (
        len(df), "LLM-polished" if use_llm else "extractive (free, local)"))

    results = []
    match_stats = {"precise": 0, "broad_fallback": 0, "news_search": 0, "none": 0}
    domain_match_count = 0

    for _, row in df.iterrows():
        retrieved, match_type = retrieve_with_fallback(row)
        match_stats[match_type] += 1

        domain_docs = retrieve_domain_knowledge(row)
        if domain_docs:
            domain_match_count += 1

        if use_llm:
            explanation = llm_explanation(row, retrieved, match_type, full_df=df, domain_docs=domain_docs)
        else:
            explanation = extractive_explanation(row, retrieved, match_type, full_df=df, domain_docs=domain_docs)

        status = "CONFIRMED" if not row.get("is_provisional", False) else "EMERGING (PROVISIONAL)"
        full_explanation = explanation
        if row.get("is_provisional", False) and row.get("warning"):
            full_explanation = str(row["warning"]) + " " + explanation

        results.append({
            "bank_name": row["bank_name"],
            "change_month": row["change_month"],
            "direction": row["direction"],
            "status": status,
            "explanation": full_explanation,
            "match_type": match_type,
            "domain_knowledge_included": bool(domain_docs),
            "top_source_title": retrieved[0]["document"]["title"] if retrieved else None,
            "top_source_link": retrieved[0]["document"]["link"] if retrieved else None,
            "top_source_score": retrieved[0]["score"] if retrieved else None,
        })

        match_label = {
            "precise": "matched (bank-specific document)",
            "broad_fallback": "matched (general regulatory context)",
            "news_search": "matched (live news search)",
            "none": "no event-specific document - domain knowledge + cross-bank/seasonal analysis",
        }[match_type]
        print("  %-30s %s (%s) -> %s" % (row["bank_name"], row["change_month"], status, match_label))

    result_df = pd.DataFrame(results)
    result_df.to_csv(output_path, index=False)

    print("\nSaved %d explanations to %s" % (len(result_df), output_path))
    print("Match breakdown: %d bank-specific, %d general-context, %d news-search, %d analytical-only (no event-specific document)." % (
        match_stats["precise"], match_stats["broad_fallback"], match_stats["news_search"], match_stats["none"]))
    print("Domain knowledge (TD/BD definitions, causes, trends) included in %d of %d explanations." % (
        domain_match_count, len(result_df)))
    return result_df


if __name__ == "__main__":
    explain_changepoints()
