"""
Reads changepoint_results.csv (from the analytics module) and generates a
grounded explanation for each flagged shift, using retrieved RBI documents.

TWO EXPLANATION MODES, chosen automatically:

1. Extractive (default, always available) - no API key, no internet beyond
   the RBI document fetch, zero cost. Reports the most relevant retrieved
   document's title and a short excerpt, honestly framed as "the closest
   matching regulatory context found" - not a confident causal claim.

2. LLM-polished (optional) - if OPENAI_API_KEY or ANTHROPIC_API_KEY is set
   in a .env file, uses the LLM to write a short 2-3 sentence explanation,
   but the LLM is instructed to use ONLY the retrieved document text as
   context - never to add outside information. This is what makes it RAG
   rather than free generation: retrieval happens first and independently,
   generation only summarizes what was actually retrieved.

Both modes clearly carry the CONFIRMED vs. PROVISIONAL/EMERGING distinction
from the change-point detection module, and never claim a retrieved document
proves causation - only that it's the most relevant available context.
"""

import os
import sys
import pandas as pd
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.retriever import retrieve
from rag.config import MIN_RELEVANCE_SCORE

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")


def build_query(row):
    """Constructs a search query from a change-point row's bank/direction/month."""
    direction_term = "decline worsening technical failure" if row["direction"] == "WORSENED" else "improvement reliability"
    return "%s UPI bank %s %s technical decline business decline" % (
        row["bank_name"], direction_term, row["change_month"]
    )


def extractive_explanation(retrieved):
    """No-API-key fallback: builds an explanation directly from the retrieved text."""
    if not retrieved:
        return ("No sufficiently relevant RBI press release or notification was found "
                "for this event (similarity below the %.2f threshold). This does not mean "
                "nothing happened - only that no matching public RBI document was retrieved." % MIN_RELEVANCE_SCORE)

    top = retrieved[0]
    doc = top["document"]
    excerpt = doc["content"][:280].rsplit(" ", 1)[0] + "..."
    return (
        "Closest matching RBI document found (similarity score %.2f): \"%s\" (%s). "
        "Excerpt: %s [Source: %s]" % (top["score"], doc["title"], doc["pub_date"], excerpt, doc["link"])
    )


def llm_explanation(row, retrieved):
    """Optional LLM-polished explanation, grounded strictly in retrieved text."""
    if not retrieved:
        return extractive_explanation(retrieved)

    context = "\n\n".join(
        "Document: %s (%s)\n%s" % (r["document"]["title"], r["document"]["pub_date"], r["document"]["content"][:600])
        for r in retrieved
    )

    prompt = (
        "You are explaining a detected change in a bank's UPI technical/business decline rate, "
        "using ONLY the RBI documents provided below. Do not add any information not present in "
        "these documents. If the documents don't clearly explain the change, say so explicitly "
        "rather than guessing.\n\n"
        "Bank: %s\nMonth: %s\nDirection: %s (%.3f -> %.3f percentage points)\n\n"
        "Retrieved RBI documents:\n%s\n\n"
        "Write a 2-3 sentence grounded explanation, citing which document (by title) supports it."
    ) % (row["bank_name"], row["change_month"], row["direction"], row["avg_before"], row["avg_after"], context)

    try:
        if ANTHROPIC_API_KEY:
            import anthropic
            client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)
            response = client.messages.create(
                model="claude-haiku-4-5-20251001", max_tokens=200,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text.strip()
        elif OPENAI_API_KEY:
            from openai import OpenAI
            client = OpenAI(api_key=OPENAI_API_KEY)
            response = client.chat.completions.create(
                model="gpt-4o-mini", max_tokens=200,
                messages=[{"role": "user", "content": prompt}]
            )
            return response.choices[0].message.content.strip()
    except Exception as e:
        print("  [LLM call failed, falling back to extractive explanation] %s" % str(e)[:150])
        return extractive_explanation(retrieved)

    return extractive_explanation(retrieved)


def explain_changepoints(changepoint_csv_path="changepoint_results.csv", output_path="rag_explanations.csv"):
    df = pd.read_csv(changepoint_csv_path)
    use_llm = bool(ANTHROPIC_API_KEY or OPENAI_API_KEY)
    print("Generating explanations for %d flagged shift(s) using %s mode.\n" % (
        len(df), "LLM-polished" if use_llm else "extractive (free, local)"))

    results = []
    for _, row in df.iterrows():
        query = build_query(row)
        retrieved = retrieve(query)

        if use_llm:
            explanation = llm_explanation(row, retrieved)
        else:
            explanation = extractive_explanation(retrieved)

        status = "CONFIRMED" if not row.get("is_provisional", False) else "EMERGING (PROVISIONAL)"
        full_explanation = explanation
        if row.get("is_provisional", False) and row.get("warning"):
            full_explanation = str(row["warning"]) + " " + explanation

        results.append({
            "bank_name": row["bank_name"],
            "change_month": row["change_month"],
            "direction": row["direction"],
            "status": status,
            "explanation": full_explanation,
            "top_source_title": retrieved[0]["document"]["title"] if retrieved else None,
            "top_source_link": retrieved[0]["document"]["link"] if retrieved else None,
            "top_source_score": retrieved[0]["score"] if retrieved else None,
        })
        print("  %-30s %s (%s) -> %s" % (
            row["bank_name"], row["change_month"], status,
            "matched: " + retrieved[0]["document"]["title"][:60] if retrieved else "no relevant document found"))

    result_df = pd.DataFrame(results)
    result_df.to_csv(output_path, index=False)
    print("\nSaved %d explanations to %s" % (len(result_df), output_path))
    return result_df


if __name__ == "__main__":
    explain_changepoints()
