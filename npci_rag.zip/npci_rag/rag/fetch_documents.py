"""
Fetches RBI press releases and notifications from their public RSS feeds and
stores them in SQLite, deduplicated by link (RBI's unique URL per document).

This is the "regularly updates itself" piece: run this on a schedule (see
README) and it will only insert genuinely new documents each time - safe to
re-run as often as you like, same philosophy as the NPCI ingestion pipeline.

NOTE: requires normal internet access to rbi.org.in. If you're behind a
restrictive corporate proxy/firewall, this specific step needs to run
somewhere with unrestricted access - the rest of the RAG pipeline (embedding,
retrieval, explanation) works fully offline once documents are stored.
"""

import os
import sys
import sqlite3
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from html import unescape

import requests

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.config import DB_PATH, RBI_FEEDS


def init_documents_table():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS rbi_documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            link TEXT UNIQUE NOT NULL,
            pub_date TEXT,
            doc_type TEXT,
            fetched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    conn.close()


def strip_html(raw_html):
    """RBI's RSS descriptions are HTML (often full tables). Strips tags down
    to plain readable text for embedding and display."""
    if not raw_html:
        return ""
    text = re.sub(r"<[^>]+>", " ", raw_html)
    text = unescape(text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def parse_rss_content(xml_text, doc_type):
    """Parses RSS XML text into a list of document dicts. Pure parsing logic,
    separated from the network fetch so it can be tested against a saved
    fixture file without needing live internet access."""
    root = ET.fromstring(xml_text)
    docs = []
    for item in root.findall(".//item"):
        title = (item.findtext("title") or "").strip()
        description = item.findtext("description") or ""
        link = (item.findtext("link") or "").strip()
        pub_date_raw = (item.findtext("pubDate") or "").strip()

        if not link or not title:
            continue

        content = strip_html(description)

        pub_date = None
        for fmt in ("%a, %d %b %Y %H:%M:%S", "%a, %d %b %Y %H:%M:%S %Z"):
            try:
                pub_date = datetime.strptime(pub_date_raw, fmt).strftime("%Y-%m-%d")
                break
            except ValueError:
                continue
        if pub_date is None:
            pub_date = pub_date_raw

        docs.append({
            "title": title,
            "content": content,
            "link": link,
            "pub_date": pub_date,
            "doc_type": doc_type,
        })
    return docs


def fetch_feed(url, doc_type, timeout=15):
    """Live network fetch - requires normal internet access."""
    response = requests.get(url, timeout=timeout)
    response.raise_for_status()
    return parse_rss_content(response.text, doc_type)


def store_documents(docs):
    """Inserts documents, skipping any whose link already exists (dedup)."""
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    inserted, skipped = 0, 0
    for doc in docs:
        try:
            cur.execute(
                "INSERT INTO rbi_documents (title, content, link, pub_date, doc_type) VALUES (?, ?, ?, ?, ?)",
                (doc["title"], doc["content"], doc["link"], doc["pub_date"], doc["doc_type"]),
            )
            inserted += 1
        except sqlite3.IntegrityError:
            skipped += 1
            continue
    conn.commit()
    conn.close()
    return inserted, skipped


def refresh_all_feeds():
    """Main entry point: fetches all configured RBI feeds and stores new documents."""
    init_documents_table()
    total_inserted = 0

    for doc_type, url in RBI_FEEDS.items():
        print("Fetching %s feed: %s" % (doc_type, url))
        try:
            docs = fetch_feed(url, doc_type)
        except requests.exceptions.RequestException as e:
            print("  FAILED to fetch %s: %s" % (doc_type, str(e)[:150]))
            print("  (If you're on a restricted network, this step needs unrestricted internet access.)")
            continue

        inserted, skipped = store_documents(docs)
        total_inserted += inserted
        print("  %d new documents inserted, %d already known (skipped)." % (inserted, skipped))

    print("\nDone. %d new documents added this run." % total_inserted)
    return total_inserted


if __name__ == "__main__":
    refresh_all_feeds()
