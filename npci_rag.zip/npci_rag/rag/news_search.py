"""
On-demand Google News search - a THIRD retrieval tier, used only when both
the static document store (RBI + NPCI feeds) fail to find a relevant match.

Why this exists: RBI's and NPCI's official feeds cover regulatory/policy
content, not day-to-day incident reporting. If "STATE BANK OF INDIA" has a
technical decline spike in a given month because of an actual reported
outage, that story is far more likely to show up in NEWS coverage than in
a government circular. Google News RSS search is free, needs no API key,
and can be queried per-bank/per-month at explanation time.

This is deliberately NOT pre-fetched into the permanent document store -
it's queried live, per change-point, since a fixed set of queries covering
every bank/month combination in advance would be both wasteful and stale.

NOTE: like fetch_documents.py, this needs normal internet access to
news.google.com. Same considerations apply as the RBI/NPCI fetch - if this
is blocked on a restricted network, this tier is simply skipped gracefully
and the pipeline falls back to the statistical-summary-only explanation.
"""

import os
import sys
import requests
from urllib.parse import quote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.fetch_documents import parse_rss_content

GOOGLE_NEWS_BASE = "https://news.google.com/rss/search"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
}


def build_news_query(bank_name, change_month, direction):
    """Builds a targeted search query for a specific bank's UPI issue in a given month."""
    event_term = "UPI outage OR UPI down OR UPI technical issue OR UPI failure" if direction == "WORSENED" else "UPI improvement OR UPI upgrade"
    return "\"%s\" (%s)" % (bank_name, event_term)


def search_bank_news(bank_name, change_month, direction, timeout=10):
    """
    Live-queries Google News RSS for bank-specific UPI incident coverage.
    Returns a list of document-shaped dicts (same shape as the static store's
    documents) so it can be used interchangeably in the retrieval/explanation
    pipeline. Returns an empty list on any failure (network blocked, no
    results, malformed response) - this tier is optional/best-effort by design.
    """
    query = build_news_query(bank_name, change_month, direction)
    url = "%s?q=%s&hl=en-IN&gl=IN&ceid=IN:en" % (GOOGLE_NEWS_BASE, quote(query))

    try:
        response = requests.get(url, timeout=timeout, headers=HEADERS)
        response.raise_for_status()
        docs = parse_rss_content(response.content, doc_type="news")
        return docs[:5]
    except requests.exceptions.RequestException as e:
        print("    [Google News search unavailable - network issue] %s" % str(e)[:120])
        return []
    except ValueError as e:
        print("    [Google News search returned an unexpected response] %s" % str(e)[:150])
        return []
    except Exception as e:
        print("    [Google News search failed unexpectedly] %s" % str(e)[:120])
        return []


if __name__ == "__main__":
    bank = sys.argv[1] if len(sys.argv) > 1 else "STATE BANK OF INDIA"
    month = sys.argv[2] if len(sys.argv) > 2 else "2026-09"
    direction = sys.argv[3] if len(sys.argv) > 3 else "WORSENED"

    print("Searching Google News for: %s (%s, %s)\n" % (bank, month, direction))
    results = search_bank_news(bank, month, direction)
    if not results:
        print("No news results found (or search unavailable).")
    for d in results:
        print("- %s (%s)\n  %s\n" % (d["title"], d["pub_date"], d["link"]))
