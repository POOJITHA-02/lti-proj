"""
Given a query string, returns the top-K most relevant RBI documents from the
local index built by embeddings.py. Works with either backend (TF-IDF or
semantic) transparently - the caller doesn't need to know which is active.
"""

import os
import sys
import sqlite3
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.config import DB_PATH, TOP_K_RESULTS, MIN_RELEVANCE_SCORE
from rag.embeddings import update_embeddings, _get_semantic_model


def _get_document_by_id(doc_id):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM rbi_documents WHERE id = ?", (doc_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def retrieve(query, top_k=TOP_K_RESULTS, min_score=MIN_RELEVANCE_SCORE, require_keyword="upi",
             doc_type_filter=None, exclude_doc_types=None):
    """
    Returns a list of {document, score} dicts, highest relevance first.
    Documents scoring below `min_score` are excluded - an empty result means
    "nothing in the document store is genuinely relevant to this query",
    which should be reported honestly, not papered over with a weak match.

    ALSO requires `require_keyword` (default "upi") to actually appear in the
    document's title or content, regardless of its similarity score. This
    exists because TF-IDF similarity can be misleadingly high between two
    completely unrelated documents that merely share generic words like
    "Bank" or "Directions" - found during testing, where an RBI notice about
    an entirely different bank's unrelated regulatory restrictions scored
    0.33 (above the 0.30 threshold) against a UPI-reliability query purely
    on generic word overlap. Requiring the topic keyword is a simple, robust,
    explainable guard against this - set require_keyword=None to disable.

    `doc_type_filter`: if set, only returns documents of this doc_type (e.g.
    "domain_knowledge" to retrieve only the curated reference documents).
    `exclude_doc_types`: if set (a list), excludes documents of these
    doc_types (e.g. excluding "domain_knowledge" when searching specifically
    for event-specific news/circulars, so the always-relevant reference docs
    don't crowd out a genuine event-specific match).
    """
    cache = update_embeddings()

    if cache["vectors"] is None or len(cache["doc_ids"]) == 0:
        return []

    if cache["backend"] == "semantic":
        model = _get_semantic_model()
        query_vec = model.encode([query], normalize_embeddings=True)[0]
        scores = cache["vectors"] @ query_vec
    else:
        query_vec = cache["vectorizer"].transform([query])
        from sklearn.metrics.pairwise import cosine_similarity
        scores = cosine_similarity(query_vec, cache["vectors"])[0]

    ranked_idx = np.argsort(scores)[::-1]

    results = []
    for idx in ranked_idx:
        if len(results) >= top_k:
            break
        score = float(scores[idx])
        if score < min_score:
            continue
        doc = _get_document_by_id(cache["doc_ids"][idx])
        if not doc:
            continue
        if doc_type_filter and doc.get("doc_type") != doc_type_filter:
            continue
        if exclude_doc_types and doc.get("doc_type") in exclude_doc_types:
            continue
        if require_keyword and require_keyword.lower() not in (doc["title"] + " " + doc["content"]).lower():
            continue
        results.append({"document": doc, "score": round(score, 4)})

    return results


if __name__ == "__main__":
    # Quick manual test: python rag/retriever.py "your query here"
    query = " ".join(sys.argv[1:]) or "UPI technical decline bank transaction failure"
    print("Query: %s\n" % query)
    results = retrieve(query)
    if not results:
        print("No sufficiently relevant documents found (min_score=%.2f)." % MIN_RELEVANCE_SCORE)
    for r in results:
        print("[score=%.3f] %s (%s)" % (r["score"], r["document"]["title"], r["document"]["pub_date"]))
        print("  %s\n" % r["document"]["link"])
