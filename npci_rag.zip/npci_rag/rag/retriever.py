"""
Given a query string, returns the top-K most relevant RBI documents from the
local index built by embeddings.py. Works with either backend (TF-IDF or
semantic) transparently - the caller doesn't need to know which is active.
"""

import os
import sys
import sqlite3
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rag.config import DB_PATH, TOP_K_RESULTS, MIN_RELEVANCE_SCORE
from rag.embeddings import update_embeddings, _get_semantic_model


def _get_document_by_id(doc_id):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute("SELECT * FROM rbi_documents WHERE id = ?", (doc_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def retrieve(query, top_k=TOP_K_RESULTS, min_score=MIN_RELEVANCE_SCORE):
    """
    Returns a list of {document, score} dicts, highest relevance first.
    Documents scoring below `min_score` are excluded - an empty result means
    "nothing in the document store is genuinely relevant to this query",
    which should be reported honestly, not papered over with a weak match.
    """
    cache = update_embeddings()  # ensures index is current before searching

    if cache["vectors"] is None or len(cache["doc_ids"]) == 0:
        return []

    if cache["backend"] == "semantic":
        model = _get_semantic_model()
        query_vec = model.encode([query], normalize_embeddings=True)[0]
        scores = cache["vectors"] @ query_vec  # cosine similarity (vectors are normalized)
    else:
        query_vec = cache["vectorizer"].transform([query])
        from sklearn.metrics.pairwise import cosine_similarity
        scores = cosine_similarity(query_vec, cache["vectors"])[0]

    ranked_idx = np.argsort(scores)[::-1][:top_k]

    results = []
    for idx in ranked_idx:
        score = float(scores[idx])
        if score < min_score:
            continue
        doc = _get_document_by_id(cache["doc_ids"][idx])
        if doc:
            results.append({"document": doc, "score": round(score, 4)})

    return results


if __name__ == "__main__":
    # Quick manual test: python rag/retriever.py "your query here"
    query = " ".join(sys.argv[1:]) or "UPI technical decline bank transaction failure"
    print("Query: %s\n" % query)
    results = retrieve(query)
    if not results:
        print("No sufficiently relevant documents found (min_score=%.2f)." % MIN_RELEVANCE_SCORE)
    for r in results:
        print("[score=%.3f] %s (%s)" % (r["score"], r["document"]["title"], r["document"]["pub_date"]))
        print("  %s\n" % r["document"]["link"])
