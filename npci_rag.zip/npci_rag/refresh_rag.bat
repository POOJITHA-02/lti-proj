@echo off
REM Refreshes RBI documents and regenerates explanations for the latest
REM changepoint_results.csv. Point Windows Task Scheduler at this file to
REM keep the RAG explanation layer up to date automatically.

cd /d "%~dp0"
python run_rag_pipeline.py >> rag_refresh_log.txt 2>&1
