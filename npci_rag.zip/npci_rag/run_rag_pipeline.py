"""
Full RAG pipeline, run in sequence:
  1. Fetch new RBI/NPCI documents (safe to re-run - only adds genuinely new ones)
     + seed domain knowledge (TD/BD/reversal definitions, causes, trends)
  2. Update the local retrieval index (incremental)
  3. Generate explanations for every row in the metric's changepoint_results CSV

Usage:
    python run_rag_pipeline.py                              -> td_pct (default)
    python run_rag_pipeline.py --metric bd_pct                -> a specific metric
    python run_rag_pipeline.py --all-metrics                   -> all 4 metrics in one run
    python run_rag_pipeline.py --skip-fetch                    -> offline, use existing documents only
    (flags can be combined, e.g. --all-metrics --skip-fetch)

Expects the matching changepoint_results CSV(s) from the analytics module's
run_all_analytics.py to already be copied into this folder:
  changepoint_results.csv                          (td_pct)
  changepoint_results_bd_pct.csv
  changepoint_results_reversal_failure_pct.csv
  changepoint_results_total_debit_reversal_count_mn.csv
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rag.fetch_documents import refresh_all_feeds, seed_domain_knowledge
from rag.embeddings import update_embeddings
from rag.explain import explain_changepoints

ALL_METRICS = ["td_pct", "bd_pct", "reversal_failure_pct", "total_debit_reversal_count_mn"]


def _input_filename(metric):
    return "changepoint_results.csv" if metric == "td_pct" else "changepoint_results_%s.csv" % metric


def _output_filename(metric):
    return "rag_explanations.csv" if metric == "td_pct" else "rag_explanations_%s.csv" % metric


if __name__ == "__main__":
    skip_fetch = "--skip-fetch" in sys.argv
    all_metrics = "--all-metrics" in sys.argv
    metric_flag_idx = sys.argv.index("--metric") if "--metric" in sys.argv else None
    single_metric = sys.argv[metric_flag_idx + 1] if metric_flag_idx is not None else "td_pct"

    metrics_to_run = ALL_METRICS if all_metrics else [single_metric]

    print("=" * 70)
    print("STEP 1/3: FETCHING RBI/NPCI DOCUMENTS + SEEDING DOMAIN KNOWLEDGE")
    print("=" * 70)
    if skip_fetch:
        print("Live fetch skipped (--skip-fetch flag set) - using documents already in the database.")
        seed_domain_knowledge()
        print()
    else:
        refresh_all_feeds()
        print()

    print("=" * 70)
    print("STEP 2/3: UPDATING RETRIEVAL INDEX")
    print("=" * 70)
    update_embeddings()
    print()

    print("=" * 70)
    print("STEP 3/3: GENERATING EXPLANATIONS FOR FLAGGED CHANGE-POINTS")
    print("=" * 70)

    any_succeeded = False
    for metric in metrics_to_run:
        input_file = _input_filename(metric)
        output_file = _output_filename(metric)

        if not os.path.exists(input_file):
            print("  [SKIPPING %s] %s not found - run the analytics module first "
                  "(run_all_analytics.py in the npci_analytics project) and copy its "
                  "output CSVs into this folder." % (metric, input_file))
            continue

        print("\n--- Metric: %s (%s -> %s) ---" % (metric, input_file, output_file))
        explain_changepoints(changepoint_csv_path=input_file, output_path=output_file)
        any_succeeded = True

    if not any_succeeded:
        print("\nNo changepoint_results CSV(s) found for the requested metric(s). Nothing generated.")
        sys.exit(1)

    print("\n" + "=" * 70)
    print("DONE.")
    print("=" * 70)
