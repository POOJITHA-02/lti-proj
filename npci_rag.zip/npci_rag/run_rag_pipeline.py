"""
Full RAG pipeline, run in sequence:
  1. Fetch new RBI documents (safe to re-run - only adds genuinely new ones)
  2. Update the local retrieval index (incremental)
  3. Generate explanations for every row in changepoint_results.csv

Usage:
    python run_rag_pipeline.py
    python run_rag_pipeline.py --skip-fetch     (use existing documents only, e.g. if offline)
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from rag.fetch_documents import refresh_all_feeds
from rag.embeddings import update_embeddings
from rag.explain import explain_changepoints

if __name__ == "__main__":
    skip_fetch = "--skip-fetch" in sys.argv

    print("=" * 70)
    print("STEP 1/3: FETCHING RBI DOCUMENTS (press releases + notifications)")
    print("=" * 70)
    if skip_fetch:
        print("Skipped (--skip-fetch flag set) - using documents already in the database.\n")
    else:
        refresh_all_feeds()
        print()

    print("=" * 70)
    print("STEP 2/3: UPDATING RETRIEVAL INDEX")
    print("=" * 70)
    update_embeddings()
    print()

    print("=" * 70)
    print("STEP 3/3: GENERATING EXPLANATIONS FOR FLAGGED CHANGE-POINTS")
    print("=" * 70)
    if not os.path.exists("changepoint_results.csv"):
        print("changepoint_results.csv not found - run the analytics module first "
              "(run_all_analytics.py in the npci_analytics project) and copy its "
              "changepoint_results.csv into this folder.")
        sys.exit(1)
    explain_changepoints()

    print("\n" + "=" * 70)
    print("DONE. rag_explanations.csv is ready.")
    print("=" * 70)
