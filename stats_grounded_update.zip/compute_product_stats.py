from datetime import datetime

from db import get_connection, init_db


def already_computed(conn) -> bool:
    row = conn.execute("SELECT COUNT(*) FROM product_stats").fetchone()
    return row[0] > 0


def compute_and_store(conn) -> int:
    now = datetime.utcnow().isoformat()

    conn.execute(
        """INSERT INTO product_stats (product_id, purchase_count, reorder_rate,
                                       avg_basket_size_when_purchased, computed_at)
           WITH order_basket_sizes AS (
               SELECT order_id, COUNT(*) AS basket_size
               FROM source_order_items
               GROUP BY order_id
           )
           SELECT soi.product_id,
                  COUNT(*) AS purchase_count,
                  AVG(soi.reordered) AS reorder_rate,
                  AVG(obs.basket_size) AS avg_basket_size_when_purchased,
                  ?
           FROM source_order_items soi
           JOIN order_basket_sizes obs ON soi.order_id = obs.order_id
           GROUP BY soi.product_id""",
        (now,),
    )
    conn.commit()
    return conn.execute("SELECT COUNT(*) FROM product_stats").fetchone()[0]


def run(force: bool = False) -> None:
    init_db()
    conn = get_connection()

    if already_computed(conn) and not force:
        print("product_stats already populated — skipping. Pass force=True to recompute.")
        conn.close()
        return

    if force:
        conn.execute("DELETE FROM product_stats")
        conn.commit()

    print("Computing per-product purchase statistics from source_order_items...")
    count = compute_and_store(conn)
    print(f"Done. Stats computed for {count:,} products.")
    conn.close()


if __name__ == "__main__":
    run()
