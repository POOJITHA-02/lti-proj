# UPI Reliability Index — Web App (Frontend + Auth)

## 1. Install dependencies
Open this folder in VS Code, open a terminal, then run:

```
pip install -r requirements.txt
```

## 2. Configure environment variables
Copy `.env.example` to `.env`:

```
copy .env.example .env        (Windows)
```

Open `.env` and fill in:
- `SECRET_KEY` — any long random string (used to sign login sessions)
- `SMTP_USER` / `SMTP_PASSWORD` — your email + a Gmail **App Password**
  (Google Account -> Security -> 2-Step Verification -> App Passwords)
- `POWERBI_EMBED_URL` — leave blank for now; add later once your report is published

## 3. Run the app
```
uvicorn app.main:app --reload
```

Then open: http://127.0.0.1:8000

## 4. Test the flow
1. Go to `/signup`, create an account
2. Check your email for the 6-digit OTP (or check the terminal — if SMTP isn't set up yet,
   the OTP prints there as `[DEV FALLBACK] OTP for ...`)
3. Enter the OTP to verify
4. Log in at `/login`
5. You'll land on `/dashboard` — the Power BI panel and RAG explanation panel are both there,
   ready to be connected

## 5. View the database
Open `users.db` (created automatically in the project root after first run) in
**DB Browser for SQLite** to see the `users` and `otp_codes` tables live.

## 6. Connect Power BI later
In Power BI Desktop: File -> Publish -> publish to Power BI Service, then use
"Publish to web" (or an embed link) to get a URL. Paste it into `POWERBI_EMBED_URL`
in `.env` and restart the app.

## Notes
- This uses SQLite (zero setup, works on a locked-down office laptop) — the DB file
  is `users.db` in the project root.
- Passwords are hashed with bcrypt, never stored in plain text.
- Login sessions use a signed JWT stored in an httponly cookie.
- OTPs expire after 10 minutes and can only be used once.
