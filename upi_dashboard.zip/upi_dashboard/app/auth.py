import os
import random
import string
from datetime import datetime, timedelta
from passlib.context import CryptContext
from jose import jwt, JWTError
from dotenv import load_dotenv

from app.database import get_db

load_dotenv()

SECRET_KEY = os.getenv("SECRET_KEY", "fallback_secret_change_me")
ALGORITHM = os.getenv("ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "60"))

pwd_context = CryptContext(schemes=["pbkdf2_sha256"], deprecated="auto")


# ---------- Password helpers ----------
def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


# ---------- JWT session token helpers ----------
def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None


# ---------- User DB helpers ----------
def get_user_by_email(email: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE email = ?", (email,))
        return cur.fetchone()


def create_user(full_name: str, email: str, password: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (full_name, email, hashed_password, is_verified) VALUES (?, ?, ?, 0)",
            (full_name, email, hash_password(password)),
        )
        conn.commit()


def mark_user_verified(email: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("UPDATE users SET is_verified = 1 WHERE email = ?", (email,))
        conn.commit()


def update_user_password(email: str, new_password: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            "UPDATE users SET hashed_password = ? WHERE email = ?",
            (hash_password(new_password), email),
        )
        conn.commit()


# ---------- OTP helpers ----------
def generate_otp() -> str:
    return "".join(random.choices(string.digits, k=6))


def store_otp(email: str, otp_code: str, purpose: str, expiry_minutes: int = 10):
    expires_at = datetime.utcnow() + timedelta(minutes=expiry_minutes)
    with get_db() as conn:
        cur = conn.cursor()
        # invalidate previous unused OTPs of the same purpose for this email
        cur.execute(
            "UPDATE otp_codes SET used = 1 WHERE email = ? AND purpose = ? AND used = 0",
            (email, purpose),
        )
        cur.execute(
            "INSERT INTO otp_codes (email, otp_code, purpose, expires_at) VALUES (?, ?, ?, ?)",
            (email, otp_code, purpose, expires_at.strftime("%Y-%m-%d %H:%M:%S")),
        )
        conn.commit()


def verify_otp(email: str, otp_code: str, purpose: str) -> bool:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            """SELECT * FROM otp_codes
               WHERE email = ? AND otp_code = ? AND purpose = ? AND used = 0
               ORDER BY id DESC LIMIT 1""",
            (email, otp_code, purpose),
        )
        row = cur.fetchone()
        if not row:
            return False

        expires_at = datetime.strptime(row["expires_at"], "%Y-%m-%d %H:%M:%S")
        if datetime.utcnow() > expires_at:
            return False

        cur.execute("UPDATE otp_codes SET used = 1 WHERE id = ?", (row["id"],))
        conn.commit()
        return True
