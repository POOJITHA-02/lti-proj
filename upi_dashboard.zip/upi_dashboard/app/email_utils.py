import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
SMTP_FROM = os.getenv("SMTP_FROM", SMTP_USER)


def send_otp_email(to_email: str, otp_code: str, purpose: str):
    """
    purpose: 'signup' or 'reset'
    """
    if purpose == "signup":
        subject = "Verify your account - OTP Code"
        heading = "Confirm your signup"
    else:
        subject = "Reset your password - OTP Code"
        heading = "Reset your password"

    html_body = f"""
    <div style="font-family: Arial, sans-serif; background:#0d0d0d; padding:30px; color:#f5f5f5;">
      <div style="max-width:480px; margin:auto; background:#1a1a1a; border:1px solid #b30000;
                  border-radius:10px; padding:30px; text-align:center;">
        <h2 style="color:#ff1a1a; margin-bottom:10px;">{heading}</h2>
        <p style="color:#cccccc;">Use the code below. It expires in 10 minutes.</p>
        <div style="font-size:32px; letter-spacing:8px; font-weight:bold; color:#ffffff;
                    background:#330000; padding:15px; border-radius:8px; margin:20px 0;">
          {otp_code}
        </div>
        <p style="color:#888888; font-size:12px;">If you didn't request this, you can ignore this email.</p>
      </div>
    </div>
    """

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = SMTP_FROM
    msg["To"] = to_email
    msg.attach(MIMEText(html_body, "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_FROM, to_email, msg.as_string())
        return True
    except Exception as e:
        print(f"[EMAIL ERROR] Could not send OTP email: {e}")
        return False
