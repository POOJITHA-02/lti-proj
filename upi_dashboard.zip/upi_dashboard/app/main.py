import os
from fastapi import FastAPI, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from dotenv import load_dotenv

from app.database import init_db
from app.auth import (
    get_user_by_email, create_user, mark_user_verified, update_user_password,
    verify_password, create_access_token, decode_access_token,
    generate_otp, store_otp, verify_otp,
)
from app.email_utils import send_otp_email

load_dotenv()

app = FastAPI(title="UPI Reliability Index")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

POWERBI_EMBED_URL = os.getenv("POWERBI_EMBED_URL", "")


@app.on_event("startup")
def on_startup():
    init_db()


# ---------- Helper: get current logged-in user from cookie ----------
def get_current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        return None
    payload = decode_access_token(token)
    if not payload:
        return None
    return payload.get("sub")  # email


# ---------- Root ----------
@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    if get_current_user(request):
        return RedirectResponse("/dashboard", status_code=303)
    return RedirectResponse("/login", status_code=303)


# ---------- SIGNUP ----------
@app.get("/signup", response_class=HTMLResponse)
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request, "error": None})


@app.post("/signup")
def signup(request: Request, full_name: str = Form(...), email: str = Form(...), password: str = Form(...)):
    existing = get_user_by_email(email)
    if existing:
        return templates.TemplateResponse(
            "signup.html", {"request": request, "error": "An account with this email already exists."}
        )

    create_user(full_name, email, password)

    otp_code = generate_otp()
    store_otp(email, otp_code, purpose="signup")
    sent = send_otp_email(email, otp_code, purpose="signup")

    if not sent:
        print(f"[DEV FALLBACK] OTP for {email}: {otp_code}")  # visible in terminal if SMTP isn't configured yet

    return RedirectResponse(f"/verify-otp?email={email}", status_code=303)


# ---------- VERIFY OTP (signup) ----------
@app.get("/verify-otp", response_class=HTMLResponse)
def verify_otp_page(request: Request, email: str):
    return templates.TemplateResponse("verify_otp.html", {"request": request, "email": email, "error": None})


@app.post("/verify-otp")
def verify_otp_submit(request: Request, email: str = Form(...), otp_code: str = Form(...)):
    valid = verify_otp(email, otp_code, purpose="signup")
    if not valid:
        return templates.TemplateResponse(
            "verify_otp.html", {"request": request, "email": email, "error": "Invalid or expired code. Try again."}
        )
    mark_user_verified(email)
    return RedirectResponse("/login", status_code=303)


@app.get("/resend-otp")
def resend_otp(email: str):
    otp_code = generate_otp()
    store_otp(email, otp_code, purpose="signup")
    sent = send_otp_email(email, otp_code, purpose="signup")
    if not sent:
        print(f"[DEV FALLBACK] Resent OTP for {email}: {otp_code}")
    return RedirectResponse(f"/verify-otp?email={email}", status_code=303)


# ---------- LOGIN ----------
@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request, "error": None, "success": None})


@app.post("/login")
def login(request: Request, email: str = Form(...), password: str = Form(...)):
    user = get_user_by_email(email)
    if not user or not verify_password(password, user["hashed_password"]):
        return templates.TemplateResponse(
            "login.html", {"request": request, "error": "Incorrect email or password.", "success": None}
        )
    if not user["is_verified"]:
        return templates.TemplateResponse(
            "login.html", {"request": request, "error": "Please verify your email first.", "success": None}
        )

    token = create_access_token({"sub": email})
    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie(key="access_token", value=token, httponly=True, max_age=3600)
    return response


@app.get("/logout")
def logout():
    response = RedirectResponse("/login", status_code=303)
    response.delete_cookie("access_token")
    return response


# ---------- FORGOT PASSWORD ----------
@app.get("/forgot-password", response_class=HTMLResponse)
def forgot_password_page(request: Request):
    return templates.TemplateResponse("forgot_password.html", {"request": request, "error": None})


@app.post("/forgot-password")
def forgot_password(request: Request, email: str = Form(...)):
    user = get_user_by_email(email)
    if not user:
        return templates.TemplateResponse(
            "forgot_password.html", {"request": request, "error": "No account found with this email."}
        )

    otp_code = generate_otp()
    store_otp(email, otp_code, purpose="reset")
    sent = send_otp_email(email, otp_code, purpose="reset")
    if not sent:
        print(f"[DEV FALLBACK] Reset OTP for {email}: {otp_code}")

    return RedirectResponse(f"/reset-password?email={email}", status_code=303)


# ---------- RESET PASSWORD ----------
@app.get("/reset-password", response_class=HTMLResponse)
def reset_password_page(request: Request, email: str):
    return templates.TemplateResponse("reset_password.html", {"request": request, "email": email, "error": None})


@app.post("/reset-password")
def reset_password(request: Request, email: str = Form(...), otp_code: str = Form(...), new_password: str = Form(...)):
    valid = verify_otp(email, otp_code, purpose="reset")
    if not valid:
        return templates.TemplateResponse(
            "reset_password.html", {"request": request, "email": email, "error": "Invalid or expired code."}
        )
    update_user_password(email, new_password)
    return templates.TemplateResponse(
        "login.html", {"request": request, "error": None, "success": "Password reset successful. Please log in."}
    )


# ---------- DASHBOARD (protected) ----------
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    email = get_current_user(request)
    if not email:
        return RedirectResponse("/login", status_code=303)

    user = get_user_by_email(email)

    # Placeholder RAG data - replace with a real query to your processed anomalies table later
    rag_items = [
        {
            "bank": "Example Bank Ltd.",
            "month": "Aug 2026",
            "explanation": "Sample placeholder: this card will show a retrieval-grounded explanation "
                            "for any bank flagged by the change-point detection pipeline, once connected."
        }
    ]

    return templates.TemplateResponse("dashboard.html", {
        "request": request,
        "user_name": user["full_name"] if user else email,
        "powerbi_url": POWERBI_EMBED_URL,
        "rag_items": rag_items,
    })
