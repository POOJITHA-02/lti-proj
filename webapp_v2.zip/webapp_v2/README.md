# Signature-Driven Inventory — Web Application

Complete FastAPI web app: secure auth (signup/login/OTP/forgot-password, real SMTP
email), and 4 analytics pages reading live from your data pipeline's `instacart.db`.
Black/red gradient glassmorphism UI throughout.

## Setup

```
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env`:
- `SECRET_KEY` — put any long random string
- `INSTACART_DB_PATH` — path to your data pipeline's `instacart.db`. Default assumes
  this folder (`webapp_v2/`) sits next to `data_pipeline/`. Adjust if yours differs.
- SMTP block — leave blank to have OTP codes print to your terminal (fine for local
  testing/demo). To send real emails via Gmail, follow the comments in `.env.example`
  (needs a Google **App Password**, not your normal password).

Run:
```
uvicorn app.main:app --reload
```
Open `http://127.0.0.1:8000` — redirects to `/login`.

## Pages

| Page | What it does |
|---|---|
| **Login / Signup / Verify / Forgot / Reset** | Full auth lifecycle, OTP-gated signup and password reset, JWT session cookie |
| **Dashboard** | 5 shopper-signature filters, live cluster-size + basket/reorder charts, pipeline health stats, a live-polling order feed (refreshes every 5s) |
| **Trends** | Select a department + two month-years → percentage-**point** change and **relative** % change side by side, plus a doughnut-chart composition snapshot for each selected month |
| **Shopper Lookup** | Search any `user_id` → their full shopper signature, cluster peer count, and recent order history |
| **Insights** | Auto-generated plain-language, per-cluster recommendations (basket size, family orientation, stock-up behavior, routine vs. exploratory buying) — turns the cluster stats into something a non-technical stakeholder could read |
| **Compare** | Side-by-side head-to-head comparison of any two clusters — shopper counts, basket/reorder stats, top departments, and a grouped bar chart across 4 behavioral metrics |
| **Account** | Profile view + in-session password change (separate from the OTP-based forgot-password flow) |

## Visual design
Black/red gradient glassmorphism throughout, plus a subtle **3D floating background** (CSS-only rotating cubes, glowing orbs, a tilted ring) on every page — pure `transform`/`opacity` animations, no JS/WebGL, so it stays light on low-spec hardware. Respects `prefers-reduced-motion`.

## On "Trends" specifically

Two numbers are shown for every department's change, because they answer different
questions:
- **Percentage-point change** — the raw difference in share (e.g. 35% → 31% = **-4pts**).
  Best for "how much of the basket mix moved."
- **Relative % change** — the change relative to the starting value (e.g. 35% → 31% =
  **-11.4%**). Best for "how big a swing was this for that category specifically."

A department with no purchases in the "from" month shows `—` for relative change
(division by zero isn't meaningful there) but still shows its point change.

## On Power BI Desktop

This web app does **not** embed Power BI — true interactive Power BI embedding
requires Power BI Service (Pro/Premium license) + Azure AD app registration, which
isn't available on a Power BI **Desktop**-only setup. Power BI Desktop remains a
**separate, static deliverable** — build your `.pbix` dashboard there for
screenshots/demo in your portfolio, while this web app's Dashboard/Trends pages are
the "live" experience, built with native charts (Chart.js) driven directly by your
SQLite data instead.

## Data dependency

This app only **reads** from `instacart.db` — it never writes to it. Run these first,
in this order, from your `data_pipeline/` folder:
```
python load_reference_data.py
python stream_simulator.py          # MODE = "bulk"
python hybrid_tagging.py            # or llm_feature_engineering.py / rule_based_tagging.py
python pattern_discovery.py
python backdate_synthetic_dates.py  # needed for Trends to show month variation
```
If `analytics_ready` shows false on any page, it means `instacart.db` wasn't found at
`INSTACART_DB_PATH`, or `shopper_signatures` is empty — check the path in `.env` and
confirm `pattern_discovery.py` has been run.

## Auth notes

- Separate database (`app.db`, created automatically) — this app's user accounts
  are entirely independent from the Instacart `user_id`s in your analytics data.
  "Shopper Lookup" searches Instacart `user_id`s (the dataset's simulated shoppers),
  not the people who have accounts on this web app.
- Passwords are bcrypt-hashed (with the 72-byte truncation fix applied) and OTPs are
  hashed the same way, never stored in plaintext.
