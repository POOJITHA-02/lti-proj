import sqlite3

from app.config import INSTACART_DB_PATH


def get_analytics_connection() -> sqlite3.Connection:
    # uri=True + mode=ro opens it strictly read-only — this app should never
    # write into the analytics database, only the pipeline scripts do.
    conn = sqlite3.connect(f"file:{INSTACART_DB_PATH}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    return conn


def analytics_db_available() -> bool:
    try:
        conn = get_analytics_connection()
        conn.execute("SELECT 1 FROM shopper_signatures LIMIT 1")
        conn.close()
        return True
    except Exception:
        return False
