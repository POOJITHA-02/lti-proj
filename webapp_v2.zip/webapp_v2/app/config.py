import os
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

BASE_DIR = Path(__file__).parent.parent

SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-.env")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
OTP_EXPIRE_MINUTES = 10

# Path to the data pipeline's instacart.db (analytics — read-only from this app).
# Default assumes webapp_v2/ sits next to data_pipeline/ — adjust if your layout differs.
INSTACART_DB_PATH = os.getenv("INSTACART_DB_PATH", str(BASE_DIR.parent / "data_pipeline" / "instacart.db"))

# SMTP — leave blank to fall back to printing the OTP to console (dev mode)
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM_NAME = os.getenv("SMTP_FROM_NAME", "Signature-Driven Inventory")
