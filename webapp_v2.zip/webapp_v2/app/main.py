from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.analytics_db import analytics_db_available
from app.database import Base, SessionLocal, engine
from app.routers import account, auth, compare, dashboard, insights, shopper, trends
from app.routers.auth import get_current_user

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Signature-Driven Inventory")
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

app.include_router(auth.router)
app.include_router(dashboard.router)
app.include_router(trends.router)
app.include_router(shopper.router)
app.include_router(insights.router)
app.include_router(compare.router)
app.include_router(account.router)


def _user_or_none(request: Request):
    db: Session = SessionLocal()
    try:
        return get_current_user(request, db)
    finally:
        db.close()


def _require_login(request: Request):
    user = _user_or_none(request)
    if not user:
        return None
    return user


@app.get("/")
def root(request: Request):
    return RedirectResponse("/dashboard" if _user_or_none(request) else "/login")


@app.get("/login")
def login_page(request: Request):
    if _user_or_none(request):
        return RedirectResponse("/dashboard")
    return templates.TemplateResponse("login.html", {"request": request})


@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})


@app.get("/verify-otp")
def verify_otp_page(request: Request):
    return templates.TemplateResponse("verify_otp.html", {"request": request})


@app.get("/forgot-password")
def forgot_password_page(request: Request):
    return templates.TemplateResponse("forgot_password.html", {"request": request})


@app.get("/reset-password")
def reset_password_page(request: Request):
    return templates.TemplateResponse("reset_password.html", {"request": request})


def _protected_page(request: Request, template_name: str, extra_ctx: dict | None = None):
    user = _require_login(request)
    if not user:
        return RedirectResponse("/login")
    ctx = {"request": request, "user": user, "analytics_ready": analytics_db_available()}
    ctx.update(extra_ctx or {})
    return templates.TemplateResponse(template_name, ctx)


@app.get("/dashboard")
def dashboard_page(request: Request):
    return _protected_page(request, "dashboard.html")


@app.get("/trends")
def trends_page(request: Request):
    return _protected_page(request, "trends.html")


@app.get("/shopper")
def shopper_page(request: Request):
    return _protected_page(request, "shopper.html")


@app.get("/insights")
def insights_page(request: Request):
    return _protected_page(request, "insights.html")


@app.get("/compare")
def compare_page(request: Request):
    return _protected_page(request, "compare.html")


@app.get("/account")
def account_page(request: Request):
    return _protected_page(request, "account.html")
