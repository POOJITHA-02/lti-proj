import smtplib
from email.mime.text import MIMEText

from app.config import SMTP_FROM_NAME, SMTP_HOST, SMTP_PASSWORD, SMTP_PORT, SMTP_USER


def send_otp_email(to_email: str, otp: str, purpose: str) -> None:
    subject = "Your verification code" if purpose == "signup" else "Your password reset code"
    body = (
        f"Your one-time code is: {otp}\n\n"
        f"It expires in 10 minutes. If you didn't request this, you can ignore this email."
    )

    if not SMTP_HOST:
        print(f"[DEV OTP — no SMTP configured] To: {to_email} | Purpose: {purpose} | OTP: {otp}")
        return

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = f"{SMTP_FROM_NAME} <{SMTP_USER}>"
    msg["To"] = to_email

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.sendmail(SMTP_USER, [to_email], msg.as_string())
        print(f"OTP email sent to {to_email}")
    except Exception as e:
        # Don't crash signup/login flows if email delivery fails — log it and
        # also print the OTP so the user isn't locked out during development.
        print(f"SMTP send failed ({e}). Falling back to console.")
        print(f"[DEV OTP — SMTP FAILED] To: {to_email} | Purpose: {purpose} | OTP: {otp}")
