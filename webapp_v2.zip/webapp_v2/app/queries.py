from app.analytics_db import get_analytics_connection

# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

def get_cluster_overview(filters: dict) -> list[dict]:
    """Cluster summary, optionally filtered by the 5 shopper-signature dimensions."""
    conn = get_analytics_connection()
    where = ["1=1"]
    params = []
    for col in ["household_orientation", "convenience", "shopping_mission", "purchase_behavior", "basket_behavior"]:
        val = filters.get(col)
        if val and val != "all":
            where.append(f"ss.{col} = ?")
            params.append(val)

    rows = conn.execute(
        f"""SELECT ss.cluster_label,
                   COUNT(*) AS num_shoppers,
                   AVG(cf.avg_basket_size) AS avg_basket_size,
                   AVG(cf.reorder_rate) AS avg_reorder_rate,
                   AVG(cf.total_orders) AS avg_total_orders
            FROM shopper_signatures ss
            JOIN customer_features cf ON ss.user_id = cf.user_id
            WHERE {' AND '.join(where)}
            GROUP BY ss.cluster_label
            ORDER BY ss.cluster_label""",
        params,
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_recent_live_orders(limit: int = 15) -> list[dict]:
    conn = get_analytics_connection()
    rows = conn.execute(
        """SELECT lo.order_id, lo.user_id, lo.ingested_at,
                  COUNT(li.product_id) AS basket_size
           FROM live_orders lo
           JOIN live_order_items li ON lo.order_id = li.order_id
           GROUP BY lo.order_id
           ORDER BY lo.ingested_at DESC
           LIMIT ?""",
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_pipeline_status() -> dict:
    conn = get_analytics_connection()
    status = {
        "total_products": conn.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        "tagged_products": conn.execute("SELECT COUNT(*) FROM product_tags").fetchone()[0],
        "total_live_orders": conn.execute("SELECT COUNT(*) FROM live_orders").fetchone()[0],
        "total_shoppers_clustered": conn.execute("SELECT COUNT(*) FROM shopper_signatures").fetchone()[0],
        "last_order_ingested": conn.execute("SELECT MAX(ingested_at) FROM live_orders").fetchone()[0],
    }
    tag_sources = conn.execute(
        "SELECT tag_source, COUNT(*) FROM product_tags GROUP BY tag_source"
    ).fetchall()
    status["tag_source_breakdown"] = {row[0]: row[1] for row in tag_sources}
    conn.close()
    return status


# ---------------------------------------------------------------------------
# Trends — month-over-month % change by department
# ---------------------------------------------------------------------------

def get_available_months() -> list[str]:
    conn = get_analytics_connection()
    rows = conn.execute(
        "SELECT DISTINCT strftime('%Y-%m', ingested_at) AS month FROM live_orders "
        "WHERE ingested_at IS NOT NULL ORDER BY month"
    ).fetchall()
    conn.close()
    return [r[0] for r in rows if r[0]]


def get_department_list() -> list[str]:
    conn = get_analytics_connection()
    rows = conn.execute("SELECT department FROM departments ORDER BY department").fetchall()
    conn.close()
    return [r[0] for r in rows]


def _department_share_by_month() -> dict[str, dict[str, float]]:
    """Returns {month: {department: share_of_that_month's_items}}."""
    conn = get_analytics_connection()
    rows = conn.execute(
        """SELECT strftime('%Y-%m', lo.ingested_at) AS month, d.department, COUNT(*) AS items
           FROM live_orders lo
           JOIN live_order_items li ON lo.order_id = li.order_id
           JOIN products p ON li.product_id = p.product_id
           JOIN departments d ON p.department_id = d.department_id
           WHERE lo.ingested_at IS NOT NULL
           GROUP BY month, d.department"""
    ).fetchall()
    conn.close()

    totals: dict[str, int] = {}
    raw: dict[str, dict[str, int]] = {}
    for month, dept, items in rows:
        raw.setdefault(month, {})[dept] = items
        totals[month] = totals.get(month, 0) + items

    return {
        month: {dept: count / totals[month] for dept, count in depts.items()}
        for month, depts in raw.items()
    }


def get_month_snapshot(month: str) -> list[dict]:
    """Composition breakdown (% share) of every department for one month."""
    shares = _department_share_by_month().get(month, {})
    return sorted(
        [{"department": d, "share_pct": round(s * 100, 2)} for d, s in shares.items()],
        key=lambda r: r["share_pct"],
        reverse=True,
    )


def compare_months(from_month: str, to_month: str, department: str | None = None) -> list[dict]:
    """Percentage-point AND relative % change for every department (or one, if specified)
    between two selected month-years."""
    by_month = _department_share_by_month()
    from_shares = by_month.get(from_month, {})
    to_shares = by_month.get(to_month, {})
    all_depts = set(from_shares) | set(to_shares)
    if department and department != "all":
        all_depts &= {department}

    results = []
    for dept in all_depts:
        from_share = from_shares.get(dept, 0.0)
        to_share = to_shares.get(dept, 0.0)
        point_change = (to_share - from_share) * 100
        relative_change = ((to_share - from_share) / from_share * 100) if from_share > 0 else None

        results.append({
            "department": dept,
            "from_share_pct": round(from_share * 100, 2),
            "to_share_pct": round(to_share * 100, 2),
            "point_change_pct": round(point_change, 2),
            "relative_change_pct": round(relative_change, 2) if relative_change is not None else None,
        })

    return sorted(results, key=lambda r: abs(r["point_change_pct"]), reverse=True)


# ---------------------------------------------------------------------------
# Shopper lookup
# ---------------------------------------------------------------------------

def get_shopper_profile(user_id: int) -> dict | None:
    conn = get_analytics_connection()
    sig = conn.execute("SELECT * FROM shopper_signatures WHERE user_id = ?", (user_id,)).fetchone()
    if not sig:
        conn.close()
        return None

    features = conn.execute("SELECT * FROM customer_features WHERE user_id = ?", (user_id,)).fetchone()
    recent_orders = conn.execute(
        """SELECT lo.order_id, lo.ingested_at, COUNT(li.product_id) AS basket_size
           FROM live_orders lo JOIN live_order_items li ON lo.order_id = li.order_id
           WHERE lo.user_id = ? GROUP BY lo.order_id ORDER BY lo.ingested_at DESC LIMIT 10""",
        (user_id,),
    ).fetchall()

    peer_count = conn.execute(
        "SELECT COUNT(*) FROM shopper_signatures WHERE cluster_label = ?", (sig["cluster_label"],)
    ).fetchone()[0]

    conn.close()
    return {
        "signature": dict(sig),
        "features": dict(features) if features else {},
        "recent_orders": [dict(r) for r in recent_orders],
        "cluster_peer_count": peer_count,
    }


# ---------------------------------------------------------------------------
# Compare — side-by-side comparison of any two clusters
# ---------------------------------------------------------------------------

def get_cluster_labels() -> list[int]:
    conn = get_analytics_connection()
    rows = conn.execute("SELECT DISTINCT cluster_label FROM shopper_signatures ORDER BY cluster_label").fetchall()
    conn.close()
    return [r[0] for r in rows]


def _cluster_department_mix(conn, cluster_label: int, top_n: int = 5) -> list[dict]:
    rows = conn.execute(
        """SELECT d.department, COUNT(*) AS items
           FROM shopper_signatures ss
           JOIN live_orders lo ON ss.user_id = lo.user_id
           JOIN live_order_items li ON lo.order_id = li.order_id
           JOIN products p ON li.product_id = p.product_id
           JOIN departments d ON p.department_id = d.department_id
           WHERE ss.cluster_label = ?
           GROUP BY d.department
           ORDER BY items DESC
           LIMIT ?""",
        (cluster_label, top_n),
    ).fetchall()
    total = sum(r["items"] for r in rows) or 1
    return [{"department": r["department"], "share_pct": round(r["items"] / total * 100, 1)} for r in rows]


def compare_clusters(cluster_a: int, cluster_b: int) -> dict:
    conn = get_analytics_connection()

    def profile(cluster_label: int) -> dict:
        stats = conn.execute(
            """SELECT COUNT(*) AS num_shoppers,
                      AVG(cf.avg_basket_size) AS avg_basket_size,
                      AVG(cf.reorder_rate) AS avg_reorder_rate,
                      AVG(cf.total_orders) AS avg_total_orders,
                      SUM(CASE WHEN ss.household_orientation='family' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_family,
                      SUM(CASE WHEN ss.shopping_mission='stockup' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_stockup,
                      SUM(CASE WHEN ss.convenience='ready_to_eat' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_ready_to_eat,
                      SUM(CASE WHEN ss.purchase_behavior='routine' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_routine
               FROM shopper_signatures ss
               JOIN customer_features cf ON ss.user_id = cf.user_id
               WHERE ss.cluster_label = ?""",
            (cluster_label,),
        ).fetchone()
        return {
            "cluster_label": cluster_label,
            "num_shoppers": stats["num_shoppers"],
            "avg_basket_size": stats["avg_basket_size"],
            "avg_reorder_rate": stats["avg_reorder_rate"],
            "avg_total_orders": stats["avg_total_orders"],
            "pct_family": stats["pct_family"],
            "pct_stockup": stats["pct_stockup"],
            "pct_ready_to_eat": stats["pct_ready_to_eat"],
            "pct_routine": stats["pct_routine"],
            "top_departments": _cluster_department_mix(conn, cluster_label),
        }

    result = {"a": profile(cluster_a), "b": profile(cluster_b)}
    conn.close()
    return result


# ---------------------------------------------------------------------------
# Insights — plain-language, auto-generated per cluster
# ---------------------------------------------------------------------------

def generate_insights() -> list[dict]:
    conn = get_analytics_connection()
    clusters = conn.execute(
        """SELECT ss.cluster_label,
                  COUNT(*) AS num_shoppers,
                  AVG(cf.avg_basket_size) AS avg_basket_size,
                  AVG(cf.reorder_rate) AS avg_reorder_rate,
                  SUM(CASE WHEN ss.household_orientation='family' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_family,
                  SUM(CASE WHEN ss.shopping_mission='stockup' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_stockup,
                  SUM(CASE WHEN ss.purchase_behavior='routine' THEN 1 ELSE 0 END)*1.0/COUNT(*) AS pct_routine
           FROM shopper_signatures ss JOIN customer_features cf ON ss.user_id = cf.user_id
           GROUP BY ss.cluster_label"""
    ).fetchall()

    insights = []
    for c in clusters:
        lines = []
        size_word = "large" if c["avg_basket_size"] >= 15 else "small"
        lines.append(f"This group of {c['num_shoppers']} shoppers typically buys {size_word} baskets "
                      f"(avg {c['avg_basket_size']:.1f} items).")

        if c["pct_family"] >= 0.6:
            lines.append(f"{c['pct_family']*100:.0f}% show family-oriented buying patterns — "
                          f"consider stocking larger pack sizes for this segment.")
        elif c["pct_family"] <= 0.4:
            lines.append(f"Only {c['pct_family']*100:.0f}% skew family-oriented — "
                          f"single-serve and smaller pack sizes likely fit this segment better.")

        if c["pct_stockup"] >= 0.5:
            lines.append(f"{c['pct_stockup']*100:.0f}% shop in stock-up mode — "
                          f"ensure bulk availability isn't a bottleneck for this group.")

        if c["pct_routine"] >= 0.6:
            lines.append(f"{c['pct_routine']*100:.0f}% are routine/repeat buyers — "
                          f"a loyalty or auto-replenishment offer could resonate here.")
        elif c["pct_routine"] <= 0.3:
            lines.append(f"Only {c['pct_routine']*100:.0f}% are routine buyers — "
                          f"this group skews exploratory, a good target for new-product promotion.")

        insights.append({
            "cluster_label": c["cluster_label"],
            "num_shoppers": c["num_shoppers"],
            "summary": " ".join(lines),
        })

    conn.close()
    return insights
