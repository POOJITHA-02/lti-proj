from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app import schemas, security
from app.database import get_db
from app.models import User
from app.routers.auth import get_current_user

router = APIRouter(prefix="/api/account", tags=["account"])


def require_user(request: Request, db: Session = Depends(get_db)) -> User:
    user = get_current_user(request, db)
    if not user:
        raise HTTPException(401, "Not logged in")
    return user


@router.get("/profile")
def profile(user: User = Depends(require_user)):
    return {
        "email": user.email,
        "display_name": user.display_name,
        "member_since": user.created_at.isoformat() if user.created_at else None,
    }


@router.post("/change-password", response_model=schemas.MessageResponse)
def change_password(
    payload: schemas.ChangePasswordRequest,
    user: User = Depends(require_user),
    db: Session = Depends(get_db),
):
    if not security.verify_password(payload.current_password, user.hashed_password):
        raise HTTPException(400, "Current password is incorrect")
    user.hashed_password = security.hash_password(payload.new_password)
    db.commit()
    return {"message": "Password updated."}
