from fastapi import APIRouter, Query

from app import queries

router = APIRouter(prefix="/api/compare", tags=["compare"])


@router.get("/clusters")
def cluster_labels():
    return queries.get_cluster_labels()


@router.get("")
def compare(cluster_a: int = Query(...), cluster_b: int = Query(...)):
    return queries.compare_clusters(cluster_a, cluster_b)
