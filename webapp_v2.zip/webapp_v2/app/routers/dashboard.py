from fastapi import APIRouter, Query

from app import queries

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/clusters")
def clusters(
    household_orientation: str = Query("all"),
    convenience: str = Query("all"),
    shopping_mission: str = Query("all"),
    purchase_behavior: str = Query("all"),
    basket_behavior: str = Query("all"),
):
    filters = {
        "household_orientation": household_orientation,
        "convenience": convenience,
        "shopping_mission": shopping_mission,
        "purchase_behavior": purchase_behavior,
        "basket_behavior": basket_behavior,
    }
    return queries.get_cluster_overview(filters)


@router.get("/live-feed")
def live_feed(limit: int = 15):
    return queries.get_recent_live_orders(limit)


@router.get("/status")
def status():
    return queries.get_pipeline_status()
