from fastapi import APIRouter

from app import queries

router = APIRouter(prefix="/api/insights", tags=["insights"])


@router.get("")
def insights():
    return queries.generate_insights()
