from fastapi import APIRouter, HTTPException

from app import queries

router = APIRouter(prefix="/api/shopper", tags=["shopper"])


@router.get("/{user_id}")
def shopper(user_id: int):
    profile = queries.get_shopper_profile(user_id)
    if not profile:
        raise HTTPException(404, f"No shopper signature found for user_id {user_id}")
    return profile
