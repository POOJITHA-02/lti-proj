from fastapi import APIRouter, Query

from app import queries

router = APIRouter(prefix="/api/trends", tags=["trends"])


@router.get("/filters")
def filters():
    return {"months": queries.get_available_months(), "departments": queries.get_department_list()}


@router.get("/snapshot")
def snapshot(month: str = Query(...)):
    return queries.get_month_snapshot(month)


@router.get("/compare")
def compare(from_month: str = Query(...), to_month: str = Query(...), department: str = Query("all")):
    return queries.compare_months(from_month, to_month, department)
